/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_swc.h
 * PURPOSE:
 *      It provides hal switch control module API.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_SWC_H
#define HAL_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_cfg.h>
#include <clx_swc.h>


/* NAMING CONSTANT DECLARATIONS
 */

/*IPP hash engine for: ECMP, LAG*/
#define HAL_SWC_HASH_ID_ECMP_L3                     (0)
#define HAL_SWC_HASH_ID_ECMP_NVO3                   (1)
#define HAL_SWC_HASH_ID_LAG                         (2)
#define HAL_SWC_HASH_ID_FABRIC_LAG                  (3)


/*EPP hash engine for: packet generation during tunnel initialization*/
#define HAL_SWC_HASH_ID_MPLS_FLOW_LABEL             (0)
#define HAL_SWC_HASH_ID_MPLS_FLOW_LABEL_MSB         (1)
#define HAL_SWC_HASH_ID_MPLS_ENTROPY_LABEL          (2)
#define HAL_SWC_HASH_ID_MPLS_ENTROPY_LABEL_MSB      (3)

#define HAL_SWC_HASH_ID_L3T_IPV6_FLOW_LABEL         (0)
#define HAL_SWC_HASH_ID_L3T_IPV6_FLOW_LABEL_MSB     (1)
#define HAL_SWC_HASH_ID_VXLAN_UDP_SRC_PORT          (2)
#define HAL_SWC_HASH_ID_NVGRE_FLOW_ID               (3)

#define HAL_SWC_ILE_HASH_BANK_NUM                   (16)
#define HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK         (16*1024)

#if defined(CLX_EN_LIGHTNING)
#define HAL_SWC_ILE_TCAM_BANK_NUM                   (64)
#define HAL_SWC_ILE_TCAM_ENTRY_NUM                  (16*1024)
#elif defined(CLX_EN_DAWN)
#define HAL_SWC_ILE_TCAM_BANK_NUM                   (8)
#define HAL_SWC_ILE_TCAM_ENTRY_NUM                  (16*1024)
#else
#define HAL_SWC_ILE_TCAM_BANK_NUM                   (8)
#define HAL_SWC_ILE_TCAM_ENTRY_NUM                  (16*1024)
#endif

#define HAL_SWC_HASH_L2_FDB_REGION_MAX              (14 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L2_FDB_REGION_DEFAULT          (4 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L2_GROUP_REGION_DEFAULT        (1 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L3_128_REGION_DEFAULT          (1 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L3_64_REGION_DEFAULT           (1 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L3_NO_PREFIEX_DEFAULT          (6 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_SECURITY_REGION_DEFAULT        (1 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_FLOW_REGION_DEFAULT            (2 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_TCAM_L3_128_REGION_DEFAULT          (HAL_SWC_ILE_TCAM_ENTRY_NUM / 2)
#define HAL_SWC_TCAM_L3_64_REGION_DEFAULT           (HAL_SWC_ILE_TCAM_ENTRY_NUM / 2)

/*ILE TCAM bank define*/
#define HAL_SWC_ILE_TCAM_128_BMP(unit)      _hal_swc_cb[unit]._ile_tcam_128_bmp
#define HAL_SWC_ILE_TCAM_64_BMP(unit)       _hal_swc_cb[unit]._ile_tcam_64_bmp

#define HAL_SWC_EPG_2B          (2)
#define HAL_SWC_EPG_4B          (4)
#define HAL_SWC_EPG_6B          (6)
#define HAL_SWC_EPG_PLD_LEN     (128)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_SWC_CONST_EMI(__unit__, __idx__)  (PTR_HAL_CONST_INFO(__unit__, swc)->emi[__idx__])

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_SWC_WBDB_CFG_ID = 0,
    HAL_SWC_WBDB_CIM_ID,
    HAL_SWC_WBDB_OBJ_LAST
} HAL_SWC_WBDB_OBJ_TYPE_T;

typedef enum
{
    HAL_SWC_CAP_EMI_BANK_NUM = 0,
    HAL_SWC_CAP_EMI_NSH_BANK_BASE,
    HAL_SWC_CAP_EMI_PAGE_PER_BANK,
    HAL_SWC_CAP_EMI_ENTRY_PER_BANK,
    HAL_SWC_CAP_EMI_LAST
} HAL_SWC_CAP_EMI_TYPE_T;

typedef struct
{
    CLX_MAC_T dmac;
    CLX_MAC_T smac;

    UI16_T    tpid;
    UI32_T    pcp;
    UI32_T    dei;
    UI32_T    vid;

    UI32_T    ip;   /* user inputs sip&dip */
    CLX_IP_ADDR_T sip;
    CLX_IP_ADDR_T dip;

    UI32_T    len;
    UI32_T    num;
    CLX_PORT_SPEED_T speed;
    CLX_PORT_BITMAP_T pbm;

    UI8_T     pld[HAL_SWC_EPG_PLD_LEN];
    UI32_T    pld_len;

    UI8_T     fill;

} HAL_SWC_EPG_PKT_T;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
CLX_ERROR_NO_T
hal_swc_getIleBankType(
    const UI32_T            unit,
    const UI32_T            bank_num,
    const UI32_T            is_ile_hash,
    CLX_CFG_TYPE_T          *ptr_cfg_type);

CLX_ERROR_NO_T
hal_swc_getIleBankBitmap(
    const UI32_T            unit,
    const CLX_CFG_TYPE_T    cfg_type,
    UI32_T                  *ptr_bitmap);

/* FUNCTION NAME:  hal_swc_setHashConstant
 * PURPOSE:
 *      Set hash engine polynominal coefficients
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      count               -- Size (number of elements) of array pointed by ptr_hash_const
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHER         -- Config fail
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *      For IPP hash engines, SDK need 24 UI32_T constants.
 *      For EPP hash engines, SDK need 10 UI32_T constants.
 *
 */
CLX_ERROR_NO_T
hal_swc_setHashConstant(
    const UI32_T              unit,
    const CLX_SWC_HASH_TYPE_T hash_type,
    const UI32_T              count,
    const UI32_T              *ptr_hash_const);

/* FUNCTION NAME:   hal_swc_getHashConstant
 * PURPOSE:
 *      Get hash engine polynominal coefficients
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      count               -- Size (number of elements) of array pointed by ptr_hash_const
 *
 * OUTPUT:
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
hal_swc_getHashConstant(
    const UI32_T              unit,
    const CLX_SWC_HASH_TYPE_T hash_type,
    const UI32_T              count,
    UI32_T                    *ptr_hash_const);

/* FUNCTION NAME:   hal_swc_setHashConstantByKey
 * PURPOSE:
 *      Set hash engine polynominal coefficients by a specific key field
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      key                 -- Hash key of interest
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHER         -- Config fail
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
hal_swc_setHashConstantByKey(
    const UI32_T                  unit,
    const CLX_SWC_HASH_TYPE_T     hash_type,
    const CLX_SWC_HASH_KEY_TYPE_T key,
    const UI32_T                  *ptr_hash_const);

/* FUNCTION NAME:   hal_swc_getHashConstantByKey
 * PURPOSE:
 *      Get hash engine polynominal coefficients by a specific key field
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      key                 -- Hash key of interest
 *
 * OUTPUT:
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
hal_swc_getHashConstantByKey(
    const UI32_T                  unit,
    const CLX_SWC_HASH_TYPE_T     hash_type,
    const CLX_SWC_HASH_KEY_TYPE_T key,
    UI32_T                        *ptr_hash_const);

/* FUNCTION NAME:  hal_swc_init
 * PURPOSE:
 *      To initialize switch control module.
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *      CLX_E_OTHER     -- Init fail
 * NOTES:
 */
CLX_ERROR_NO_T
hal_swc_init(
    const UI32_T  unit);

/* FUNCTION NAME:  hal_swc_deinit
 * PURPOSE:
 *      To deinitialize switch control module.
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *      CLX_E_OTHER     -- Init fail
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_deinit(
    const UI32_T  unit);

/* FUNCTION NAME:   hal_swc_setProperty
 * PURPOSE:
 *      Set switch control property.
 * INPUT:
 *      unit            -- Device unit number
 *      property        -- Property type
 *      param0          -- First parameter
 *      param1          -- Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_setProperty(
    const UI32_T                unit,
    const CLX_SWC_PROPERTY_T    property,
    const UI32_T                param0,
    const UI32_T                param1);

/* FUNCTION NAME:   hal_swc_getProperty
 * PURPOSE:
 *      Get switch control property.
 * INPUT:
 *      unit            -- Device unit number
 *      property        -- Property type
 * OUTPUT:
 *      *ptr_param0     -- First parameter
 *      *ptr_param1     -- Second parameter
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_getProperty(
    const UI32_T                unit,
    const CLX_SWC_PROPERTY_T    property,
    UI32_T                      *ptr_param0,
    UI32_T                      *ptr_param1);


/* FUNCTION NAME:   hal_swc_getChipTemperature
 * PURPOSE:
 *      Get chip temperature.
 * INPUT:
 *      unit                -- Device unit number.
 * OUTPUT:
 *      ptr_temperature     -- Chip temperature
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_getChipTemperature(
    const UI32_T   unit,
    I32_T          *ptr_temperature);

/* FUNCTION NAME:   hal_swc_setHashKey
 * PURPOSE:
 *      set hash engine's hash key.
 * INPUT:
 *      unit            -- Device unit number
 *      hash_type       -- Hash type
 *      key_bitmap      -- Hash key bitmap
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_setHashKey(
    const UI32_T                    unit,
    const CLX_SWC_HASH_TYPE_T       hash_type,
    const CLX_SWC_HASH_KEY_BITMAP_T hash_key);

/* FUNCTION NAME:   hal_swc_getHashKey
 * PURPOSE:
 *      Get switch control property.
 * INPUT:
 *      unit            -- Device unit number
 *      hash_type       -- Hash type
 * OUTPUT:
 *      *ptr_key_bitmap -- Hash key bitmap
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_getHashKey(
    const UI32_T                    unit,
    const CLX_SWC_HASH_TYPE_T       hash_type,
    CLX_SWC_HASH_KEY_BITMAP_T       *ptr_key_bitmap);

/* FUNCTION NAME:   hal_swc_setTsValue
 * PURPOSE:
 *      Set timestamp value of system.
 * INPUT:
 *      unit                --  Chip id
 *      sec_hi              --  Bit[47:32] seconds for timestamp
 *      sec_low             --  Bit[31:0]  seconds for timestamp
 *      nsec                --  Bit[29:0]  nano seconds for timestamp
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_swc_setTsValue(
    const UI32_T                unit,
    UI16_T                      sec_hi,
    UI32_T                      sec_low,
    UI32_T                      nsec);

/* FUNCTION NAME:   hal_swc_getTsValue
 * PURPOSE:
 *      Get timestamp value of system.
 * INPUT:
 *      unit                --  Chip id
 *      ptr_sec_hi          --  Bit[47:32] seconds for timestamp
 *      ptr_sec_low         --  Bit[31:0]  seconds for timestamp
 *      ptr_nsec            --  Bit[29:0]  nano seconds for timestamp
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_swc_getTsValue(
    const UI32_T                unit,
    UI16_T                      *ptr_sec_hi,
    UI32_T                      *ptr_sec_low,
    UI32_T                      *ptr_nsec);

/* FUNCTION NAME:   hal_swc_setTsOffset
 * PURPOSE:
 *      Set timestamp offset.
 * INPUT:
 *      unit                --  Chip id
 *      nsec                --  Signed nano seconds for timestamp offset
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_swc_setTsOffset(
    const UI32_T                unit,
    const I32_T                 nsec);

/* FUNCTION NAME:   hal_swc_setSteering
 * PURPOSE:
 *      Set the configuration of egress view of steering.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_str_entry       -- Structure of egress steering
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_setSteering(
    const UI32_T                    unit,
    const CLX_SWC_STEERING_ENTRY_T  *ptr_str_entry);

/* FUNCTION NAME:   hal_swc_getSteering
 * PURPOSE:
 *      Get the configuration of egress view of steering.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      *ptr_str_entry      -- Setting of egress steering
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_getSteering(
    const UI32_T                    unit,
    CLX_SWC_STEERING_ENTRY_T        *ptr_str_entry);

/* FUNCTION NAME:   hal_swc_registerErrorCallback
 * PURPOSE:
 *      Register error callback function.
 * INPUT:
 *      unit                -- Device unit number
 *      error               -- error source type
 *      callback            -- The callback function of type CLX_SWC_ERROR_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_registerErrorCallback(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_SRC_T     error,
    const CLX_SWC_ERROR_FUNC_T    callback,
    void                          *ptr_cookie);

/* FUNCTION NAME:   hal_swc_deregisterErrorCallback
 * PURPOSE:
 *      Deregister error callback function.
 * INPUT:
 *      unit                -- Device unit number
 *      error               -- error source type
 *      callback            -- The callback function of type CLX_SWC_ERROR_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_deregisterErrorCallback(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_SRC_T     error,
    const CLX_SWC_ERROR_FUNC_T    callback,
    void                          *ptr_cookie);

void
hal_swc_notifyErrorCallback(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_SRC_T     error,
    const CLX_SWC_ERROR_INFO_T    *ptr_error_info);

/* FUNCTION NAME:   hal_swc_getDeviceInfo
 * PURPOSE:
 *      Get device information.
 * INPUT:
 *      unit                -- Device unit number
 *
 * OUTPUT:
 *      ptr_device_info     -- The device information
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_swc_getDeviceInfo(
    const UI32_T                unit,
    CLX_SWC_DEVICE_INFO_T       *ptr_device_info);

/* FUNCTION NAME:   hal_swc_getPortConfig
 * PURPOSE:
 *      Get port bitmap of current config.
  * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      ptr_port_config     -- type of CLX_SWC_PORT_CONFIG_T
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_swc_getPortConfig(
    const UI32_T            unit,
    CLX_SWC_PORT_CONFIG_T   *ptr_port_config);

/* FUNCTION NAME:   hal_swc_getCapacity
 * PURPOSE:
 *      Get resource capacity
 * INPUT:
 *      unit            -- Device unit number
 *      type            -- Resource type
 *      param           -- Parameter if necessary
 * OUTPUT:
 *      ptr_size        -- Size of capacity
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_getCapacity(
    const UI32_T unit,
    const CLX_SWC_RSRC_T type,
    const UI32_T param,
    UI32_T *ptr_size);

/* FUNCTION NAME:   hal_swc_getUsage
 * PURPOSE:
 *     Get resource usage.
 * INPUT:
 *      unit            -- Device unit number
 *      type            -- Resource type
 *      param           -- Parameter if necessary
 * OUTPUT:
 *      ptr_cnt         -- Count of usage
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_getUsage(
    const UI32_T         unit,
    const CLX_SWC_RSRC_T type,
    const UI32_T         param,
    UI32_T               *ptr_cnt);

/* FUNCTION NAME:   hal_swc_setCsoMode
 * PURPOSE:
 *      Set clock servo mode.
 * INPUT:
 *      unit                -- Device unit number
 *      mode                -- Clock servo mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_setCsoMode(
    const UI32_T                unit,
    const CLX_SWC_CSO_MODE_T    mode);

/* FUNCTION NAME:   hal_swc_getCsoMode
 * PURPOSE:
 *      Get clock servo mode.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      ptr_mode            -- Clock servo mode
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_getCsoMode(
    const UI32_T        unit,
    CLX_SWC_CSO_MODE_T  *ptr_mode);

/* FUNCTION NAME:   hal_swc_setException
 * PURPOSE:
 *      Set exceptions to drop or to CPU.
 * INPUT:
 *      unit                -- Device unit number
 *      enable              -- Enable or restore exceptions
 *      action              -- Drop or to CPU
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_setException(
    const UI32_T            unit,
    const UI32_T            enable,
    const CLX_FWD_ACTION_T  action);

/* FUNCTION NAME:   hal_swc_setTrapAll
 * PURPOSE:
 *      Trap all packets to CPU.
 * INPUT:
 *      unit                -- Device unit number
 *      enable              -- Enable or disable
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_setTrapAll(
    const UI32_T            unit,
    const UI32_T            enable);

/* FUNCTION NAME:   hal_swc_initEpgPkt
 * PURPOSE:
 *      Init EPG user packet before feeding user configuration
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_pkt             -- EPG user packet
 * OUTPUT:
 *      ptr_pkt             -- EPG user packet
 * RETURN:
 *      None
 * NOTES:
 *
 */
void
hal_swc_initEpgPkt(
    HAL_SWC_EPG_PKT_T *ptr_pkt);

/* FUNCTION NAME:   hal_swc_buildEpgBuf
 * PURPOSE:
 *      Build EPG hardware buffer from user packet
 * INPUT:
 *      ptr_pkt             -- EPG user packet
 *      pad                 -- 1-byte padding after packet header
 *      buf_len             -- length of EPG hardware buffer
 * OUTPUT:
 *      ptr_buf             -- EPG hardware buffer
 * RETURN:
 *      None
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_swc_buildEpgBuf(
    const HAL_SWC_EPG_PKT_T *ptr_pkt,
    const UI32_T            pad,
    const UI32_T            buf_len,
    UI8_T                   *ptr_buf);

#endif
