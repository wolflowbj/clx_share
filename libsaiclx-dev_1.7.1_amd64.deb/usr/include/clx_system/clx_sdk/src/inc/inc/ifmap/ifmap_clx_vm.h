/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   ifmap_clx_vm.h
 * PURPOSE:
 *      It provides user port to np port translation for VM API.
 * NOTES:
 */

#ifndef IFMAP_CLX_VM_H
#define IFMAP_CLX_VM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_vm.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   ifmap_clx_vm_createPort
 * PURPOSE:
 *      This API is used to create a VM port with
 *      port, vm id and vm tag type.
 * INPUT:
 *      unit          -- Device unit number
 *      user_port     -- Port or LAG port
 *      vm_id         -- VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 *      vm_tag_type   -- VM type
 * OUTPUT:
 *      ptr_vm_port   -- VM port
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_createPort(
    const UI32_T               unit,
    const CLX_PORT_T           user_port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_tag_type,
    CLX_PORT_T                 *ptr_vm_port);

/* FUNCTION NAME:   ifmap_clx_vm_getPort
 * PURPOSE:
 *      This API is used to get a VM port.
 * INPUT:
 *      unit        -- Device unit number
 *      user_port   -- Port or LAG port
 *      vm_id       -- VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 *      vm_tag_type -- VM type
 * OUTPUT:
 *      ptr_vm_port -- VM port
 * RETURN:
 *      CLX_E_OK              -- Operation success.
 *      CLX_E_BAD_PARAMETER   -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- VM port is not created.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getPort(
    const UI32_T               unit,
    const CLX_PORT_T           user_port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_tag_type,
    CLX_PORT_T                 *ptr_vm_port);

/* FUNCTION NAME:   ifmap_clx_vm_getKey
 * PURPOSE:
 *      This API is used to get keys of a VM port.
 * INPUT:
 *      unit            -- Device unit number
 *      vm_port         -- VM port
 * OUTPUT:
 *      ptr_user_port   -- Port or LAG port
 *      ptr_vm_id       -- VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 *      ptr_vm_tag_type -- VM type
 * RETURN:
 *      CLX_E_OK              -- Operation success.
 *      CLX_E_BAD_PARAMETER   -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- VM port is not created or is destroyed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getKey(
    const UI32_T         unit,
    const CLX_PORT_T     vm_port,
    CLX_PORT_T           *ptr_user_port,
    CLX_VM_ID_T          *ptr_vm_id,
    CLX_VM_TAG_TYPE_T    *ptr_vm_tag_type);

/* FUNCTION NAME:   ifmap_clx_vm_setUpstreamPort
 * PURPOSE:
 *      This API is used to set the associated upstream port of a downstream port.
 * INPUT:
 *      unit                 -- Device unit number
 *      user_downstream_port -- Downstream port (port or VM port)
 *      user_upstream_port   -- Upstream port (port or LAG port)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_setUpstreamPort(
    const UI32_T        unit,
    const CLX_PORT_T    user_downstream_port,
    const CLX_PORT_T    user_upstream_port);

/* FUNCTION NAME:   ifmap_clx_vm_resetUpstreamPort
 * PURPOSE:
 *      This API is used to reset the associated upstream port of a downstream port.
 * INPUT:
 *      unit                 -- Device unit number
 *      user_downstream_port -- Downstream port (port or VM port)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_resetUpstreamPort(
    const UI32_T        unit,
    const CLX_PORT_T    user_downstream_port);

/* FUNCTION NAME:   ifmap_clx_vm_getUpstreamPort
 * PURPOSE:
 *      This API is used to get the associated upstream port of the downstream port.
 * INPUT:
 *      unit                   -- Device unit number
 *      user_downstream_port   -- Downstream port (port or VM port)
 * OUTPUT:
 *      ptr_user_upstream_port -- Upstream port (port or LAG port)
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getUpstreamPort(
    const UI32_T        unit,
    const CLX_PORT_T    user_downstream_port,
    CLX_PORT_T          *ptr_user_upstream_port);

/* FUNCTION NAME:   ifmap_clx_vm_setPortProperty
 * PURPOSE:
 *      This API is used to set port property to provide VM function for the port.
 * INPUT:
 *      unit      -- Device unit number
 *      user_port -- port
 *      ptr_prty  -- VM related port property
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_setPortProperty(
    const UI32_T                unit,
    const CLX_PORT_T            user_port,
    const CLX_VM_PORT_PRTY_T    *ptr_prty);

/* FUNCTION NAME:   ifmap_clx_vm_getPortProperty
 * PURPOSE:
 *      This API is used to get port property which providing VM function for the port.
 * INPUT:
 *      unit      -- Device unit number
 *      user_port -- port
 * OUTPUT:
 *      ptr_prty  -- VM related port property
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getPortProperty(
    const UI32_T          unit,
    const CLX_PORT_T      user_port,
    CLX_VM_PORT_PRTY_T    *ptr_prty);

/* FUNCTION NAME:   ifmap_clx_vm_pe_addUcastAddr
 * PURPOSE:
 *      This API is used to add a point-to-point e_channel/vif downstream entry
 *      for 802.1BR and NIV in PE/IV switch.
 * INPUT:
 *      unit          -- Device unit number
 *      ptr_user_addr -- Unicast entry in PE/IV, including
 *                       vm_id, vm_tag_type, source and destination port information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_addUcastAddr(
    const UI32_T                    unit,
    const CLX_VM_PE_UCAST_ADDR_T    *ptr_user_addr);

/* FUNCTION NAME:   ifmap_clx_vm_pe_delUcastAddr
 * PURPOSE:
 *      This API is used to delete a point-to-point e_channel/vif downstream entry
 *      for 802.1BR and NIV in PE/IV switch.
 * INPUT:
 *      unit          -- Device unit number
 *      ptr_user_addr -- Unicast entry in PE/IV, including source port, vm_id and vm_tag_type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_delUcastAddr(
    const UI32_T                    unit,
    const CLX_VM_PE_UCAST_ADDR_T    *ptr_user_addr);

/* FUNCTION NAME:   ifmap_clx_vm_pe_getUcastAddr
 * PURPOSE:
 *      This API is used to get a point-to-point e_channel/vif downstream entry
 *      for 802.1BR and NIV in PE/IV switch.
 * INPUT:
 *      unit          -- Device unit number
 *      ptr_user_addr -- Unicast entry in PE/IV, including source port, vm_id and vm_tag_type
 * OUTPUT:
 *      ptr_user_addr -- Unicast entry in PE/IV, including destination port information
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_getUcastAddr(
    const UI32_T              unit,
    CLX_VM_PE_UCAST_ADDR_T    *ptr_user_addr);

/* FUNCTION NAME:   ifmap_clx_vm_pe_addMcastAddr
 * PURPOSE:
 *      This API is used to add a point-to-multi-point e_channel/vif downstream entry
 *      for 802.1BR and NIV in PE/IV switch.
 * INPUT:
 *      unit          -- Device unit number
 *      ptr_user_addr -- Multicast entry in PE/IV, including
 *                       vm_id, vm_tag_type, source port and destination pbm/group information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_addMcastAddr(
    const UI32_T                    unit,
    const CLX_VM_PE_MCAST_ADDR_T    *ptr_user_addr);

/* FUNCTION NAME:   ifmap_clx_vm_pe_delMcastAddr
 * PURPOSE:
 *      This API is used to delete a point-to-multi-point e_channel/vif downstream entry
 *      for 802.1BR and NIV in PE/IV switch.
 * INPUT:
 *      unit          -- Device unit number
 *      ptr_user_addr -- Multicast entry in PE/IV, including source port, vm_id and vm_tag_type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_delMcastAddr(
    const UI32_T                    unit,
    const CLX_VM_PE_MCAST_ADDR_T    *ptr_user_addr);

/* FUNCTION NAME:   ifmap_clx_vm_pe_getMcastAddr
 * PURPOSE:
 *      This API is used to get point-to-multi-point e_channel/vif downstream entry
 *      for 802.1BR and NIV in PE/IV switch.
 * INPUT:
 *      unit          -- Device unit number.
 *      ptr_user_addr -- Multicast entry in PE/IV, including source port, vm_id and vm_tag_type
 * OUTPUT:
 *      ptr_user_addr -- Multicast entry in PE/IV, including destination pbm/group information
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_getMcastAddr(
    const UI32_T              unit,
    CLX_VM_PE_MCAST_ADDR_T    *ptr_user_addr);

/* FUNCTION NAME:   ifmap_clx_vm_addMcastIntfProperty
 * PURPOSE:
 *      This API is used to add interface of a port combined with multicast vm id, and
 *      set related interface properties.
 * INPUT:
 *      unit          -- Device unit number
 *      user_port     -- port
 *      vm_id         -- 1BR p2mp or NIV vif-list VM id
 *      vm_type       -- VM type
 *      ptr_property  -- Interface property
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_addMcastIntfProperty(
    const UI32_T                      unit,
    const CLX_PORT_T                  user_port,
    const CLX_VM_ID_T                 vm_id,
    const CLX_VM_TAG_TYPE_T           vm_type,
    const CLX_PORT_INTF_PROPERTY_T    *ptr_property);

/* FUNCTION NAME:   ifmap_clx_vm_delMcastIntfProperty
 * PURPOSE:
 *      This API is used to delete interface of a port combined with multicast vm id.
 * INPUT:
 *      unit      -- Device unit number
 *      user_port -- port
 *      vm_id     -- 1BR p2mp or NIV vif-list VM id
 *      vm_type   -- VM type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success.
 *      CLX_E_BAD_PARAMETER   -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- Entry not exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_delMcastIntfProperty(
    const UI32_T               unit,
    const CLX_PORT_T           user_port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_type);

/* FUNCTION NAME:   ifmap_clx_vm_getMcastIntfProperty
 * PURPOSE:
 *      This API is used to get interface properties of a port combined with multicast vm id.
 * INPUT:
 *      unit          -- Device unit number
 *      user_port          -- port
 *      vm_id         -- 1BR p2mp or NIV vif-list VM id
 *      vm_type       -- VM type
 * OUTPUT:
 *      ptr_property  -- Interface property
 * RETURN:
 *      CLX_E_OK              -- Operation success.
 *      CLX_E_BAD_PARAMETER   -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- Entry not exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getMcastIntfProperty(
    const UI32_T                unit,
    const CLX_PORT_T            user_port,
    const CLX_VM_ID_T           vm_id,
    const CLX_VM_TAG_TYPE_T     vm_type,
    CLX_PORT_INTF_PROPERTY_T    *ptr_property);

/* FUNCTION NAME:   ifmap_clx_vm_addMcastSegService
 * PURPOSE:
 *      This API is used to add service of a port combined multicast vm-id and vlan.
 *      1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *      2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 * INPUT:
 *      unit        -- Device unit number
 *      user_port   -- Port
 *      vm_id       -- 1BR p2mp or NIV vif-list VM id
 *      vm_type     -- VM type
 *      seg0        -- Segment parameter 0
 *      seg1        -- Segment parameter 1
 *      ptr_seg_srv -- Service
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_addMcastSegService(
    const UI32_T                unit,
    const CLX_PORT_T            user_port,
    const CLX_VM_ID_T           vm_id,
    const CLX_VM_TAG_TYPE_T     vm_type,
    const UI32_T                seg0,
    const UI32_T                seg1,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   ifmap_clx_vm_delMcastSegService
 * PURPOSE:
 *      This API is used to delete service of a port combined multicast vm-id and vlan.
 *      1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *      2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 * INPUT:
 *      unit        -- Device unit number
 *      user_port   -- Port
 *      vm_id       -- 1BR p2mp or NIV vif-list VM id
 *      vm_type     -- VM type
 *      seg0        -- Segment parameter 0
 *      seg1        -- Segment parameter 1
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_delMcastSegService(
    const UI32_T               unit,
    const CLX_PORT_T           user_port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_type,
    const UI32_T               seg0,
    const UI32_T               seg1);

/* FUNCTION NAME:   ifmap_clx_vm_getMcastSegService
 * PURPOSE:
 *      This API is used to get service of a port combined multicast vm-id and vlan.
 *      1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *      2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 * INPUT:
 *      unit        -- Device unit number
 *      user_port   -- Port
 *      vm_id       -- 1BR p2mp or NIV vif-list VM id
 *      vm_type     -- VM type
 *      seg0        -- Segment parameter 0
 *      seg1        -- Segment parameter 1
 * OUTPUT:
 *      ptr_seg_srv -- Service
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getMcastSegService(
    const UI32_T               unit,
    const CLX_PORT_T           user_port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_type,
    const UI32_T               seg0,
    const UI32_T               seg1,
    CLX_PORT_SEG_SRV_T         *ptr_seg_srv);

#endif /* End of #ifndef IFMAP_CLX_VM_H */
