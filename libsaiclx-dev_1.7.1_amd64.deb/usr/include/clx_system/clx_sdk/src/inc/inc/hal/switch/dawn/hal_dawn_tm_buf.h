/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_tm_buf.h
 * PURPOSE:
 *      It provides hal traffic management module API.
 * NOTES:
 *
 *
 */

#ifndef HAL_DAWN_TM_BUF_H
#define HAL_DAWN_TM_BUF_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_tm.h>
#include <hal/common/hal.h>
#include <osal/osal.h>
#include <hal/common/hal_tbl.h>
#include <hal/common/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_NON_TCP_GREEN         (32)
#define HAL_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_NON_TCP_RED           (32)
#define HAL_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_NON_TCP_YELLOW        (32)
#define HAL_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_GREEN             (32)
#define HAL_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_RED               (32)
#define HAL_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_YELLOW            (32)
#define HAL_DAWN_MAX_NUM_OF_TM_DCTCP_THD_G_PROFILE                       (32)

#define HAL_DAWN_TM_WRED_PROFILE_CONFIG_MAX_THRESHOLD_WIDTH              (16)
#define HAL_DAWN_TM_WRED_PROFILE_CONFIG_MANTISSA_WIDTH                   (10)
#define HAL_DAWN_TM_WRED_PROFILE_CONFIG_EXPONENT_WIDTH                   (6)


#define HAL_DAWN_TM_BUF_FP_PORT_MAX_NUM       (128)
#define HAL_DAWN_TM_BUF_FC_SC                 (7)

#define HAL_DAWN_TM_ADM_AIP_PLANE_NUM            (HAL_DAWN_TM_ADM_AIP_PLANE1_IDX - HAL_DAWN_TM_ADM_AIP_PLANE0_IDX)
#define HAL_DAWN_TM_ADM_AIP_PLANE0_IDX           (0)
#define HAL_DAWN_TM_ADM_AIP_PLANE1_IDX           (36)
#define HAL_DAWN_TM_ADM_AIP_PLANE2_IDX           (72)
#define HAL_DAWN_TM_ADM_AIP_PLANE3_IDX           (108)

#define HAL_DAWN_TM_ENB_FP_NUM                   (36)
#define HAL_DAWN_TM_ADM_FP_FP_ENTRY              (144)

#define HAL_DAWN_TM_IA_FP_NUM                    (32)
#define HAL_DAWN_TM_REP_NUM                      (2)
#define HAL_DAWN_TM_IA_CPI_NUM                   (1)
#define HAL_DAWN_TM_IA_CPU_NUM                   (1)
#define HAL_DAWN_TM_IA_NON_FP_NUM                (HAL_DAWN_TM_REP_NUM + HAL_DAWN_TM_IA_CPI_NUM + HAL_DAWN_TM_IA_CPU_NUM)
#define HAL_DAWN_TM_EA_FP_NUM                    (17)
#define HAL_DAWN_TM_MEA_FP_NUM                   (HAL_DAWN_TM_DEB_FP_NUM + HAL_DAWN_TM_REP_NUM)
#define HAL_DAWN_TM_DEB_FP_NUM                   (32)
#define HAL_DAWN_TM_AQM_FP_BIN_NUM               (64)
#define HAL_DAWN_TM_IOS_SLC_FP_PLANE_NUM         (16)

#define HAL_DAWN_TM_IOS_SLC_CPI_IDX              (1)

#define HAL_DAWN_TM_IA_RECIR_P_IDX_0             (HAL_DAWN_TM_IA_FP_NUM)
#define HAL_DAWN_TM_IA_RECIR_P_IDX_1             (HAL_DAWN_TM_IA_FP_NUM + 1)
#define HAL_DAWN_TM_IA_CPI_P_IDX                 (HAL_DAWN_TM_IA_FP_NUM + HAL_DAWN_TM_REP_NUM)
#define HAL_DAWN_TM_IA_CPU_P_IDX                 (HAL_DAWN_TM_IA_FP_NUM + HAL_DAWN_TM_REP_NUM + HAL_DAWN_TM_IA_CPI_NUM)

#define HAL_DAWN_TM_IA_CPU_P_SUB_INST_IDX        (3)
#define HAL_DAWN_TM_IA_CPU_P_INST_IDX            (HAL_DAWN_TM_IA_P_PLANE_NUM - 1)

#define HAL_DAWN_TM_ADM_P_SUB_INST_IDX           (HAL_DAWN_TM_ADM_SLICE_NUM - 1)
#define HAL_DAWN_TM_ADM_P_INST_IDX               (HAL_DAWN_TM_ADM_PLANE_NUM - 1)


#define HAL_DAWN_TM_IA_P_PLANE_NUM               (1)
#define HAL_DAWN_TM_IA_P_SLICE_NUM               (4)
#define HAL_DAWN_TM_ADM_SLICE_NUM                (1)
#define HAL_DAWN_TM_ADM_PLANE_NUM                (1)
#define HAL_DAWN_TM_AQM_PLANE_NUM                (1)
#define HAL_DAWN_TM_AQM_SLICE_NUM                (1)
#define HAL_DAWN_TM_IOS_PLANE_NUM                (2)
#define HAL_DAWN_TM_IOS_SLICE_NUM                (1)
#define HAL_DAWN_TM_DEB_PLANE_NUM                (2)
#define HAL_DAWN_TM_DEB_SLICE_NUM                (1)
#define HAL_DAWN_TM_MIA_SLICE_NUM                (2)
#define HAL_DAWN_TM_MEA_P_SLICE_NUM              (2)
#define HAL_DAWN_TM_MEA_G_SLICE_NUM              (1)
#define HAL_DAWN_TM_MEA_G_GROUP_NUM              (4)

#define HAL_DAWN_TM_MAX_PFC_SC_NUM               (2)

#define HAL_DAWN_TM_MEA_P_ENTRY_NUM              \
(HAL_DAWN_TM_MEA_FP_NUM * (HAL_DAWN_TM_MULTICAST_QUEUE_NUM))


#define HAL_DAWN_TM_EA_RECIR_P_IDX_0             (HAL_DAWN_TM_EA_FP_NUM - HAL_DAWN_TM_REP_NUM)
#define HAL_DAWN_TM_EA_RECIR_P_IDX_1             (HAL_DAWN_TM_EA_FP_NUM - HAL_DAWN_TM_REP_NUM + 1)
#define HAL_DAWN_TM_EA_RECIR_S_IDX_1             (1)
#define HAL_DAWN_TM_EA_RECIR_S_IDX_3             (3)


#define HAL_DAWN_TM_IOS_IA_SC2PCP_NUM            (128)
#define HAL_DAWN_TM_PCP_NUM                      (8)

#define HAL_DAWN_TM_EA_PLANE_FP_NUM              (HAL_DAWN_TM_BUF_FP_PORT_MAX_NUM / 2)

#define HAL_DAWN_TM_EA_CMQ_CPU_NUM               (HAL_DAWN_TM_CPU_QUEUE_NUM)
#define HAL_DAWN_TM_EA_CMQ_CPI_NUM               (HAL_DAWN_TM_CPI_QUEUE_NUM)
#define HAL_DAWN_TM_EA_CMQ_MIR_NUM               (8)

#define HAL_DAWN_TM_EA_CMQ_OFFSET_CPU            (0)
#define HAL_DAWN_TM_EA_CMQ_OFFSET_CPI0           (HAL_DAWN_TM_EA_CMQ_OFFSET_CPU + HAL_DAWN_TM_EA_CMQ_CPU_NUM)
#define HAL_DAWN_TM_EA_CMQ_OFFSET_CPI1           (HAL_DAWN_TM_EA_CMQ_OFFSET_CPI0 + HAL_DAWN_TM_EA_CMQ_CPI_NUM)
#define HAL_DAWN_TM_EA_CMQ_OFFSET_IMIR           (HAL_DAWN_TM_EA_CMQ_OFFSET_CPI1 + HAL_DAWN_TM_EA_CMQ_CPI_NUM)
#define HAL_DAWN_TM_EA_CMQ_OFFSET_EMIR           (HAL_DAWN_TM_EA_CMQ_OFFSET_IMIR + HAL_DAWN_TM_EA_CMQ_MIR_NUM)

#define HAL_DAWN_TM_ADM_SC_NUM                   (8)
#define HAL_DAWN_TM_EA_Q_NUM                     (HAL_DAWN_TM_UNICAST_QUEUE_NUM + HAL_DAWN_TM_MULTICAST_QUEUE_NUM)

#define HAL_DAWN_TM_SC_BITMAP                    (0xFF)
#define HAL_DAWN_TM_IA_HGAP_EN_BITMAP            (HAL_DAWN_TM_SC_BITMAP)

#define HAL_DAWN_TM_IA_MAX_DYNAMIC_TH            (128)
#define HAL_DAWN_TM_EA_MAX_DYNAMIC_TH            (16)
#define HAL_DAWN_TM_EA_MC_MAX_DYNAMIC_TH         (2)

#define HAL_DAWN_TM_IA_XON_TH_100G               (350)
#define HAL_DAWN_TM_IA_XON_TH_50G                (236)
#define HAL_DAWN_TM_IA_XON_TH_40G                (212)
#define HAL_DAWN_TM_IA_XON_TH_25G                (184)
#define HAL_DAWN_TM_IA_XON_TH_10G                (144)

#define HAL_DAWN_TM_CELL_SIZE                    (224)

#define HAL_DAWN_TM_MTU                          ((22 * 1024 + 9) / 10)
#define HAL_DAWN_TM_GAP                          (2 * HAL_DAWN_TM_MTU / HAL_DAWN_TM_CELL_SIZE)
#define HAL_DAWN_TM_IA_XOFF_TH_100G              (HAL_DAWN_TM_IA_XON_TH_100G + HAL_DAWN_TM_GAP)
#define HAL_DAWN_TM_IA_XOFF_TH_50G               (HAL_DAWN_TM_IA_XON_TH_50G + HAL_DAWN_TM_GAP)
#define HAL_DAWN_TM_IA_XOFF_TH_40G               (HAL_DAWN_TM_IA_XON_TH_40G + HAL_DAWN_TM_GAP)
#define HAL_DAWN_TM_IA_XOFF_TH_25G               (HAL_DAWN_TM_IA_XON_TH_25G + HAL_DAWN_TM_GAP)
#define HAL_DAWN_TM_IA_XOFF_TH_10G               (HAL_DAWN_TM_IA_XON_TH_10G + HAL_DAWN_TM_GAP)

#define HAL_DAWN_TM_IA_MAX_TH_100G               (HAL_DAWN_TM_IA_XOFF_TH_100G - HAL_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)
#define HAL_DAWN_TM_IA_MAX_TH_50G                (HAL_DAWN_TM_IA_XOFF_TH_50G - HAL_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)
#define HAL_DAWN_TM_IA_MAX_TH_40G                (HAL_DAWN_TM_IA_XOFF_TH_40G - HAL_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)
#define HAL_DAWN_TM_IA_MAX_TH_25G                (HAL_DAWN_TM_IA_XOFF_TH_25G - HAL_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)
#define HAL_DAWN_TM_IA_MAX_TH_10G                (HAL_DAWN_TM_IA_XOFF_TH_10G - HAL_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)

#define HAL_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF       (0)
#define HAL_DAWN_TM_IA_G_MIN_RESERV_POOL         (2 * HAL_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF \
                                                * HAL_DAWN_TM_BUF_FP_PORT_MAX_NUM)


#define HAL_DAWN_TM_MCA_UNIT                     (2)
#define HAL_DAWN_TM_IEA_UNIT                     (1)

#define HAL_DAWN_TM_IA_G_CP_POOL                 (0)
#define HAL_DAWN_TM_IA_G_CP_ALLOCATE             (26)

#define HAL_DAWN_TM_EA_CMQ_NUM                   (80)
#define HAL_DAWN_TM_EA_CMQ_TH                    (46)
#define HAL_DAWN_TM_EA_G_CM_TH                   (1024)
#define HAL_DAWN_TM_EA_G_STR_TH                  (128)
#define HAL_DAWN_TM_EA_G_CM_POOL                 (HAL_DAWN_TM_EA_CMQ_NUM * HAL_DAWN_TM_EA_CMQ_TH + HAL_DAWN_TM_EA_G_CM_TH \
                                                + HAL_DAWN_TM_EA_G_STR_TH)


#define HAL_DAWN_TM_IEA_G_MSC_MIN_TH             (6000)

#define HAL_DAWN_TM_PERCNTAGE                    (100)
#define HAL_DAWN_TM_IEA_Q_MIN_CEILING            (0xFFFF)
#define HAL_DAWN_TM_IEA_Q_MIN                    (16)
#define HAL_DAWN_TM_EA_Q_MIN                     (16)
#define HAL_DAWN_TM_IEA_Q_MIN_100G               (HAL_DAWN_TM_IEA_Q_MIN)
#define HAL_DAWN_TM_EA_Q_MIN_100G                (50)


#define HAL_DAWN_TM_G_MARGIN                     (22856)
#define HAL_DAWN_TM_EA_G_MIN_RESERV_POOL         (0)
#define HAL_DAWN_TM_IEA_G_MIN_RESERV_POOL        (0)

#define HAL_DAWN_TM_EA_GS_MC_POOL                (11200)


#define HAL_DAWN_TM_MIA_MCB_POOL                 (32 * 1024)
#define HAL_DAWN_TM_MIA_MCB_Q_MIN_TH             (HAL_DAWN_TM_IEA_Q_MIN + 50)
#define HAL_DAWN_TM_MIA_MCB_G_MIN_TH             (HAL_DAWN_TM_MIA_MCB_Q_MIN_TH * HAL_DAWN_TM_EA_PLANE_FP_NUM * 8 / 2)
#define HAL_DAWN_TM_MIA_MCB_G_DROP_ON            (HAL_DAWN_TM_MIA_MCB_POOL - HAL_DAWN_TM_MIA_MCB_G_MIN_TH)

#define HAL_DAWN_TM_MIA_CPB_POOL                 (8 * 1024)
#define HAL_DAWN_TM_MIA_CPB_Q_MIN_TH             (100)
#define HAL_DAWN_TM_MIA_CPB_G_MIN_TH             (HAL_DAWN_TM_MIA_CPB_Q_MIN_TH * 8)
#define HAL_DAWN_TM_MIA_CPB_G_DROP_ON            (HAL_DAWN_TM_MIA_CPB_POOL - HAL_DAWN_TM_MIA_CPB_G_MIN_TH)
#define HAL_DAWN_TM_MIA_CPB_Q_MAX_TH             (HAL_DAWN_TM_MIA_CPB_G_DROP_ON)

#define HAL_DAWN_TM_MIA_MRB_POOL                 (8 * 1024)
#define HAL_DAWN_TM_MIA_MRB_Q_MIN_TH             (100)
#define HAL_DAWN_TM_MIA_MRB_G_MIN_TH             (HAL_DAWN_TM_MIA_MRB_Q_MIN_TH * 2)
#define HAL_DAWN_TM_MIA_MRB_G_DROP_ON            (HAL_DAWN_TM_MIA_MRB_POOL - HAL_DAWN_TM_MIA_MRB_G_MIN_TH)
#define HAL_DAWN_TM_MIA_MRB_Q_MAX_TH             (HAL_DAWN_TM_MIA_MRB_G_DROP_ON)

#define HAL_DAWN_TM_MEA_CM_POOL                  (152 * 1024 / 10)
#define HAL_DAWN_TM_MEA_CM_Q_MIN_TH              (300)
#define HAL_DAWN_TM_MEA_CM_G_MIN_TH              (HAL_DAWN_TM_MEA_CM_Q_MIN_TH * 24)
#define HAL_DAWN_TM_MEA_CM_G_DROP_ON             (HAL_DAWN_TM_MEA_CM_POOL - HAL_DAWN_TM_MEA_CM_G_MIN_TH)
#define HAL_DAWN_TM_MEA_CM_Q_MAX_TH              (HAL_DAWN_TM_MEA_CM_G_DROP_ON)

#define HAL_DAWN_TM_MEA_MCQ_POOL                 (64 * 1024)
#define HAL_DAWN_TM_MEA_MCQ_Q_MIN_TH             (300)
#define HAL_DAWN_TM_MEA_MCQ_G_MIN_TH             (HAL_DAWN_TM_MEA_MCQ_Q_MIN_TH * HAL_DAWN_TM_EA_PLANE_FP_NUM * 8 / 4)
#define HAL_DAWN_TM_MEA_MCQ_G_DROP_ON            (HAL_DAWN_TM_MEA_MCQ_POOL - HAL_DAWN_TM_MEA_CM_POOL \
                                                - HAL_DAWN_TM_MEA_MCQ_G_MIN_TH)



/* IA per port */
#define HAL_DAWN_TM_IA_PORT_MIN_THD_DEF          (HAL_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)

/* max value, Limit by HW design. */
#define HAL_DAWN_TM_IA_MAX_DYNAMIC_VALUE         (12)
#define HAL_DAWN_TM_IA_MAX_DYNAMIC_VALUE_OFFSET  (0)
#define HAL_DAWN_TM_EA_MAX_DYNAMIC_VALUE         (12)
#define HAL_DAWN_TM_EA_MAX_DYNAMIC_VALUE_OFFSET  (0)


#define HAL_DAWN_TM_WRED_PROFILE_SW_NUM          (HAL_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_GREEN)

#define HAL_DAWN_TM_DCTCP_PROFILE_SW_NUM         (HAL_DAWN_MAX_NUM_OF_TM_DCTCP_THD_G_PROFILE)

/* WRED SMDP */
#define HAL_DAWN_TM_UI16_WIDTH                   (16)
#define HAL_DAWN_TM_UI16_MAX_VALUE               ((1U << (HAL_DAWN_TM_UI16_WIDTH)) - 1)
#define HAL_DAWN_TM_WRED_MAX_EXPONENT_SIGN_BIT   (1U << ((HAL_DAWN_TM_WRED_PROFILE_CONFIG_EXPONENT_WIDTH) - 1))
#define HAL_DAWN_TM_WRED_MAX_EXPONENT_VALUE      ((1U << ((HAL_DAWN_TM_WRED_PROFILE_CONFIG_EXPONENT_WIDTH) \
                                                - 1)) - 1)
#define HAL_DAWN_TM_WRED_MAX_MANTISSA_VALUE      ((1U << (HAL_DAWN_TM_WRED_PROFILE_CONFIG_MANTISSA_WIDTH)) - 1)
#define HAL_DAWN_TM_UI16_TO_MANTISSA_SHIFT       (HAL_DAWN_TM_UI16_WIDTH \
                                                - (HAL_DAWN_TM_WRED_PROFILE_CONFIG_MANTISSA_WIDTH))

#define HAL_DAWN_TM_WRED_PROFILE_MAX_DROP_RATE   (100)
#define HAL_DAWN_TM_WRED_Q_WEIGHT_VALUE_SW_MAX   (10000)
#define HAL_DAWN_TM_WRED_Q_WEIGHT_VALUE_HW_MAX   (7) /* weight min = 1/2^HAL_DAWN_TM_WRED_Q_WEIGHT_VALUE_HW_MAX */


#define HAL_DAWN_TM_WRED_PROFILE_ID_MAX          (HAL_DAWN_TM_WRED_PROFILE_SW_NUM - 1)
#define HAL_DAWN_TM_DCTCP_PROFILE_ID_MAX         (HAL_DAWN_TM_DCTCP_PROFILE_SW_NUM - 1)

#define HAL_DAWN_TM_WRED_PF_MAX_DROP             (100)

/* DCTCP */
#define HAL_DAWN_TM_DCTCP_PF_TH_G                (0)
#define HAL_DAWN_TM_DCTCP_PF_TH_Y                (16)
#define HAL_DAWN_TM_DCTCP_PF_TH_R                (32)

typedef enum
{
    HAL_DAWN_TM_TYPE_ING  = 0,
    HAL_DAWN_TM_TYPE_EGR  = 1,
    HAL_DAWN_TM_TYPE_LAST
} HAL_DAWN_TM_TYPE_T;


typedef enum
{
    HAL_DAWN_TM_EA_CMP_CPU  = 0,
    HAL_DAWN_TM_EA_CMP_CPI0  = 1,
    HAL_DAWN_TM_EA_CMP_CPI1  = 2,
    HAL_DAWN_TM_EA_CMP_IMIR  = 3,
    HAL_DAWN_TM_EA_CMP_EMIR  = 4,
    HAL_DAWN_TM_EA_CMP_LAST
} HAL_DAWN_TM_EA_CMP_T;

typedef enum
{
    HAL_DAWN_TM_IA_P_FP      = 0,
    HAL_DAWN_TM_IA_P_CPI0    = 1,
    HAL_DAWN_TM_IA_P_CPI1    = 2,
    HAL_DAWN_TM_IA_P_IMIR    = 3,
    HAL_DAWN_TM_IA_P_EMIR    = 4,
    HAL_DAWN_TM_EA_P_LAST
} HAL_DAWN_TM_IA_P_T;



typedef enum
{
    HAL_DAWN_TM_ADM_SC_TYPE_LOSSY    = 0x0,
    HAL_DAWN_TM_ADM_SC_TYPE_LOSSLESS = 0x2,
    HAL_DAWN_TM_ADM_SC_TYPE_CTRL     = 0x3,
    HAL_DAWN_TM_ADM_SC_TYPE_LAST
} HAL_DAWN_TM_ADM_SC_TYPE_T;


/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_DAWN_TM_HANDLER_ID_GET(handler, id) do {                   \
        (id) = ((handler) & ((1U << HAL_DAWN_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while(0)


/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_DAWN_TM_BUF_RELEASE_NONE           = 0,
    HAL_DAWN_TM_BUF_RELEASE_SEMAPHORE      = (1U << 0),
    HAL_DAWN_TM_BUF_RELEASE_RESOURCE_1     = (1U << 1),
    HAL_DAWN_TM_BUF_RELEASE_RESOURCE_2     = (1U << 2),
    HAL_DAWN_TM_BUF_RELEASE_LAST           = (1U << 3)
} HAL_DAWN_TM_BUF_RELEASE_ACTION_T;


/* HAL layer API structure */
typedef struct HAL_DAWN_TM_WRED_ENTRY_HW_S {
    UI32_T hw_min;
    UI32_T hw_max;
    UI32_T hw_mantissa;
    UI32_T hw_exponent;
} HAL_DAWN_TM_WRED_ENTRY_HW_T;

typedef struct HAL_DAWN_TM_DCTCP_PROFILE_HW_S {
    UI32_T hw_threshold[CLX_COLOR_LAST];
} HAL_DAWN_TM_DCTCP_PROFILE_HW_T;


/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_dawn_tm_buf_initRsrc
 * PURPOSE:
 *      The function is used to init TM buffer management HW & SW DB
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_initRsrc(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_dawn_tm_buf_deinitRsrc
 * PURPOSE:
 *      The function is used to deinit TM buffer management HW & SW DB
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_deinitRsrc(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_dawn_tm_buf_initCfg
 * PURPOSE:
 *      The function is used to init TM buffer management configuration
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_initCfg(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_dawn_tm_buf_deinitCfg
 * PURPOSE:
 *      The function is used to deinit TM buffer management configuration
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_deinitCfg(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_dawn_tm_buf_setFlowCtrlMode
 * PURPOSE:
 *      The function is used to set flow control mode.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      mode             -- flow control mode(lossy, FC, PFC)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setFlowCtrlMode(
    const UI32_T                            unit,
    const UI32_T                            port,
    const HAL_TM_FC_T                       mode);

/* FUNCTION NAME: hal_dawn_tm_buf_getFlowCtrlMode
 * PURPOSE:
 *      The function is used to get flow control mode.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pcp              -- (Optional) PFC pcp
 * OUTPUT:
 *      ptr_mode         -- flow control mode(lossy, FC, PFC)
 *      ptr_pfc_tx_state -- (Optional) PFC TX state
 *      ptr_pfc_rx_state -- (Optional) PFC RX state
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getFlowCtrlMode(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pcp,
    HAL_TM_FC_T                             *ptr_mode,
    BOOL_T                                  *ptr_pfc_tx_state,
    BOOL_T                                  *ptr_pfc_rx_state);

/* FUNCTION NAME: hal_dawn_tm_buf_setIgrBufPcpThreshold
 * PURPOSE:
 *      The function is used to set ingress buffer per pcp thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pcp              -- pcp value.
 *      ptr_entry        -- the entry which the user want to set.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setIgrBufPcpThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pcp,
    const CLX_TM_BUF_THRESHOLD_T            *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_updateQueueState
 * PURPOSE:
 *      The function is used to update the port status with action for non-block used.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      dir              -- direction (CLX_DIR_INGRESS, CLX_DIR_EGRESS, CLX_DIR_BOTH).
 *      status           -- action (HAL_TM_PS_ACTIVED, HAL_TM_PS_NO_ACTIVED)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_updateQueueState(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_DIR_T                         dir,
    const HAL_TM_SC_T                       status,
    const UI32_T                            all_queue,
    const CLX_TM_HANDLER_T                  handler);


/* FUNCTION NAME: hal_dawn_tm_buf_getIgrBufPcpThreshold
 * PURPOSE:
 *      The function is used to get ingress buffer per pcp thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pfc_pcp          -- pfc pcp value.
 * OUTPUT:
 *      ptr_entry        -- the entry which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */

CLX_ERROR_NO_T
hal_dawn_tm_buf_getIgrBufPcpThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pcp,
    CLX_TM_BUF_THRESHOLD_T                  *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_setIgrBufPortThreshold
 * PURPOSE:
 *      The function is used to set ingress buffer per port thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      ptr_entry        -- the entry which the user want to set.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setIgrBufPortThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_BUF_THRESHOLD_T            *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_getIgrBufPortThreshold
 * PURPOSE:
 *      The function is used to get ingress buffer per port thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 * OUTPUT:
 *      ptr_entry        -- the entry which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getIgrBufPortThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    CLX_TM_BUF_THRESHOLD_T                  *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_setIgrBufPcpRemap
 * PURPOSE:
 *      The function is used to set orginal pcp remap to ingress buffer pcp
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      org_pcp          -- orginal pcp.
 *      ingbuf_pcp       -- ingress buffer pcp.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setIgrBufPcpRemap(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            org_pcp,
    const UI32_T                            ingbuf_pcp);

/* FUNCTION NAME: hal_dawn_tm_buf_getIgrBufPcpRemap
 * PURPOSE:
 *      The function is used to get orginal pcp remap to ingress buffer pcp
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      org_pcp          -- orginal pcp.
 * OUTPUT:
 *      ptr_ingbuf_pcp   -- ingress buffer pcp.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getIgrBufPcpRemap(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            org_pcp,
    UI32_T                                  *ptr_ingbuf_pcp);

/* FUNCTION NAME: hal_dawn_tm_buf_setEgrBufQueueThreshold
 * PURPOSE:
 *      The function is used to set egress buffer per queue thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- tm handler.
 *      ptr_entry        -- the entry which the user want to set.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setEgrBufQueueThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const CLX_TM_BUF_THRESHOLD_T            *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufQueueThreshold
 * PURPOSE:
 *      The function is used to get egress buffer per queue thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- tm handler.
 * OUTPUT:
 *      ptr_entry        -- the entry which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufQueueThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    CLX_TM_BUF_THRESHOLD_T                  *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_setEgrBufPortThreshold
 * PURPOSE:
 *      The function is used to set egress buffer per port thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      ptr_entry        -- the entry which the user want to set.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setEgrBufPortThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_BUF_THRESHOLD_T        *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufPortThreshold
 * PURPOSE:
 *      The function is used to get egress buffer per port thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 * OUTPUT:
 *      ptr_entry        -- the entry which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufPortThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    CLX_TM_BUF_THRESHOLD_T                  *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_setEgrBufPfcPcpRemapQueue
 * PURPOSE:
 *      The function is used to set the pcp which received from PFC pause frame
 *      remap to egress queue.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pfc_pcp          -- The pcp which received from PFC pause frame.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      None
 * RETURN:
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setEgrBufPfcPcpRemapQueue(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pfc_pcp,
    const CLX_TM_HANDLER_T                  handler);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufPfcPcpRemapQueue
 * PURPOSE:
 *      The function is used to get the pcp which received from PFC pause frame
 *      remap to which egress queue.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pfc_pcp          -- The pcp which received from PFC pause frame.
 * OUTPUT:
 *      ptr_handler      -- Egress queue handler.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufPfcPcpRemapQueue(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pfc_pcp,
    CLX_TM_HANDLER_T                        *ptr_handler);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufPortPktUsage
 * PURPOSE:
 *      The function is used to get egress buffer per port packet usage.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 * OUTPUT:
 *      ptr_usage        -- per queue usage.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufPortPktUsage(
    const UI32_T                            unit,
    const UI32_T                            port,
    UI32_T                                  *ptr_usage);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufQueueUsage
 * PURPOSE:
 *      The function is used to get egress buffer per queue usage.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- tm handler.
 * OUTPUT:
 *      ptr_usage        -- per queue usage.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufQueueUsage(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    UI32_T                                  *ptr_usage);

/* FUNCTION NAME: hal_dawn_tm_buf_setIgrBufMirHrm
 * PURPOSE:
 *      The function is used to set Ingress Buffer mirror headroom
 * INPUT:
 *      unit             -- Device unit number.
 *      threshold        -- Ingress Buffer mirror headroom
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setIgrBufMirHrm(
    const UI32_T                            unit,
    const UI32_T                            threshold);

/* FUNCTION NAME: hal_dawn_tm_buf_getIgrBufMirHrm
 * PURPOSE:
 *      The function is used to get Ingress Buffer mirror headroom
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_threshold    -- Ingress Buffer mirror headroom
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getIgrBufMirHrm(
    const UI32_T                            unit,
    UI32_T                                  *ptr_threshold);

/* FUNCTION NAME: hal_dawn_tm_buf_setIgrBufSdnHrm
 * PURPOSE:
 *      The function is used to set Ingress Buffer SDN headroom
 * INPUT:
 *      unit             -- Device unit number.
 *      threshold        -- Ingress Buffer SDN headroom
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setIgrBufSdnHrm(
    const UI32_T                            unit,
    const UI32_T                            threshold);

/* FUNCTION NAME: hal_dawn_tm_buf_getIgrBufSdnHrm
 * PURPOSE:
 *      The function is used to get Ingress Buffer SDN headroom
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_threshold    -- Ingress Buffer SDN headroom
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getIgrBufSdnHrm(
    const UI32_T                            unit,
    UI32_T                                  *ptr_threshold);

/* FUNCTION NAME: hal_dawn_tm_buf_setEgrBufCtrlPktHrm
 * PURPOSE:
 *      The function is used to set egress buffer control packet headroom
 * INPUT:
 *      unit             -- Device unit number.
 *      threshold        -- egress buffer control packet headroom
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setEgrBufCtrlPktHrm(
    const UI32_T                        unit,
    const UI32_T                        threshold);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufCtrlPktHrm
 * PURPOSE:
 *      The function is used to get egress buffer control packet headroom
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_threshold    -- egress buffer control packet headroom
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufCtrlPktHrm(
    const UI32_T                            unit,
    UI32_T                                  *ptr_threshold);

/* FUNCTION NAME: hal_dawn_tm_buf_setCngCtrl
 * PURPOSE:
 *      The function is used to set queue TM congestion control mode.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 *      mode             -- TM congestion control mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER           --  Other error
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setCngCtrl(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const CLX_TM_CNG_T                      mode);

/* FUNCTION NAME: hal_dawn_tm_buf_getCngCtrl
 * PURPOSE:
 *      The function is used to get queue TM congestion control mode.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      ptr_mode         -- TM congestion control mode
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getCngCtrl(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    CLX_TM_CNG_T                            *ptr_mode);

/* FUNCTION NAME: hal_dawn_tm_buf_setWredDropForce
 * PURPOSE:
 *      The function is used to set WRED drop force state
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- TM handler
 *      force_en         -- WRED drop force enable/disable
 *      force_value      -- WRED drop force on/off
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setWredDropForce(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const BOOL_T                            force_en,
    const BOOL_T                            force_value);

/* FUNCTION NAME: hal_dawn_tm_buf_getWredDropForce
 * PURPOSE:
 *      The function is used to get WRED drop force state
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- TM handler
 * OUTPUT:
 *      ptr_force_en     -- WRED drop force enable/disable
 *      ptr_force_value   -- WRED drop force on/off
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getWredDropForce(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    BOOL_T                                  *ptr_force_en,
    BOOL_T                                  *ptr_force_value);

/* FUNCTION NAME: hal_dawn_tm_buf_setWredMarkForce
 * PURPOSE:
 *      The function is used to set WRED mark force state
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- TM handler
 *      force_en         -- WRED mark force enable/disable
 *      force_value      -- WRED mark force on/off
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setWredMarkForce(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const BOOL_T                            force_en,
    const BOOL_T                            force_value);

/* FUNCTION NAME: hal_dawn_tm_buf_getWredMarkForce
 * PURPOSE:
 *      The function is used to get WRED mark force state
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- TM handler
 * OUTPUT:
 *      ptr_force_en     -- WRED mark force enable/disable
 *      ptr_force_value   -- WRED mark force on/off
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getWredMarkForce(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    BOOL_T                                  *ptr_force_en,
    BOOL_T                                  *ptr_force_value);

/* FUNCTION NAME: hal_dawn_tm_buf_setDctcpForce
 * PURPOSE:
 *      The function is used to set DCTCP force state
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- TM handler
 *      force_en         -- DCTCP force enable/disable
 *      force_value      -- DCTCP force on/off
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setDctcpForce(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const BOOL_T                            force_en,
    const BOOL_T                            force_value);

/* FUNCTION NAME: hal_dawn_tm_buf_getDctcpForce
 * PURPOSE:
 *      The function is used to get DCTCP force state
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- TM handler
 * OUTPUT:
 *      ptr_force_en     -- DCTCP force enable/disable
 *      ptr_force_value   -- DCTCP force on/off
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getDctcpForce(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    BOOL_T                                  *ptr_force_en,
    BOOL_T                                  *ptr_force_value);

/* FUNCTION NAME: hal_dawn_tm_buf_getWredProfile
 * PURPOSE:
 *      The function is used to get WRED profile
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- WRED profile ID.
 *      type             -- traffic type.
 *      color            -- traffic color.
 * OUTPUT:
 *      ptr_entry        -- WRED profile entry.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    const CLX_TM_TRAFFIC_TYPE_T             type,
    const CLX_COLOR_T                       color,
    CLX_TM_WRED_ENTRY_T                     *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_createWredProfile
 * PURPOSE:
 *      The function is used to create WRED profile
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- WRED profile ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_createWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_dawn_tm_buf_setWredProfile
 * PURPOSE:
 *      The function is used to set WRED profile
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- WRED profile ID.
 *      type             -- traffic type.
 *      color            -- traffic color.
 *      ptr_entry        -- WRED profile entry.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    const CLX_TM_TRAFFIC_TYPE_T             type,
    const CLX_COLOR_T                       color,
    const CLX_TM_WRED_ENTRY_T               *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_delWredProfile
 * PURPOSE:
 *      The function is used to delete WRED profile
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- WRED profile ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_delWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_dawn_tm_buf_setWredQueueConfig
 * PURPOSE:
 *      The function is used to set per queue WRED configuration.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 *      ptr_entry        -- WRED configuration of egress queue.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setWredQueueConfig(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const CLX_TM_WRED_QUEUE_CFG_T           *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_getWredQueueConfig
 * PURPOSE:
 *      The function is used to get per queue WRED configuration.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      ptr_entry        -- WRED configuration of egress queue.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getWredQueueConfig(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    CLX_TM_WRED_QUEUE_CFG_T                 *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_getDctcpProfile
 * PURPOSE:
 *      The function is used to get DCTCP profile.
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- DCTCP profile ID.
 * OUTPUT:
 *      ptr_entry        -- DCTCP profile entry.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getDctcpProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    CLX_TM_DCTCP_PROFILE_T                  *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_createDctcpProfile
 * PURPOSE:
 *      The function is used to create DCTCP profile.
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- DCTCP profile ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_createDctcpProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_dawn_tm_buf_setDctcpProfile
 * PURPOSE:
 *      The function is used to set DCTCP profile.
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- DCTCP profile ID.
 *      ptr_entry        -- DCTCP profile entry.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setDctcpProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    const CLX_TM_DCTCP_PROFILE_T            *ptr_entry);

/* FUNCTION NAME: hal_dawn_tm_buf_delDctcpProfile
 * PURPOSE:
 *      The function is used to delete DCTCP profile.
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- DCTCP profile ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_delDctcpProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_dawn_tm_buf_setDctcpQueueConfig
 * PURPOSE:
 *      The function is used to set per queue DCTCP configuration.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 *      profile_id       -- The DCTCP profile id is binded by the queue.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setDctcpQueueConfig(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_dawn_tm_buf_getDctcpQueueConfig
 * PURPOSE:
 *      The function is used to get per queue DCTCP configuration.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      ptr_profile_id   -- The DCTCP profile id is binded by the queue.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getDctcpQueueConfig(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    UI32_T                                  *ptr_profile_id);

/* FUNCTION NAME: hal_dawn_tm_buf_setPfcMapping
 * PURPOSE:
 *      The function is used to set the mapping of the PCP and the queue group.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 *      pcp_bitmap       -- The bit map of port control protocal.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        pcp_bitmap);

/* FUNCTION NAME: hal_dawn_tm_buf_getPfcMapping
 * PURPOSE:
 *      The function is used to set the mapping of the PCP and the queue group.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      ptr_pcp_bitmap   -- The bit map of port control protocal.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_pcp_bitmap);

/* FUNCTION NAME: hal_dawn_tm_buf_setFlowCtrlEnable
 * PURPOSE:
 *      The function is used to set flow conctrol enable status.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pcp              -- pcp value.
 * OUTPUT:
 *      ptr_min          -- min threshold of the pcp.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_setFlowCtrlEnable(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            mode);


/* FUNCTION NAME: hal_dawn_tm_buf_getFlowCtrlEnable
 * PURPOSE:
 *      The function is used to get flow conctrol enable status.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pcp              -- pcp value.
 * OUTPUT:
 *      ptr_min          -- min threshold of the pcp.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getFlowCtrlEnable(
    const UI32_T                            unit,
    const UI32_T                            port,
    HAL_TM_FC_T                             *ptr_mode);

/* FUNCTION NAME: hal_dawn_tm_buf_getHrmAndMaxTh
 * PURPOSE:
 *      The function is used to get the definition of share_max_th and hrm_th of the PCP.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 * OUTPUT:
 *      ptr_share_max_th    -- The share_max_th of pcp.
 *      ptr_hrm_th          -- The ptr_hrm_th of pcp.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */

CLX_ERROR_NO_T
hal_dawn_tm_buf_getHrmAndMaxTh(
    const UI32_T                            unit,
    const UI32_T                            port,
    UI32_T                                  *ptr_share_max_th,
    UI32_T                                  *ptr_hrm_th);

/* FUNCTION NAME: hal_dawn_tm_buf_getAoqMinTh
 * PURPOSE:
 *      The function is used to get the definition of min_th of the queue.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 * OUTPUT:
 *      ptr_ea_min_th    -- The min_th of the queue.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getAoqMinTh(
    const UI32_T                            unit,
    const UI32_T                            port,
    UI32_T                                  *ptr_ea_min_th);

/* FUNCTION NAME: hal_dawn_tm_buf_getIgrBufGsTh
 * PURPOSE:
 *      The function is used to get max threshold of share pool usage under IA accountable area.
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_max_static_th -- max threshold of share pool usage under IA accountable area.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getIgrBufGsTh(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    UI32_T                                  *ptr_max_static_th);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufGsCmTh
 * PURPOSE:
 *      The function is used to get max threshold of share pool usage under CM accountable area of EA.
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_max_static_th -- max threshold of share pool usage under IA accountable area.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufGsCmTh(
    const UI32_T                            unit,
    UI32_T                                  *ptr_max_static_th);

/* FUNCTION NAME: hal_dawn_tm_buf_getLsyBufGsTh
 * PURPOSE:
 *      The function is used to get max threshold of share pool usage under ingress lossy accountable area.
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_max_static_th-- max threshold of share pool usage under IEA accountable area.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getLsyBufGsTh(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    UI32_T                                  *ptr_max_static_th);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufGsTh
 * PURPOSE:
 *      The function is used to get EA global share threshold.
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_gs_thd       -- global share threshold.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufGsTh(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    UI32_T                                  *ptr_gs_thd);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufMcGsTh
 * PURPOSE:
 *      The function is used to get EA MC global share threshold.
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_gs_thd       -- global share threshold.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufMcGsTh(
    const UI32_T                            unit,
    UI32_T                                  *ptr_gs_thd);

/* FUNCTION NAME: hal_dawn_tm_buf_getScType
 * PURPOSE:
 *      The function is used to get sc type.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- The port number.
 *      sc               -- The sc number.
 * OUTPUT:
 *      type_value       -- sc type value.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getScType(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            sc,
    UI32_T                                  *ptr_type_value);

/* FUNCTION NAME: hal_dawn_tm_buf_getEgrBufUmQueueMinTh
 * PURPOSE:
 *      The function is used to get per queue min threshold
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      queue_type       -- queue type.
 *      queue_id         -- queue ID.
 * OUTPUT:
 *      ptr_min_th   -- strict min threshold.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getEgrBufUmQueueMinTh(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            queue_type,
    const UI32_T                            queue_id,
    UI32_T                                  *ptr_min_th);

/* FUNCTION NAME: hal_dawn_tm_buf_getIgrBufPcpHrm
 * PURPOSE:
 *      The function is used to get IA per PCP headroom.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pcp              -- pcp value.
 * OUTPUT:
 *      ptr_headroom     -- headroom threshold for the pcp.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getIgrBufPcpHrm(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    const UI32_T                            port,
    const UI32_T                            pcp,
    UI32_T                                  *ptr_headroom);

/* FUNCTION NAME: hal_dawn_tm_buf_getIgrBufPcpMaxStaticTh
 * PURPOSE:
 *      The function is used to get IA max static threshold for the pcp.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pcp              -- pcp.
 * OUTPUT:
 *      ptr_max_static_th -- max static threshold for the pcp.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getIgrBufPcpMaxStaticTh(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    const UI32_T                            port,
    const UI32_T                            pcp,
    UI32_T                                  *ptr_max_static_th);

/* FUNCTION NAME: hal_dawn_tm_buf_getIgrBufPortMaxStaticEn
 * PURPOSE:
 *      The function is used to get IA port max static threshold.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 * OUTPUT:
 *      ptr_max_static_th -- ingress buffer port max static threshold.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getIgrBufPortMaxStaticEn(
    const UI32_T                            unit,
    const UI32_T                            port,
    BOOL_T                                  *ptr_max_static_en);

/* FUNCTION NAME: hal_dawn_tm_buf_updatePortStatus
 * PURPOSE:
 *      The function is used to update the port status with action.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      status           -- action (HAL_TM_PS_ACTIVED, HAL_TM_PS_NO_ACTIVED)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_updatePortStatus(
    const UI32_T                            unit,
    const UI32_T                            port,
    const HAL_TM_SC_T                       status);

/* FUNCTION NAME: hal_dawn_tm_buf_getAopEmpty
 * PURPOSE:
 *      The function is used to get EA port empty.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- CLX port number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_tm_buf_getAopEmpty(
    const UI32_T            unit,
    const UI32_T            port);

CLX_ERROR_NO_T
hal_dawn_tm_buf_getAoqEmpty(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_TM_HANDLER_T  handler);

CLX_ERROR_NO_T
hal_dawn_tm_buf_getAiqEmpty(
    const UI32_T            unit,
    const UI32_T            port,
    const UI32_T            queue);

CLX_ERROR_NO_T
hal_dawn_tm_buf_setBufThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    const CLX_TM_BUF_THRESHOLD_T        *ptr_entry);

CLX_ERROR_NO_T
hal_dawn_tm_buf_getBufThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_THRESHOLD_T              *ptr_entry);

CLX_ERROR_NO_T
hal_dawn_tm_buf_getBufOccupancy(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_OCCUPANCY_T              *ptr_entry);

CLX_ERROR_NO_T
hal_dawn_tm_buf_getAopIdx(
    const UI32_T                            unit,
    const UI32_T                            port,
    UI32_T                                  *ptr_inst_idx,
    UI32_T                                  *ptr_sub_idx,
    UI32_T                                  *ptr_entry_idx);

CLX_ERROR_NO_T
hal_dawn_tm_buf_getWarmSize(
    const UI32_T        unit,
    UI32_T              *ptr_size);

CLX_ERROR_NO_T
hal_dawn_tm_buf_deinitWarm(
    const UI32_T        unit,
    HAL_IO_WB_DB_T      *ptr_db);

CLX_ERROR_NO_T
hal_dawn_tm_buf_initWarm(
    const UI32_T        unit,
    HAL_IO_WB_DB_T      *ptr_db);

UI32_T
hal_dawn_tm_buf_getAipSubIdx(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    const UI32_T                            port);

UI32_T
hal_dawn_tm_buf_getAiqIdx(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pcp);

CLX_ERROR_NO_T
hal_dawn_tm_buf_getBufWatermark(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_WATERMARK_T              *ptr_entry);

CLX_ERROR_NO_T
hal_dawn_tm_buf_clearBufWatermark(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type);

CLX_ERROR_NO_T
hal_dawn_tm_buf_getBufWatermarkList(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T             type,
    const UI32_T                        list_cnt,
    CLX_TM_BUF_WATERMARK_T              *ptr_entry_list);

CLX_ERROR_NO_T
hal_dawn_tm_buf_clearBufWatermarkList(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T             type,
    const UI32_T                        list_cnt);

CLX_ERROR_NO_T
hal_dawn_tm_buf_setPortDefault(
    const UI32_T                            unit,
    const UI32_T                            port);

CLX_ERROR_NO_T
hal_dawn_tm_buf_resetPortDefault(
    const UI32_T                            unit,
    const UI32_T                            port);

#endif /*end of HAL_DAWN_TM_BUF_H*/
