/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_meter.h
 * PURPOSE:
 *    It provides HAL driver API functions for meter module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_METER_H
#define HAL_METER_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_types.h>
#include <clx_error.h>
#include <clx_meter.h>
#include <clx_init.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_METER_SERVICE_TYPE_NUM  (3)     /* ing intf, egr intf and domain */
#define HAL_METER_CIA_TYPE_NUM      (12)    /* 8 icia ucp grps, 4 ecia ucp grps */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* meter type in HAL */
typedef enum
{
    HAL_METER_TYPE_INGRESS_INTF = 0,    /* ingress interface */
    HAL_METER_TYPE_EGRESS_INTF,         /* egress interface  */
    HAL_METER_TYPE_DOMAIN,              /* domain            */
    HAL_METER_TYPE_ICIA,                /* ingress cia       */
    HAL_METER_TYPE_ECIA,                /* egress cia        */
    HAL_METER_TYPE_FLOW,                /* flow-based        */
    HAL_METER_TYPE_LAST,
} HAL_METER_TYPE_T;

/* cnt_mtr_prof entry field */
typedef enum
{
    HAL_METER_CNT_MTR_FIELD_DIST_CNT = 0,
    HAL_METER_CNT_MTR_FIELD_CNT,
    HAL_METER_CNT_MTR_FIELD_METER,
    HAL_METER_CNT_MTR_FIELD_LAST
} HAL_METER_CNT_MTR_FIELD_T;

/* double bucket hw meter */
typedef struct HAL_METER_HW_METER_S
{
    UI32_T                      even_sw_id; /* even allocated by which sw meter */
    UI32_T                      odd_sw_id;  /* odd allocated by which sw meter  */
    UI32_T                      bank_idx;   /* hw meter owned by which bank (0 ~ 19) */
    struct HAL_METER_HW_METER_S *ptr_next;  /* next hw meter                    */
    struct HAL_METER_HW_METER_S *ptr_prev;  /* prev hw meter                    */
} HAL_METER_HW_METER_T;

typedef struct HAL_METER_INDEX_S
{
    UI32_T  hw_id;      /* hw meter pool entry id   */
    UI16_T  even_en;    /* even bucket enable       */
    UI16_T  odd_en;     /* odd bucket enable        */
} HAL_METER_INDEX_T;

/* Meter TCM Mode */
typedef enum
{
    HAL_METER_ALGO_SRTCM = 0,   /* SrTCM                 */
    HAL_METER_ALGO_TRTCM,       /* TrTCM                 */
    HAL_METER_ALGO_MTRTCM,      /* modified TrTCM        */
    HAL_METER_ALGO_1R2CM,       /* single rate two color */
    HAL_METER_ALGO_LAST
} HAL_METER_ALGO_T;

/* Meter Parameter */
typedef struct HAL_METER_PARAMETER_S
{
    UI32_T cir;       /* cir */
    UI32_T cbs;       /* cbs */
    UI32_T pir_eir;   /* pir or eir */
    UI32_T pbs_ebs;   /* pbs or ebs */
} HAL_METER_PARAMETER_T;

/* Meter Configuration*/
typedef struct HAL_METER_CFG_S
{
    HAL_METER_PARAMETER_T   param;          /* Bucket cir/cbs/pir/pbs/eir/ebs */
    HAL_METER_ALGO_T        algo_mode;      /* Meter TCM mode */
    UI16_T                  color_aware;    /* 0: color blind; 1: color ware */
    UI16_T                  layer1;         /* 0: layer2; 1: layer1 */
    UI16_T                  global;         /* 0: plane; 1: global */
    UI16_T                  packet;         /* 0: byte; 1: packet */
} HAL_METER_CFG_T;

typedef struct HAL_METER_SW_METER_S
{
    UI32_T              sw_id;      /* meter id */
    HAL_METER_CFG_T     cfg;        /* tcm mode/color mode/layer mode/port mode */
    HAL_METER_INDEX_T   hw_index;   /* hw meter info when meter allocated       */
    HAL_METER_TYPE_T    type;       /* sw meter type                            */
    UI32_T              valid;      /* 0: sw meter not created; 1: created      */
} HAL_METER_SW_METER_T;

typedef struct HAL_METER_BANK_S
{
    struct HAL_METER_BANK_S *ptr_next;      /* next bank */
    struct HAL_METER_BANK_S *ptr_prev;      /* prev bank */
    UI16_T global;                          /* 0: plane meter; 1: global meter */
    UI16_T valid;                           /* 0: not allocated; 1: allocated */
    UI16_T ucp_grp_id;                      /* the ucp group id if the bank is used for cia */
    UI16_T used_single_num;                 /* the number of the used single bucket in bank */
    UI16_T used_double_num;                 /* the number of the used double bucket in bank */
    HAL_METER_TYPE_T type;                  /* the bank type */
    HAL_METER_HW_METER_T free_single_list;  /* the double list of the free single bucket nodes */
    HAL_METER_HW_METER_T free_double_list;  /* the double list of the free double bucket nodes */
    HAL_METER_HW_METER_T *ptr_hw;           /* hw meters managed by this bank */
} HAL_METER_BANK_T;

typedef struct HAL_METER_POOL_MGMT_CB_S
{
    HAL_METER_BANK_T *ptr_bank_list;                            /* the array of meter bank */

    /* allocated bank management */
    HAL_METER_BANK_T used_p_srv[HAL_METER_SERVICE_TYPE_NUM];    /* manage allocated plane bank for service  */
    HAL_METER_BANK_T used_p_cia[HAL_METER_CIA_TYPE_NUM];        /* manage allocated plane bank for cia      */
    HAL_METER_BANK_T used_p_flow;                               /* manage allocated plane bank for flow     */
    HAL_METER_BANK_T used_g_srv[HAL_METER_SERVICE_TYPE_NUM];    /* manage allocated global bank for service */
    HAL_METER_BANK_T used_g_cia[HAL_METER_CIA_TYPE_NUM];        /* manage allocated global bank for cia     */
    HAL_METER_BANK_T used_g_flow;                               /* manage allocated global bank for flow    */

    HAL_METER_BANK_T free_p_list;                               /* manage free plane bank list              */
    HAL_METER_BANK_T free_g_list;                               /* manage free global bank list             */
    HAL_METER_SW_METER_T *ptr_sw;                               /* the array of sw meter                    */
    HAL_METER_HW_METER_T *ptr_hw;                               /* the array of hw meter                    */
    UI32_T sw_id_num_words;                                     /* it is used to manage sw meter ids        */
    UI32_T *ptr_sw_id_bmap;                                     /* it is used to manage sw meter ids        */
    UI32_T sw_p_free_cnt;                                       /* free sw plane meter count                */
    UI32_T sw_g_free_cnt;                                       /* free sw global meter count               */
} HAL_METER_POOL_MGMT_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_meter_init
 * PURPOSE:
 *      init meter module control blocks.
 * INPUT:
 *      unit            -- Device unit number.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK        -- init success.
 *      CLX_E_NO_MEMORY -- allocate control block failed.
 *      CLX_E_OTHERS    -- Init fail.
 *      CLX_E_BAD_PARAMETER -- parameter invalid
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_init(
    const UI32_T    unit);

/* FUNCTION NAME: hal_meter_deinit
 * PURPOSE:
 *      deinit meter module control blocks and free resource.
 * INPUT:
 *      unit            -- Device unit number.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK        -- deinit success.
 *      CLX_E_OTHERS    -- deInit fail.
 *      CLX_E_BAD_PARAMETER -- parameter invalid
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_deinit(
    const UI32_T    unit);

/* FUNCTION NAME: hal_meter_createMeter
 * PURPOSE:
 *      create a meter
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_meter_cfg   -- meter configuration
 * OUTPUT:
 *      ptr_meter_id    -- meter id, it presents a logical meter
 * RETURN:
 *      CLX_E_OK              -- create success.
 *      CLX_E_BAD_PARAMETER   -- parameter invalid or null pointer.
 *      CLX_E_OTHERS          -- not inited or others.
 *      CLX_E_TABLE_FULL      -- no more meter can be created.
 * NOTES:
 *      the rate & burst size should be multiple of 64. if usr provide a number
 *  which is not multiple of 64, this function will reset it.
 *      eg: rate = 1 kbps, the final rate will be 64 kbps
 *          size = 1 byte, the final size will be 64 bytes.
 */
CLX_ERROR_NO_T
hal_meter_createMeter(
    const UI32_T            unit,
    const CLX_METER_CFG_T   *ptr_meter_cfg,
    UI32_T                  *ptr_meter_id);

/* FUNCTION NAME: hal_meter_destroyMeter
 * PURPOSE:
 *    delete a meter.
 * INPUT:
 *    unit  --  Device number.
 *    meter_id -- service meter logic id
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK  --  success
 *    CLX_E_BAD_PARAMETER  --  bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_destroyMeter(
    const UI32_T        unit,
    const UI32_T        meter_id);

/* FUNCTION NAME: hal_meter_getMeter
 * PURPOSE:
 *      get a meter configuration.
 * INPUT:
 *      unit          -- Device unit number.
 *      meter_id      -- meter id, it presents a logical meter
 * OUTPUT:
 *      ptr_meter_cfg  -- the meter configuration.
 * RETURN:
 *      CLX_E_OK              -- get success.
 *      CLX_E_BAD_PARAMETER   -- parameter invalid or null pointer.
 *      CLX_E_ENTRY_NOT_FOUND -- the meter does not exist.
 *      CLX_E_OTHERS          -- unit is invalid.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_getMeter(
    const UI32_T    unit,
    const UI32_T    meter_id,
    CLX_METER_CFG_T *ptr_meter_cfg);

/* FUNCTION NAME: hal_meter_setServiceMeterParam
 * PURPOSE:
 *      modify meter rate & bucket size.
 * INPUT:
 *      unit          -- Device unit number.
 *      meter_id      -- meter id, it presents a logical meter
 * OUTPUT:
 *      ptr_meter_param  -- the meter rate & bucket size.
 * RETURN:
 *      CLX_E_OK              -- set success.
 *      CLX_E_BAD_PARAMETER   -- parameter invalid or null pointer.
 *      CLX_E_ENTRY_NOT_FOUND -- the meter does not exist.
 *      CLX_E_OTHERS          -- unit is invalid.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_setMeterParam(
    const UI32_T                unit,
    const UI32_T                meter_id,
    const CLX_METER_PARAMETER_T *ptr_meter_param);

/* FUNCTION NAME:   hal_meter_setIgrPortMeter
 * PURPOSE:
 *      Set ingress port metering for a specific port.
 * INPUT:
 *      unit             -- Device unit number
 *      port             -- Physical port ID
 *      ptr_cfg          -- The configuration
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Set success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_OTHERS          -- Set failed
 * NOTES:
 *      If ingress port metering is enabled and the traffic exceeds meter rate,
 *      ingress packet will be dropped.
 */
CLX_ERROR_NO_T
hal_meter_setIgrPortMeter(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_METER_PORT_CFG_T *ptr_cfg);

/* FUNCTION NAME:   hal_meter_getIgrPortMeter
 * PURPOSE:
 *      Get ingress port metering for a specific port.
 * INPUT:
 *      unit             -- Device unit number
 *      port             -- Physical port ID
 *      ptr_cfg          -- The configuration
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Set success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_OTHERS          -- Get failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_meter_getIgrPortMeter(
    const UI32_T            unit,
    const UI32_T            port,
    CLX_METER_PORT_CFG_T    *ptr_cfg);

/* FUNCTION NAME: hal_meter_getMeterHwIdx
 * PURPOSE:
 *      get a hw meter index for meter
 * INPUT:
 *      unit            -- device unit number.
 *      meter_id        -- sw meter id
 *      meter_type      -- meter type
 *      ucp_grp_id      -- ucp group id for ingress or egress cia
 * OUTPUT:
 *      ptr_hw_idx      -- hw meter index
 * RETURN:
 *      CLX_E_OK              -- alloc success.
 *      CLX_E_BAD_PARAMETER   -- parameter invalid or null pointer.
 *      CLX_E_OTHERS          -- not inited or others.
 *      CLX_E_ENTRY_NOT_FOUND -- no more hw meter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_getMeterHwIdx(
    const UI32_T            unit,
    const UI32_T            meter_id,
    const HAL_METER_TYPE_T  meter_type,
    const UI32_T            ucp_grp_id,
    UI32_T                  *ptr_hw_idx);

/* FUNCTION NAME: hal_meter_getMeterId
 * PURPOSE:
 *    get a meter id by hw meter index.
 * INPUT:
 *    unit         --  Device number.
 *    hw_idx       --  meter hw index.
 *
 * OUTPUT:
 *    ptr_meter_id -- meter id
 *
 * RETURN:
 *    CLX_E_OK  --  success
 *    CLX_E_BAD_PARAMETER  --  bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_getMeterId(
    const UI32_T        unit,
    const UI32_T        hw_idx,
    UI32_T              *ptr_meter_id);

/* FUNCTION NAME: hal_meter_allocCntMtrProf
 * PURPOSE:
 *    allocate icia or ecia cnt_mtr_prof entry. meter and counter is disabled
 *    by default.
 * INPUT:
 *    unit          --  Device number.
 *    ingress       --  Ingress or egress.
 *
 * OUTPUT:
 *    ptr_cnt_mtr_prof_idx -- cnt_mtr_prof entry index.
 *
 * RETURN:
 *    CLX_E_OK  --  success
 *    CLX_E_BAD_PARAMETER  --  bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_allocCntMtrProf(
    const UI32_T            unit,
    const BOOL_T            ingress,
    UI32_T                  *ptr_cnt_mtr_prof_idx);

/* FUNCTION NAME: hal_meter_freeCntMtrProf
 * PURPOSE:
 *    free icia or ecia cnt_mtr_prof entry.
 * INPUT:
 *    unit          --  Device number.
 *    ingress       --  Ingress or egress.
 *    cnt_mtr_prof_idx -- cnt_mtr_prof entry index.
 *
 * OUTPUT:
 *    none.
 *
 * RETURN:
 *    CLX_E_OK  --  success
 *    CLX_E_BAD_PARAMETER  --  bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_freeCntMtrProf(
    const UI32_T            unit,
    const BOOL_T            ingress,
    const UI32_T            cnt_mtr_prof_idx);

/* FUNCTION NAME: hal_meter_setCntMtrProf
 * PURPOSE:
 *    set hw meter or counter index into into icia or ecia cnt_mtr_prof entry.
 * INPUT:
 *    unit          --  Device number.
 *    ingress       --  Ingress or egress.
 *    cnt_mtr_prof_idx -- cnt_mtr_prof entry index.
 *    cnt_mtr_field    -- Select meter or counter.
 *    cnt_mtr_hw_idx   -- Hw meter or counter index.
 *
 * OUTPUT:
 *    none.
 *
 * RETURN:
 *    CLX_E_OK  --  success
 *    CLX_E_BAD_PARAMETER  --  bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_setCntMtrProf(
    const UI32_T                    unit,
    const BOOL_T                    ingress,
    const UI32_T                    cnt_mtr_prof_idx,
    const HAL_METER_CNT_MTR_FIELD_T cnt_mtr_field,
    const UI32_T                    cnt_mtr_hw_idx);

/* FUNCTION NAME: hal_meter_getCntMtrProf
 * PURPOSE:
 *    get hw meter or counter index from icia or ecia cnt_mtr_prof entry.
 * INPUT:
 *    unit          --  Device number.
 *    ingress       --  Ingress or egress.
 *    cnt_mtr_prof_idx -- cnt_mtr_prof entry index.
 *    cnt_mtr_field    -- Select meter or counter.
 *
 * OUTPUT:
 *    ptr_cnt_mtr_hw_idx    -- Hw meter or counter index.
 *
 * RETURN:
 *    CLX_E_OK  --  success
 *    CLX_E_BAD_PARAMETER  --  bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_getCntMtrProf(
    const UI32_T                    unit,
    const BOOL_T                    ingress,
    const UI32_T                    cnt_mtr_prof_idx,
    const HAL_METER_CNT_MTR_FIELD_T cnt_mtr_field,
    UI32_T                          *ptr_cnt_mtr_hw_idx);

/* FUNCTION NAME: hal_meter_checkCntMtrProf
 * PURPOSE:
 *    check if any meter or counter exists in icia or ecia cnt_mtr_prof entry.
 * INPUT:
 *    unit          --  Device number.
 *    ingress       --  Ingress or egress.
 *    cnt_mtr_prof_idx -- cnt_mtr_prof entry index.
 *
 * OUTPUT:
 *    ptr_cnt_mtr_exist    -- any meter or counter exists or not.
 *
 * RETURN:
 *    CLX_E_OK  --  success
 *    CLX_E_BAD_PARAMETER  --  bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_meter_checkCntMtrProf(
    const UI32_T            unit,
    const BOOL_T            ingress,
    const UI32_T            cnt_mtr_prof_idx,
    BOOL_T                  *ptr_cnt_mtr_exist);

#endif /* End of HAL_METER_H */

