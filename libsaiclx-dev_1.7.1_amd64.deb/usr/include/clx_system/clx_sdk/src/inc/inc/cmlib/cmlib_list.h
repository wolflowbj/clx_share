/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  cmlib_list.h
 * PURPOSE:
 *  this file is used to provide linked list operations to other users.
 *  linked list include: singly linked list, doubly linked list
 *
 * NOTES:
 *  it contains operations as below:
 *      1. create a linked list
 *      2. destroy a linked list
 *      3. insert user data to a linked list
 *      4. delete a user data from a linked list
 *      5. locate a user data from a linked list
 *      6. get next node from a linked list node
 *      7. get previous node from a linked list node
 *      7. get a linked list nodes count
 *
 */
#ifndef CMLIB_LIST_H
#define CMLIB_LIST_H
/* INCLUDE FILE DECLARATIONS
 */
#include <cmlib/cmlib.h>
/* NAMING CONSTANT DECLARATIONS
 */



/* linked list type */
typedef enum
{
    CMLIB_LIST_TYPE_SINGLY = 0,           /* singly linked list type   */
    CMLIB_LIST_TYPE_DOUBLY,               /* doubly linked list type   */
    CMLIB_LIST_TYPE_LAST,
} CMLIB_LIST_TYPE_T;

/* MACRO FUNCTION DECLARATIONS
 */
/* DATA TYPE DECLARATIONS
 */

/* linked list node */
typedef struct CMLIB_LIST_NODE_S
{
    void                     *ptr_data;      /* node data                   */
    struct CMLIB_LIST_NODE_S *ptr_next;      /* point to next link node     */
    struct CMLIB_LIST_NODE_S *ptr_prev;      /* point to previous link node */
} CMLIB_LIST_NODE_T;

struct CMLIB_LIST_S;

/* FUNCTION TYPE NAME: CMLIB_LIST_CMP_FUNC_T
 * PURPOSE:
 *      it is used to find which position the node should be inserted.
 * INPUT:
 *      ptr_node_data   -- the checked linked list node data.
 *      ptr_insert_data -- the data will be inserted.
 * OUTPUT:
 *      None.
 * RETURN:
 *      0     -- the insert node should be inserted before the node.
 *      non 0 -- it is not the right position.
 * NOTES:
 *
 */
typedef I32_T (*CMLIB_LIST_CMP_FUNC_T)(
    void *ptr_node_data,
    void *ptr_insert_data );

/* FUNCTION TYPE NAME: CMLIB_LIST_LOCATE_FUNC_T
 * PURPOSE:
 *      it is used to locate a linked list node.
 * INPUT:
 *      ptr_node_data  -- the checked linked list node data.
 *      ptr_cookie     -- the data used to check the linked list node. it is
 *                          one of locate function parameters.
 * OUTPUT:
 *      None.
 * RETURN:
 *      0     -- locate success
 *      non 0 -- locate failed, should continue to check.
 * NOTES:
 *
 */
typedef I32_T (*CMLIB_LIST_LOCATE_FUNC_T)(
    void *ptr_node_data,
    void *ptr_cookie );


/* FUNCTION TYPE NAME: CMLIB_LIST_DESTROY_FUNC_T
 * PURPOSE:
 *      it is used to release linked list node when destroy a linked list.
 * INPUT:
 *      ptr_node_data  -- the linked list node data will be destroyed.
 * OUTPUT:
 *      None.
 * RETURN:
 *      None.
 * NOTES:
 *
 */
typedef void (*CMLIB_LIST_DESTROY_FUNC_T)(
    void *ptr_node_data );

typedef CMLIB_LIST_DESTROY_FUNC_T CMLIB_LIST_DELETE_FUNC_T;

/* linked list operations */
typedef struct
{
    CLX_ERROR_NO_T (*getNodeData) (
    struct CMLIB_LIST_S      *ptr_list,         /* the node owner                      */
    CMLIB_LIST_NODE_T        *ptr_node,         /* the node will be get the data       */
    void                     **pptr_node_data );/* the data pointer saved in the node  */

    CLX_ERROR_NO_T (*insertByFunc)(                /* it used to insert a node by a function        */
    struct CMLIB_LIST_S      *ptr_list,        /* the linked list in which the node is inserted */
    void                     *ptr_data,        /* the inserted data                             */
    CMLIB_LIST_CMP_FUNC_T    insert_callback );/* the insert function decide where the data is
                                                    * inserted.
                                                    */

    CLX_ERROR_NO_T (*insertToHead)(         /* it used to insert a data to the head          */
    struct CMLIB_LIST_S    *ptr_list,   /* the linked list in which the node is inserted */
    void                   *ptr_data ); /* the inserted data                             */

    CLX_ERROR_NO_T (*insertToTail)(         /* it used to insert a data to the tail          */
    struct CMLIB_LIST_S    *ptr_list,   /* the linked list in which the node is inserted */
    void                   *ptr_data ); /* the inserted data                             */

    CLX_ERROR_NO_T (*insertBefore)(                /* insert a data before a specified node         */
    struct CMLIB_LIST_S    *ptr_list,          /* the linked list in which the node is inserted */
    CMLIB_LIST_NODE_T      *ptr_node,          /* the specified node                            */
    void                   *ptr_insert_data ); /* the inserted data                             */

    CLX_ERROR_NO_T (*insertAfter)(                 /* insert a data after a specified node          */
    struct CMLIB_LIST_S    *ptr_list,          /* the linked list in which the node is inserted */
    CMLIB_LIST_NODE_T      *ptr_node,          /* the specified node                            */
    void                   *ptr_insert_data ); /* the inserted data                             */

    CLX_ERROR_NO_T (*deleteNode)(                  /* delete a node from a linked list     */
    struct CMLIB_LIST_S    *ptr_list,          /* the linked list from which delete    */
    CMLIB_LIST_NODE_T      *ptr_delete_node ); /* the node will be deleted             */

    CLX_ERROR_NO_T (*deleteByData)(
    struct CMLIB_LIST_S *ptr_list,
    void                *ptr_data );

    CLX_ERROR_NO_T (*locateByFunc)(                  /* locate a node from a linked list    */
    struct CMLIB_LIST_S      *ptr_list,          /* the linked list from which locate   */
    void                     *ptr_cookie,        /* the cookie data for locate callback */
    CMLIB_LIST_LOCATE_FUNC_T locate_callback,    /* locate calback function             */
    CMLIB_LIST_NODE_T        **pptr_node );      /* the located node                    */

    CLX_ERROR_NO_T (*locateHead)(                  /* get the head node from a linked list */
    struct CMLIB_LIST_S      *ptr_list,         /* the linked list from which get       */
    CMLIB_LIST_NODE_T        **pptr_node );     /* the head node                        */

    CLX_ERROR_NO_T (*locateTail)(                   /* get the tail node from a linked list */
    struct CMLIB_LIST_S      *ptr_list,         /* the linked list from which get       */
    CMLIB_LIST_NODE_T        **pptr_node );     /* the tail node                        */

    CLX_ERROR_NO_T (*next)(                         /* get next node of the specified node */
    struct CMLIB_LIST_S      *ptr_list,         /* the node of this linked list        */
    CMLIB_LIST_NODE_T        *ptr_node,         /* the speicified node                 */
    CMLIB_LIST_NODE_T        **pptr_next_node); /* the next node                       */

    CLX_ERROR_NO_T (*prev)(                         /* get previous node of the specified node */
    struct CMLIB_LIST_S      *ptr_list,         /* the node of this linked list            */
    CMLIB_LIST_NODE_T        *ptr_node,         /* the speicified node                     */
    CMLIB_LIST_NODE_T        **pptr_prev_node );/* the previous node                       */

    CLX_ERROR_NO_T (*getLength)(                    /* get the node count of a linked list     */
    struct CMLIB_LIST_S      *ptr_list,         /* the linked list                         */
    UI32_T                   *ptr_length);      /* the linked list, output parameter       */

    CLX_ERROR_NO_T (*destroy)(                        /* destroy a linked list     */
    struct CMLIB_LIST_S       *ptr_list,          /* the destroyed linked list */
    CMLIB_LIST_DESTROY_FUNC_T destroy_callback ); /* the destroy function for
                                                       * releasing linked list node data
                                                       */
    CLX_ERROR_NO_T (*deleteAll)(                  /* destroy all nodes from a linked list*/
    struct CMLIB_LIST_S       *ptr_list,           /*  the linked list*/
    CMLIB_LIST_DELETE_FUNC_T delete_callback);   /*  the delete function for releasing node data*/

} CMLIB_LIST_OPS_T;


/* linked list head */
typedef struct CMLIB_LIST_S
{
    CMLIB_LIST_NODE_T *ptr_head_node;       /* linked list head node   */
    CMLIB_LIST_NODE_T *ptr_tail_node;       /* linked list tail node   */
    CMLIB_LIST_TYPE_T type;                 /* list type */
    UI32_T            capacity;             /* max count of nodes in list
                                             * size=0: the capacity is unlimited.
                                             * size>0: the capacity is limited.
                                             */
    void              *ptr_node_pool;       /* node pool */
    UI32_T            node_count;           /* the count of nodes in the list */
    CMLIB_LIST_OPS_T  *ptr_ops;             /* linked list operations         */
} CMLIB_LIST_T;


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */


/* FUNCTION NAME: cmlib_list_create
 * PURPOSE:
 *      it is used to create a linked list head.
 * INPUT:
 *      list_type -- the linked list type.
 *                   CMLIB_LIST_TYPE_SINGLY  : singly linked list.
 *                   CMLIB_LIST_TYPE_DOUBLY  : doubly linked list.
 *      capacity  -- the linked list capacity, if it is 0 then the linked list
 *                   size is unfixed, or is fixed.
 *      ptr_name  -- the linked list name, max length is CMLIB_NAME_MAX_LEN(include '\0')
 * OUTPUT:
 *      ptr_list  -- the new list head.
 * RETURN:
 *      CLX_E_OK            -- create success.
 *      CLX_E_BAD_PARAMETER -- parameter pointer is null or the type is invalid.
 *      CLX_E_NO_MEMORY     -- list head failed.
 *      CLX_E_OTHERS        -- create node pool failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_create(
    const UI32_T            capacity,
    const CMLIB_LIST_TYPE_T list_type,
    const C8_T              *ptr_name,
    CMLIB_LIST_T            **pptr_list );

/* FUNCTION NAME: cmlib_list_destroy
 * PURPOSE:
 *      it is used to destroy a linked list and release head and nodes. if user
 *      provide a destroy function, it will release every node data in the
 *      linked list.
 * INPUT:
 *      ptr_list         -- the destroyed linked list.
 *      destroy_callback -- destroy function is used to destroy node data.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK             -- destroy success.
 *      CLX_E_BAD_PARAMETER  -- ptr_list is null.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_destroy(
    CMLIB_LIST_T                    *ptr_list,
    const CMLIB_LIST_DESTROY_FUNC_T destroy_callback );

/* FUNCTION NAME: cmlib_list_getNodeData
 * PURPOSE:
 *      it is used to get the node data, the node may be singly/doubly linked list node.
 * INPUT:
 *      ptr_list  -- the list owns the node
 *      ptr_node  -- the node will be get data
 * OUTPUT:
 *      pptr_node_data -- the data saved in the node.
 * RETURN:
 *      CLX_E_OK             -- destroy success.
 *      CLX_E_BAD_PARAMETER  -- parameter pointer is null.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_getNodeData(
    CMLIB_LIST_T        *ptr_list,
    CMLIB_LIST_NODE_T   *ptr_node,
    void                **pptr_node_data );

/* FUNCTION NAME: cmlib_list_insertByFunc
 * PURPOSE:
 *      it is used to insert a data by a insert function which is used to decide
 *      where the inserted node should be inserted. if the insert function does
 *      not give a position(node), the node will be inserted to the tail of the
 *      linked list. if the insert function give a position(node), the node will
 *      be inserted before the position(node).
 * INPUT:
 *      ptr_list        -- the node will be inseted in it.
 *      ptr_data        -- the inserted data.
 *      cmp_callback    -- the inserted callback function, used to find the
 *                         insert position.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK             -- insert success.
 *      CLX_E_BAD_PARAMETER  -- parameter pointer is null.
 *      CLX_E_TABLE_FULL     -- the linked list is full, this is for capacity>0
 *      CLX_E_NO_MEMORY      -- allocate node failed, this is for capacity==0.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_insertByFunc(
    CMLIB_LIST_T                 *ptr_list,
    void                         *ptr_data,
    const CMLIB_LIST_CMP_FUNC_T  cmp_callback );

/* FUNCTION NAME: cmlib_list_insertToHead
 * PURPOSE:
 *      it is used to insert a data to the front of linked list.
 * INPUT:
 *      ptr_list  -- the node will be inserted in it.
 *      ptr_data  -- the inserted data.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK             -- insert success.
 *      CLX_E_BAD_PARAMETER  -- parameter pointer is null.
 *      CLX_E_TABLE_FULL     -- the linked list is full, this is for capacity>0
 *      CLX_E_NO_MEMORY      -- allocate node failed, this is for capacity==0.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_insertToHead(
    CMLIB_LIST_T  *ptr_list,
    void          *ptr_data );


/* FUNCTION NAME: cmlib_list_insertToTail
 * PURPOSE:
 *      it is used to insert a data to the tail of linked list.
 * INPUT:
 *      ptr_list  -- the node will be inserted in it.
 *      ptr_data  -- the inserted data.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK             -- insert success.
 *      CLX_E_BAD_PARAMETER  -- parameter pointer is null.
 *      CLX_E_TABLE_FULL     -- the linked list is full, this is for capacity>0
 *      CLX_E_NO_MEMORY      -- allocate node failed, this is for capacity==0.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_insertToTail(
    CMLIB_LIST_T  *ptr_list,
    void          *ptr_data );

/* FUNCTION NAME: cmlib_list_insertBefore
 * PURPOSE:
 *      it is used to insert a data before a specified node.
 * INPUT:
 *      ptr_list -- the node will be inserted in it.
 *      ptr_node -- insert before it.
 *      ptr_data -- the inserted data.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK             -- insert success.
 *      CLX_E_BAD_PARAMETER  -- parameter pointer is null.
 *      CLX_E_TABLE_FULL     -- the linked list is full, this is for capacity>0
 *      CLX_E_NO_MEMORY      -- allocate node failed, this is for capacity==0.
 *      CLX_E_NOT_SUPPORT    -- list don't support this operation
 * NOTES:
 *      singly linked list don't support this operation.
 */
CLX_ERROR_NO_T
cmlib_list_insertBefore(
    CMLIB_LIST_T        *ptr_list,
    CMLIB_LIST_NODE_T   *ptr_node,
    void                *ptr_data );


/* FUNCTION NAME: cmlib_list_insertAfter
 * PURPOSE:
 *      it is used to insert a data after a specified node.
 * INPUT:
 *      ptr_list -- the node will be inserted in it.
 *      ptr_node -- insert after it.
 *      ptr_data -- the inserted data.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK            -- insert success.
 *      CLX_E_BAD_PARAMETER -- parameter pointer is null.
 *      CLX_E_TABLE_FULL    -- the linked list is full, this is for capacity>0
 *      CLX_E_NO_MEMORY     -- allocate node failed, this is for capacity==0.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_insertAfter(
    CMLIB_LIST_T        *ptr_list,
    CMLIB_LIST_NODE_T   *ptr_node,
    void                *ptr_data );

/* FUNCTION NAME: cmlib_list_delete
 * PURPOSE:
 *      it is used to delete a node from a linked list.
 * INPUT:
 *      ptr_list         -- the node will delete from it.
 *      ptr_delete_node  -- the deleted node pointer.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK              -- delete success.
 *      CLX_E_BAD_PARAMETER   -- parameter pointer is null.
 *      CLX_E_ENTRY_NOT_FOUND -- the delete node is not in the linked list
 * NOTES:
 *      the delete node data will not process in this function
 */
CLX_ERROR_NO_T
cmlib_list_delete(
    CMLIB_LIST_T        *ptr_list,
    CMLIB_LIST_NODE_T   *ptr_delete_node);

/* FUNCTION NAME: cmlib_list_deleteAll
 * PURPOSE:
 *      it is used to delete alll node from a linked list.
 * INPUT:
 *      ptr_list          -- the node will delete from it.
 *      delete_callback   -- delete function is used to destroy node data.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK              -- delete success.
 *      CLX_E_BAD_PARAMETER   -- parameter pointer is null.
 */
CLX_ERROR_NO_T
cmlib_list_deleteAll(
    CMLIB_LIST_T       *ptr_list,
    const CMLIB_LIST_DELETE_FUNC_T delete_callback);


/* FUNCTION NAME: cmlib_list_deleteByData
 * PURPOSE:
 *      it is used to delete a node from a linked list by user data pointer.
 * INPUT:
 *      ptr_list         -- the node will delete from it.
 *      ptr_delete_data  -- the deleted user data pointer.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK              -- delete success.
 *      CLX_E_BAD_PARAMETER   -- parameter pointer is null.
 *      CLX_E_ENTRY_NOT_FOUND -- the delete node is not in the linked list
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_deleteByData(
    CMLIB_LIST_T *ptr_list,
    void         *ptr_delete_data);


/* FUNCTION NAME: cmlib_list_locateByFunc
 * PURPOSE:
 *      it is used to locate a node data from a linked list by a locate function.
 * INPUT:
 *      ptr_list        -- the linked list.
 *      ptr_cookie      -- cookie data for locate function.
 *      locate_callback -- locate function for location.
 * OUTPUT:
 *      pptr_node       -- the located node.
 * RETURN:
 *      CLX_E_OK              -- locate success.
 *      CLX_E_BAD_PARAMETER   -- parameter pointer is null.
 *      CLX_E_ENTRY_NOT_FOUND -- the locate data is not in the linked list
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_locateByFunc(
    CMLIB_LIST_T                   *ptr_list,
    void                           *ptr_cookie,
    const CMLIB_LIST_LOCATE_FUNC_T locate_callback,
    CMLIB_LIST_NODE_T              **pptr_node );

/* FUNCTION NAME: cmlib_list_locateHead
 * PURPOSE:
 *      it is used to get the first node of the linked list.
 * INPUT:
 *      ptr_list  -- the linked list.
 * OUTPUT:
 *      pptr_node -- the head data node.
 * RETURN:
 *      CLX_E_OK              -- locate success.
 *      CLX_E_BAD_PARAMETER   -- parameter pointer is null.
 *      CLX_E_ENTRY_NOT_FOUND -- no data node, it means list is empty
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_locateHead(
    CMLIB_LIST_T        *ptr_list,
    CMLIB_LIST_NODE_T   **pptr_node );

/* FUNCTION NAME: cmlib_list_locateTail
 * PURPOSE:
 *      it is used to get the last node of the linked list.
 * INPUT:
 *      ptr_list  -- the linked list.
 * OUTPUT:
 *      pptr_node -- the tail node.
 * RETURN:
 *      CLX_E_OK              -- locate success.
 *      CLX_E_BAD_PARAMETER   -- parameter pointer is null.
 *      CLX_E_ENTRY_NOT_FOUND -- no data node, it means list is empty
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_locateTail(
    CMLIB_LIST_T        *ptr_list,
    CMLIB_LIST_NODE_T   **pptr_node );

/* FUNCTION NAME: cmlib_list_next
 * PURPOSE:
 *      it is used to get the next node of a specified node.
 * INPUT:
 *      ptr_list  -- the linked list.
 *      ptr_node  -- the specified node.
 * OUTPUT:
 *      pptr_next_node -- the next node.
 * RETURN:
 *      CLX_E_OK              -- get next node success.
 *      CLX_E_BAD_PARAMETER   -- parameter pointer is null.
 *      CLX_E_ENTRY_NOT_FOUND -- no next node
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_next(
    CMLIB_LIST_T        *ptr_list,
    CMLIB_LIST_NODE_T   *ptr_node,
    CMLIB_LIST_NODE_T   **pptr_next_node );

/* FUNCTION NAME: cmlib_list_prev
 * PURPOSE:
 *      it is used to get the previous node of a specified node.
 * INPUT:
 *      ptr_list  -- the linked list.
 *      ptr_node  -- the specified node.
 * OUTPUT:
 *      pptr_prev_node -- the previous node.
 * RETURN:
 *      CLX_E_OK              -- get previous node success.
 *      CLX_E_BAD_PARAMETER   -- parameter pointer is null.
 *      CLX_E_ENTRY_NOT_FOUND -- no previous node
 *      CLX_E_NOT_SUPPORT     -- list don't support this operation
 * NOTES:
 *      singly linked list don't support this operation.
 */
CLX_ERROR_NO_T
cmlib_list_prev(
    CMLIB_LIST_T        *ptr_list,
    CMLIB_LIST_NODE_T   *ptr_node,
    CMLIB_LIST_NODE_T   **pptr_prev_node );

/* FUNCTION NAME: cmlib_list_getLength
 * PURPOSE:
 *      it is used to get the count of nodes in the linked list.
 * INPUT:
 *      ptr_list  -- the linked list.
 * OUTPUT:
 *      ptr_length -- the number of nodes in the linked list.
 * RETURN:
 *      CLX_E_OK             -- destroy success.
 *      CLX_E_BAD_PARAMETER  -- parameter pointer is null.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
cmlib_list_getLength(
    CMLIB_LIST_T *ptr_list,
    UI32_T       *ptr_length );

#endif /* End of CMLIB_LIST_H */

