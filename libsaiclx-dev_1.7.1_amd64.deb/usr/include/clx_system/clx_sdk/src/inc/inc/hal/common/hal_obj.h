/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_obj.h
 * PURPOSE:
 *  1. Provide object API.
 * NOTES:
 */

#ifndef HAL_OBJ_H
#define HAL_OBJ_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_cfg.h>
#include <hal/common/hal.h>
#include <hal/common/hal_tbl.h>

/* NAMING CONSTANT DECLARATIONS
 */

/*
 *    VM_ETAG       : bit31(1):1, bit11-bit30(20):ecid, bit0-bit10(11):di
 *    VM VNTAG/VEPA : bit31(1):0, bit26-bit30(5):type, bit11-bit25(15):vm_vif, bit0-bit10(11):di
 *    Others        : bit31(1):0, bit26-bit30(5):type, bit16-bit25(10):rsv, bit0-bit15(16):di
 *
 *             1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * ETAG       |1|            ecid                       |         di          |
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * VNTAG/VEPA |0|  type   |        vif                  |         di          |
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * Others     |0|  type   |      reserve      |             di                |
 *            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 */

#define HAL_OBJ_DI_SHIFT             (0)
#define HAL_OBJ_VM_ID_SHIFT          (11)
#define HAL_OBJ_TYPE_SHIFT           (26)
#define HAL_OBJ_VM_ETAG_TYPE_SHIFT   (31)
#define HAL_OBJ_VM_DI_BITS           (11)
#define HAL_OBJ_NORMAL_DI_BITS       (16)
#define HAL_OBJ_VM_ETAG_BITS         (20)
#define HAL_OBJ_VM_VNTAG_BITS        (12)
#define HAL_OBJ_VM_VEPA_BITS         (12)
#define HAL_OBJ_TYPE_BITS            (5)
#define HAL_OBJ_VM_TYPE_BIT          (1)

#define HAL_OBJ_PHY_PORT_MIN         (0)
#define HAL_OBJ_PHY_PORT_MAX         (1535)
#define HAL_OBJ_LAG_BASE_ID          (1536)
#define HAL_OBJ_LAG_MIN              (0)
#define HAL_OBJ_LAG_MAX              (511)

#define HAL_OBJ_SET(__intf__, __shift__, __bit__, __id__)                  \
            ((__intf__) |= (((__id__) & ((1U << __bit__) -1)) << __shift__))
#define HAL_OBJ_GET(__intf__, __shift__, __bit__, __id__)                  \
            (__id__ = ((__intf__ >> __shift__) & ((1U << __bit__) - 1)))

#define HAL_OBJ_TYPE_SET(__intf__, __id__)                                                  \
            HAL_OBJ_SET(__intf__, HAL_OBJ_TYPE_SHIFT, HAL_OBJ_TYPE_BITS, __id__)
#define HAL_OBJ_VM_ETAG_TYPE_SET(__intf__, __id__)                                          \
            HAL_OBJ_SET(__intf__, HAL_OBJ_VM_ETAG_TYPE_SHIFT, HAL_OBJ_VM_TYPE_BIT, __id__)
#define HAL_OBJ_VM_ETAG_SET(__intf__, __id__)                                                \
            HAL_OBJ_SET(__intf__, HAL_OBJ_VM_ID_SHIFT, HAL_OBJ_VM_ETAG_BITS, __id__)
#define HAL_OBJ_VM_VNTAG_SET(__intf__, __id__)                                               \
            HAL_OBJ_SET(__intf__, HAL_OBJ_VM_ID_SHIFT, HAL_OBJ_VM_VNTAG_BITS, __id__)
#define HAL_OBJ_VM_VEPA_SET(__intf__, __id__)                                                \
            HAL_OBJ_SET(__intf__, HAL_OBJ_VM_ID_SHIFT, HAL_OBJ_VM_VEPA_BITS, __id__)
#define HAL_OBJ_VM_DI_SET(__intf__, __id__) do                                                  \
            {                                                                                       \
                UI32_T __sw_di__ = (__id__);                                                        \
                if ((__id__) >= HAL_LAG_BASE_ID)                                                \
                {                                                                                   \
                    __sw_di__ -= (HAL_LAG_BASE_ID - HAL_OBJ_LAG_BASE_ID);                   \
                }                                                                                   \
                HAL_OBJ_SET((__intf__), HAL_OBJ_DI_SHIFT, HAL_OBJ_VM_DI_BITS, __sw_di__); \
            }while(0)
#define HAL_OBJ_DI_SET(__intf__, __id__)                                                     \
            HAL_OBJ_SET(__intf__, HAL_OBJ_DI_SHIFT, HAL_OBJ_NORMAL_DI_BITS, __id__)
#define HAL_OBJ_TYPE_GET(__intf__, __id__)                                                   \
            HAL_OBJ_VM_ETAG_CHK(__intf__) ? (__id__ = CLX_PORT_TYPE_VM_ETAG) :                \
            HAL_OBJ_GET(__intf__, HAL_OBJ_TYPE_SHIFT, HAL_OBJ_TYPE_BITS, __id__)
#define HAL_OBJ_VM_ETAG_GET(__intf__, __id__)                                                \
            HAL_OBJ_GET(__intf__, HAL_OBJ_VM_ID_SHIFT, HAL_OBJ_VM_ETAG_BITS, __id__)
#define HAL_OBJ_VM_VNTAG_GET(__intf__, __id__)                                               \
            HAL_OBJ_GET(__intf__, HAL_OBJ_VM_ID_SHIFT, HAL_OBJ_VM_VNTAG_BITS, __id__)
#define HAL_OBJ_VM_VEPA_GET(__intf__, __id__)                                                \
            HAL_OBJ_GET(__intf__, HAL_OBJ_VM_ID_SHIFT, HAL_OBJ_VM_VEPA_BITS, __id__)
#define HAL_OBJ_VM_DI_GET(__intf__, __id__) do                                               \
            {                                                                                    \
                HAL_OBJ_GET(__intf__, HAL_OBJ_DI_SHIFT, HAL_OBJ_VM_DI_BITS, __id__); \
                if ((__id__) >= HAL_OBJ_LAG_BASE_ID)                                         \
                {                                                                                \
                  (__id__) += (HAL_LAG_BASE_ID - HAL_OBJ_LAG_BASE_ID);                   \
                }                                                                                \
            }while(0)
#define HAL_OBJ_DI_GET(__intf__, __id__) do                                                  \
            {                                                                                    \
                UI32_T    __type__;                                                              \
                HAL_OBJ_TYPE_GET(__intf__, __type__);                                        \
                if ((CLX_PORT_TYPE_VM_ETAG == __type__)  ||                                      \
                    (CLX_PORT_TYPE_VM_VNTAG == __type__) ||                                      \
                    (CLX_PORT_TYPE_VM_VEPA == __type__))                                         \
                {                                                                                \
                    HAL_OBJ_VM_DI_GET(__intf__, __id__);                                     \
                }                                                                                \
                else                                                                             \
                {                                                                                \
                    HAL_OBJ_GET(__intf__, HAL_OBJ_DI_SHIFT, HAL_OBJ_NORMAL_DI_BITS, __id__); \
                }                                                                                \
            } while(0)
#define HAL_OBJ_CHK(__intf__)                                                                \
            (((__intf__) >> HAL_OBJ_TYPE_SHIFT) != 0)
#define HAL_OBJ_VM_ETAG_CHK(__intf__)                                                        \
            (((__intf__) >> HAL_OBJ_VM_ETAG_TYPE_SHIFT) != 0)

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   hal_obj_createPort
 * PURPOSE:
 *      hal_obj_createPort() is responsible for creating port.
 *
 * INPUT:
 *      unit              -- The unit number
 *      ptr_info          -- The info to create port.
 * OUTPUT:
 *      ptr_port          -- Return created port.
 * RETURN:
 *      CLX_E_OK          -- Successful.
 *      CLX_E_OTHERS      -- Failed.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_obj_createPort(
    const UI32_T                 unit,
    const HAL_INTF_OBJ_INFO_T    *ptr_info,
    CLX_PORT_T                   *ptr_port);

/* FUNCTION NAME:   hal_obj_destroyPort
 * PURPOSE:
 *      hal_obj_destroyPort() is responsible for destroying created port.
 *
 * INPUT:
 *      unit              -- The unit number
 *      port              -- The created port.
 * OUTPUT:
 *      None              --
 * RETURN:
 *      CLX_E_OK          -- Successful.
 *      CLX_E_OTHERS      -- Failed.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_obj_destroyPort(
    const UI32_T            unit,
    const CLX_PORT_T        port);

/* FUNCTION NAME:   hal_obj_getPort
 * PURPOSE:
 *      hal_obj_getPort() is responsible for getting created port.
 *
 * INPUT:
 *      unit            -- The unit number
 *      ptr_info        -- The info of created port.
 * OUTPUT:
 *      ptr_port        -- Return created port.
 * RETURN:
 *      CLX_E_OK        -- Successful.
 *      CLX_E_OTHERS    -- Failed.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_obj_getPort(
    const UI32_T                 unit,
    const HAL_INTF_OBJ_INFO_T    *ptr_info,
    CLX_PORT_T                   *ptr_port);

/* FUNCTION NAME:   hal_obj_getPortInfo
 * PURPOSE:
 *      hal_obj_getPortInfo() is responsible for getting created port.
 *
 * INPUT:
 *      unit               -- The unit number
 *      port               -- The created port.
 * OUTPUT:
 *      ptr_info           -- Return created port info.
 * RETURN:
 *      CLX_E_OK           -- Successful.
 *      CLX_E_OTHERS       -- Failed.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_obj_getPortInfo(
    const UI32_T            unit,
    const CLX_PORT_T        port,
    HAL_INTF_OBJ_INFO_T     *ptr_info);

/* FUNCTION NAME:   hal_obj_validatePort
 * PURPOSE:
 *      hal_obj_validatePort() is responsible for validate created port.
 *
 * INPUT:
 *      unit             -- The unit number
 *      port             -- The created port.
 * OUTPUT:
 *      none             --
 * RETURN:
 *      CLX_E_OK         -- Successful.
 *      CLX_E_OTHERS     -- Failed.
 *
 * NOTES:
 *      None
 *
 */
 CLX_ERROR_NO_T
hal_obj_validatePort(
    const UI32_T            unit,
    const CLX_PORT_T        port);

/* FUNCTION NAME:   hal_obj_getLclIntf
 * PURPOSE:
 *      hal_obj_getLclIntf() is responsible for local interface.
 *
 * INPUT:
 *      unit              -- The unit number
 *      port              -- The created port.
 * OUTPUT:
 *      ptr_lcl_intf      --local interface
 * RETURN:
 *      CLX_E_OK          -- Successful.
 *      CLX_E_OTHERS      -- Failed.
 *
 * NOTES:
 *      None
 *
 */
 CLX_ERROR_NO_T
hal_obj_getLclIntf(
    const UI32_T            unit,
    const CLX_PORT_T        intf,
    UI32_T                  *ptr_lcl_intf);

#endif  /* #ifndef HAL_OBJ_H */
