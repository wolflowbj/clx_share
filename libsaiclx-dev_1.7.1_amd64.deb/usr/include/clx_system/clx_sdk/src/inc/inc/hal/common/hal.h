/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal.h
 * PURPOSE:
 *  1. Provide whole HAL resource initialization API.
 *  2. Provide HAL per-unit initialization and de-initialization function
 *     APIs.
 *  3. Provide HAL database access APIs.
 *  4. Provide a HAL multiplexing function vector.
 *
 * NOTES:
 */

#ifndef HAL_H
#define HAL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_cfg.h>
#include <clx_module.h>
#include <hal/common/hal_drv.h>
#include <hal/common/hal_tbl.h>
#include <hal/common/hal_intr.h>
#include <hal/common/hal_io.h>
#include <hal/common/hal_dbg.h>
#include <cmlib/cmlib_bitmap.h>
#include <api/diag.h>
#include <cdb/cdb.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_DEBUG                       (1)
#define HAL_MAX_DCC_CMD                 (16)
#define HAL_BCAST_ADDR_OFFSET           (0x80000000)
#define HAL_BYTES_OF_WORD               (4)
#define HAL_MAX_ENTRY_WORD_SIZE         (MAX_ENTRY_SIZE/HAL_BYTES_OF_WORD)
#define HAL_INVALID_ID                  (CLX_INVALID_ID)
#define HAL_ENABLE_RESOURCE_LOCK        (1)
#define HAL_LOCAL_INTF_AVL              "lcl_intf_avl"
#define HAL_LOCAL_INTF_INFO_AVL         "lcl_intf_info_avl"
#define HAL_SDB_ENABLE                  (0)
#define HAL_MAX_MAC_MACRO_COUNT         (64) /* HAL support maximum MAC/SERDES macro number,
                                            may need to adjust when chip support maximum capacity change */
#define HAL_MAX_MAC_MACRO_WORD_SIZE     (CLX_BITMAP_SIZE(HAL_MAX_MAC_MACRO_COUNT))
#define HAL_MAX_PLANE_PORT_COUNT        (96) /* HAL support maximum plane port number,
                                            may need to adjust when chip support maximum capacity change */
#define HAL_MAX_PLANE_PORT_WORD_SIZE    (CLX_BITMAP_SIZE(HAL_MAX_PLANE_PORT_COUNT))
#define HAL_MAX_CPI_PORT_COUNT          (2) /* HAL support maximum CPI port number */
#define HAL_CPI_PORT_0                  (0) /* HAL CPI port 0 index */
#define HAL_CPI_PORT_1                  (1) /* HAL CPI port 1 index */
#define HAL_CPI_PLANE_PORT              (64)
#define HAL_CPI_DP_PLANE_PORT           (32)
#define HAL_DEVICE_PXP_REV_ID           (CLX_INVALID_ID)
#define HAL_MAX_RC_PORT_COUNT           (2) /* HAL support maximum RC port number */
#define HAL_RC_PORT_0                   (0) /* HAL RC port 0 index */
#define HAL_RC_PORT_1                   (1) /* HAL RC port 1 index */

/* MACRO FUNCTION DECLARATIONS
 */

#define PTR_HAL_FUNC_VECTOR(unit)       _ext_ptr_chip_func_vector[unit]
#define PTR_HAL_EXT_CHIP_INFO(unit)     _ext_ptr_chip_info[unit]
#define PTR_HAL_CMN_FUNC_VECTOR(unit)   _ext_ptr_chip_cmn_func_vector[unit]

/* hal related check macros */
#define HAL_IS_UNIT_VALID(__unit__)                                         \
        (((__unit__) < CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM) &&                 \
         (NULL !=_ext_ptr_chip_func_vector[(__unit__)]))

#define HAL_IS_VLAN_VALID(__vlan__)                                         \
        (((__vlan__) >= 1) && ((__vlan__) <= 4095))

#define HAL_IS_ETH_PORT_VALID(__unit__, __port__)                           \
        (((__port__) < CLX_PORT_NUM) &&                                     \
         (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP_ETH((__unit__)), (__port__))))

#define HAL_IS_PORT_VALID(__unit__, __port__)                               \
        (((__port__) < CLX_PORT_NUM) &&                                     \
         (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP((__unit__)), (__port__))))

#define HAL_IS_PP_PORT_VALID(__unit__, __port__)                            \
        (((__port__) < CLX_PORT_NUM) &&                                     \
         (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP_PP((__unit__)), (__port__))))

#define HAL_IS_PHY_PORT_VALID(__unit__, __port__)                           \
        (((__port__) < CLX_PORT_NUM) &&                                     \
         (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP_PHY((__unit__)), (__port__))))

#define HAL_IS_RC_PORT_VALID(__unit__, __port__)                            \
        ((((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_0)) ||           \
        ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_1))) &&            \
        (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP((__unit__)), (__port__))))

#define HAL_IS_CPI_PORT_VALID(__unit__, __port__)                           \
        ((((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_0)) ||         \
        ((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_1))) &&          \
        (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP((__unit__)), (__port__))))

#define HAL_IS_RC_PORT(__unit__, __port__)                                  \
        (((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_0)) ||            \
        ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_1)))

#define HAL_IS_CPI_PORT(__unit__, __port__)                                 \
        (((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_0)) ||          \
        ((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_1)))

#define HAL_UI32_FLD_MSK(__unit__, __tbl__, __fld__)                        \
        (0xFFFFFFFF >> (32 - (CDB_TABLE((__unit__), (__tbl__))->ptr_table_entry[(__fld__)].length)))
#define HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl__, __fld__, __value__)  \
        ((__value__) <= HAL_UI32_FLD_MSK((__unit__), (__tbl__), (__fld__)))
#define HAL_TRUNCATE_UI32_FLD(__unit__, __tbl__, __fld__, __value__)        \
        ((__value__) & HAL_UI32_FLD_MSK((__unit__), (__tbl__), (__fld__)))

#define HAL_CHECK_ERROR(__rc__) do                                          \
    {                                                                       \
        CLX_ERROR_NO_T  __rc = (__rc__);                                    \
        if (__rc  != CLX_E_OK)                                              \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, #__rc__"=%d\n", __rc);                 \
            return __rc;                                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_UNIT(__unit__) do                                         \
    {                                                                       \
        if (!HAL_IS_UNIT_VALID((__unit__)))                                 \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "invalid unit=%u, rc=%d\n",            \
            __unit__, CLX_E_BAD_PARAMETER);                                 \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_VLAN(__vlan_id__) do                                      \
    {                                                                       \
        if (!HAL_IS_VLAN_VALID((__vlan_id__)))                              \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "invalid "#__vlan_id__"=%u,"           \
            " range=1-4095, rc=%d\n", __vlan_id__, CLX_E_BAD_PARAMETER);    \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_PORT(__unit__, __port__) do                               \
    {                                                                       \
        if (!HAL_IS_PORT_VALID((__unit__), (__port__)))                     \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid port=%u, rc=%d\n",      \
            __unit__, __port__, CLX_E_BAD_PARAMETER);                       \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_ETH_PORT(__unit__, __port__) do                           \
    {                                                                       \
        if (!HAL_IS_ETH_PORT_VALID((__unit__), (__port__)))                 \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid eth port=%u, rc=%d\n",  \
            __unit__, __port__, CLX_E_BAD_PARAMETER);                       \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_PP_PORT(__unit__, __port__) do                            \
    {                                                                       \
        if (!HAL_IS_PP_PORT_VALID((__unit__), (__port__)))                  \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_ERR, "u=%u, invalid pp port=%u, rc=%d\n",    \
            __unit__, __port__, CLX_E_BAD_PARAMETER);                       \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_PHY_PORT(__unit__, __port__) do                           \
    {                                                                       \
        if (!HAL_IS_PHY_PORT_VALID((__unit__), (__port__)))                 \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid phy port=%u, rc=%d\n",  \
            __unit__, __port__, CLX_E_BAD_PARAMETER);                       \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_PORT_BITMAP(__unit__, __port_bitmap__) do                 \
    {                                                                       \
        CLX_PORT_BITMAP_T __bitmap__;                                       \
                                                                            \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP((__unit__)));        \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__port_bitmap__));               \
                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                             \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid port bitmap, rc=%d\n",  \
            __unit__, CLX_E_BAD_PARAMETER);                                 \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_ETH_PORT_BITMAP(__unit__, __port_bitmap__) do             \
    {                                                                       \
        CLX_PORT_BITMAP_T __bitmap__;                                       \
                                                                            \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_ETH((__unit__)));    \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__port_bitmap__));               \
                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                             \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid eth port bitmap, "      \
            "rc=%d\n", __unit__, CLX_E_BAD_PARAMETER);                      \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_PP_PORT_BITMAP(__unit__, __port_bitmap__) do              \
    {                                                                       \
        CLX_PORT_BITMAP_T __bitmap__;                                       \
                                                                            \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_PP((__unit__)));     \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__port_bitmap__));               \
                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                             \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid pp port bitmap, "       \
            "rc=%d\n", __unit__, CLX_E_BAD_PARAMETER);                      \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_PHY_PORT_BITMAP(__unit__, __port_bitmap__) do             \
    {                                                                       \
        CLX_PORT_BITMAP_T __bitmap__;                                       \
                                                                            \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_PHY((__unit__)));    \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__port_bitmap__));               \
                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                             \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid phy port bitmap, "      \
            "rc=%d\n", __unit__, CLX_E_BAD_PARAMETER);                      \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_PTR(__ptr__) do                                           \
    {                                                                       \
        if (NULL == (__ptr__))                                              \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, #__ptr__" is null pointer, rc=%d\n",   \
            CLX_E_BAD_PARAMETER);                                           \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_ENUM_RANGE(__value__, __max__) do                         \
    {                                                                       \
        if ((__value__) >= (__max__))                                       \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "invalid "#__value__"=%u, range=0-%u," \
            " rc=%d\n", __value__, ((__max__) - 1), CLX_E_BAD_PARAMETER);   \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_MIN_MAX_RANGE(__value__, __min__, __max__) do             \
    {                                                                       \
        if ( ((__value__) > (__max__))  ||                                  \
             ((__value__) < (__min__)) )                                    \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "invalid "#__value__"=%u, range=%u-%u,"\
            " rc=%d\n", __value__, (UI32_T)__min__, (UI32_T)__max__,        \
            CLX_E_BAD_PARAMETER);                                           \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_BOOL(__value__) do                                        \
    {                                                                       \
        if (((FALSE) != (__value__)) &&                                     \
            ((TRUE)  != (__value__)))                                       \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, #__value__"=%u isn't bool, rc=%d\n",   \
            __value__, CLX_E_BAD_PARAMETER);                                \
            return  CLX_E_BAD_PARAMETER;                                    \
        }                                                                   \
    } while (0)

#define HAL_CHECK_INIT(__unit__, __module_id__) do                          \
    {                                                                       \
        if (HAL_INIT_STAGE_NONE ==                                          \
            HAL_MODULE_INITED((__unit__), (__module_id__)))                 \
        {                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, %s module isn't inited, "       \
            "rc=%d\n", __unit__, clx_module_getModuleName(__module_id__),   \
            CLX_E_NOT_INITED);                                              \
            return  CLX_E_NOT_INITED;                                       \
        }                                                                   \
    } while (0)

#define HAL_BANK_BMP_ID(idx)        (1U << idx)  /* idx is 0, 1, 2, or 3 */
#define HAL_BANK_BMP                (HAL_BANK_BMP_ID(0)|HAL_BANK_BMP_ID(1)|HAL_BANK_BMP_ID(2)|HAL_BANK_BMP_ID(3))

#define HAL_TBL_INFO(unit, tbl_id)                  _ext_chip_control_block[unit].pptr_tbl_info[tbl_id]
#define HAL_TBL_KEY_INFO(unit, tbl_id)              _ext_chip_control_block[unit].pptr_tbl_key_info[tbl_id]
#define HAL_SDB_INFO(unit, tbl_id, plane_id)        _ext_chip_control_block[unit].ppptr_sdb_info[tbl_id][plane_id]
#define HAL_SEMA_INFO(unit, tbl_id)                 &(_ext_chip_control_block[unit].ptr_sema_id[tbl_id])
#define HAL_ALLOC_INFO(unit, tbl_id)                _ext_chip_control_block[unit].ptr_alloc_info->ptr_alloc_tbl[tbl_id]
#define HAL_TCAM_INFO(unit, idx)                    _ext_chip_control_block[unit].ptr_tcam_meta_info[idx]
#define HAL_HASH_INFO(unit, idx)                    _ext_chip_control_block[unit].ptr_hash_meta_info[idx]
#define HAL_ALLOC_ENTRY_NUM(unit)                   _ext_chip_control_block[unit].ptr_alloc_info->entry_num
#define HAL_HASH_TYPE_L2_BMP(unit)                  _ext_chip_control_block[unit].ptr_hash_info->l2_bmp
#define HAL_HASH_TYPE_L2_GROUP_BMP(unit)            _ext_chip_control_block[unit].ptr_hash_info->l2_grp_bmp
#define HAL_HASH_TYPE_L3_IPV6_128_BMP(unit)         _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_128_bmp
#define HAL_HASH_TYPE_L3_IPV6_64_BMP(unit)          _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_64_bmp
#define HAL_HASH_TYPE_L3_NO_PREFIX_BMP(unit)        _ext_chip_control_block[unit].ptr_hash_info->l3_no_prefix_bmp
#define HAL_HASH_TYPE_L3_RPF_BMP(unit)              _ext_chip_control_block[unit].ptr_hash_info->l3_rpf_bmp
#define HAL_HASH_TYPE_SECURITY_BMP(unit)            _ext_chip_control_block[unit].ptr_hash_info->security_bmp
#define HAL_HASH_TYPE_FLOW_BMP(unit)                _ext_chip_control_block[unit].ptr_hash_info->flow_bmp
#define HAL_OBJ_INFO_PTR(unit)                      _ext_chip_control_block[unit].ptr_obj_info
#define HAL_LCL_INTF_AVL(unit)                      _ext_chip_control_block[unit].ptr_obj_info->ptr_lcl_intf_avl
#define HAL_LCL_INTF_INFO_AVL(unit)                 _ext_chip_control_block[unit].ptr_obj_info->ptr_lcl_intf_info_avl
#define HAL_INIT_STAGE(unit)                        _ext_chip_control_block[unit].init_stage
#define HAL_MODULE_INFO(unit, module_id)            _ext_chip_control_block[unit].ptr_module_info[module_id]
#define HAL_ETH_MACRO_INFO_PTR(unit) \
        _ext_chip_control_block[unit].ptr_eth_macro_info
#define HAL_ETH_MACRO_NUM(unit) \
        _ext_chip_control_block[unit].ptr_eth_macro_info->macro_num
#define HAL_ETH_MACRO_MAP_INFO(unit, eth_macro) \
        _ext_chip_control_block[unit].ptr_eth_macro_info->ptr_macro_map[eth_macro]

#define HAL_MODULE_INITED(__unit__, __module__)     (HAL_MODULE_INFO(__unit__, __module__).inited)

#define HAL_TBL_ADDR(__unit__, __tbl__, __inst__, __subinst__, __idx__)     \
       ( HAL_TBL_INFO((__unit__), __tbl__)->table_addr                      \
       + HAL_TBL_INFO((__unit__), __tbl__)->slot_size*(__inst__)            \
       + HAL_TBL_INFO((__unit__), __tbl__)->subinst_offset*(__subinst__)    \
       + HAL_TBL_INFO((__unit__), __tbl__)->entry_offset*(__idx__))

#define HAL_FUNC_CALL(__unit__, __module__, __func__, __param__) ({                                                 \
    CLX_ERROR_NO_T __rc = CLX_E_OK;                                                                                 \
    if ((NULL == PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec) ||                                           \
    (NULL == PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec->hal_##__module__##_##__func__))                  \
    {                                                                                                               \
        __rc = CLX_E_NOT_SUPPORT;                                                                                   \
    }                                                                                                               \
    else                                                                                                            \
    {                                                                                                               \
        DIAG_PRINT(HAL_DBG_INFO,"[N]\n");                                                                           \
        __rc = (PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec->hal_##__module__##_##__func__ __param__);     \
    }                                                                                                               \
    __rc;                                                                                                           \
    })

#define HAL_CMN_FUNC_CALL(__unit__, __module__, __func__, __param__) ({                                                 \
        CLX_ERROR_NO_T __rc = CLX_E_OK;                                                                                 \
        if ((NULL == PTR_HAL_CMN_FUNC_VECTOR(__unit__)->__module__##_cmn_func_vec) ||                                           \
        (NULL == PTR_HAL_CMN_FUNC_VECTOR(__unit__)->__module__##_cmn_func_vec->hal_##__module__##_##__func__))                  \
        {                                                                                                               \
            __rc = CLX_E_NOT_SUPPORT;                                                                                   \
        }                                                                                                               \
        else                                                                                                            \
        {                                                                                                               \
            DIAG_PRINT(HAL_DBG_INFO,"[N]\n");                                                                           \
            __rc = (PTR_HAL_CMN_FUNC_VECTOR(__unit__)->__module__##_cmn_func_vec->hal_##__module__##_##__func__ __param__);     \
        }                                                                                                               \
        __rc;                                                                                                           \
        })

/* Macros for chip related information */
#define HAL_DEVICE_CHIP_ID(unit)                PTR_HAL_EXT_CHIP_INFO(unit)->device_id
#define HAL_DEVICE_REV_ID(unit)                 PTR_HAL_EXT_CHIP_INFO(unit)->revision_id
#define HAL_DEVICE_FREQ(unit)                   PTR_HAL_EXT_CHIP_INFO(unit)->frequency
#define HAL_DEVICE_MODE(unit)                   PTR_HAL_EXT_CHIP_INFO(unit)->mode
#define HAL_HW_CHIP_ID(unit)                    PTR_HAL_EXT_CHIP_INFO(unit)->hw_chip_id
#define HAL_LAG_EPOCH_ID(unit)                  PTR_HAL_EXT_CHIP_INFO(unit)->lag_epoch_id
#define HAL_DIE_BMP(unit)                       PTR_HAL_EXT_CHIP_INFO(unit)->die_bmp
#define HAL_BIN_BMP(unit)                       PTR_HAL_EXT_CHIP_INFO(unit)->bin_bmp
#define HAL_PLANE_BMP(unit)                     PTR_HAL_EXT_CHIP_INFO(unit)->plane_bmp
#define HAL_ETH_MACRO_BMP(unit)                 PTR_HAL_EXT_CHIP_INFO(unit)->mac_macro_bmp
#define HAL_CPU_PORT(unit)                      PTR_HAL_EXT_CHIP_INFO(unit)->cpu_port
#define HAL_PORT_BMP(unit)                      PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap
#define HAL_PORT_BMP_ETH(unit)                  PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_eth
#define HAL_PORT_BMP_PP(unit)                   PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_pp
#define HAL_PORT_BMP_PHY(unit)                  PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_phy
#define HAL_PORT_BMP_TOTAL(unit)                PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_total
#define HAL_PLANE_ETH_MACRO_NUM(unit, plane)    PTR_HAL_EXT_CHIP_INFO(unit)->plane_mac_macro_num
#define HAL_PLANE_FP_NUM(unit, plane)           PTR_HAL_EXT_CHIP_INFO(unit)->plane_fp_num
#define HAL_PLANE_ETH_PORT_NUM(unit)            PTR_HAL_EXT_CHIP_INFO(unit)->plane_eth_port_num
#define HAL_PORT_MAP_INFO(unit, port)           PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port]
#define HAL_CPI_PORT(unit, cpi_idx)             PTR_HAL_EXT_CHIP_INFO(unit)->cpi_port[cpi_idx]
#define HAL_PLANE_PORT_MAP_INFO(unit)           PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info
#define HAL_SERDES_PORT_MAP_INFO(unit)          PTR_HAL_EXT_CHIP_INFO(unit)->ppptr_serdes_port_map_info
#define HAL_CHIP_INFO_FLAGS(unit)               PTR_HAL_EXT_CHIP_INFO(unit)->flags
#define HAL_PLANE_PORT_BMP(unit, plane)         PTR_HAL_EXT_CHIP_INFO(unit)->ptr_plane_port_bitmap[plane]
#define HAL_RC_PORT(unit, rcp_idx)              PTR_HAL_EXT_CHIP_INFO(unit)->rc_port[rcp_idx]

/* Macro to check CPI port working mode */
#define HAL_IS_CPI_PORT_ETH_MODE(unit, cpi_port)                            \
    ( (cpi_port == HAL_CPI_PORT(unit, HAL_CPI_PORT_0)) ?                    \
    (HAL_CHIP_INFO_FLAGS(unit) & HAL_CHIP_INFO_FLAGS_CPI0_MODE_ETH)         \
    : (HAL_CHIP_INFO_FLAGS(unit) & HAL_CHIP_INFO_FLAGS_CPI1_MODE_ETH) )


typedef TABLE_INFO_T     CDB_TABLE_T;
typedef PACKING_INFO_T   CDB_FIELD_T;
typedef TCAM_TBL_META_T  CDB_TCAM_T;
typedef HASH_TBL_META_T  CDB_HASH_T;
#define CDB_TABLE        HAL_TBL_INFO
#define CDB_TCAM         HAL_TCAM_INFO
#define CDB_HASH         HAL_HASH_INFO

#define HAL_IS_DEVICE_DAWN_FAMILY(unit)                                   \
        ((HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8363) ||              \
        (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8365)  ||              \
        (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8366)  ||              \
        (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8367)  ||              \
        (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8368)  ||              \
        (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8369))

#define HAL_IS_DEVICE_LIGHTNING_FAMILY(unit)                                     \
        ((HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8571) ||             \
         (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8573) ||             \
         (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8575) ||             \
         (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8577) ||             \
         (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8578) ||             \
         (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8579))

#define HAL_WARM_BOOT_FLAGS_INIT                   (1U << 0)
#define HAL_WARM_BOOT_FLAGS_DEINIT                 (1U << 1)
#define HAL_WARM_INIT(__value__)                                                     \
        ((TRUE ==__value__) ? (_ext_warm_boot_flag |= HAL_WARM_BOOT_FLAGS_INIT) :    \
                              (_ext_warm_boot_flag &= ~HAL_WARM_BOOT_FLAGS_INIT))

#define HAL_WARM_DEINIT(__value__)                                                   \
        ((TRUE == __value__) ? (_ext_warm_boot_flag |= HAL_WARM_BOOT_FLAGS_DEINIT) : \
                               (_ext_warm_boot_flag &= ~HAL_WARM_BOOT_FLAGS_DEINIT))

#define HAL_IS_WARM_INIT()      (_ext_warm_boot_flag & HAL_WARM_BOOT_FLAGS_INIT)
#define HAL_IS_WARM_DEINIT()    (_ext_warm_boot_flag & HAL_WARM_BOOT_FLAGS_DEINIT)

/* Macros for CLX port related attributes */
#define HAL_CL_PORT_TO_DIE(unit, port)          PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].die
#define HAL_CL_PORT_TO_BIN(unit, port)          PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].bin
#define HAL_CL_PORT_TO_PLANE(unit, port)        PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].plane
#define HAL_CL_PORT_TO_MAC_MACRO(unit, port)    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].hw_mac_macro
#define HAL_CL_PORT_TO_TM_MAC_MACRO(unit, port) PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].tm_mac_macro
#define HAL_CL_PORT_TO_SERDES_MACRO(unit, port) PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].serdes_mac_macro
#define HAL_CL_PORT_TO_MACRO_PORT(unit, port)   PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].lane
#define HAL_CL_PORT_TO_TM_MAC_PORT(unit, port)  PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].mpid
#define HAL_CL_PORT_TO_PLANE_PORT(unit, port)   PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].ppid

#define HAL_CL_PORT_TO_DP_PLANE_PORT(unit, port)  \
        ((HAL_CPI_PLANE_PORT == PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].ppid) ? \
          HAL_CPI_DP_PLANE_PORT : PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].ppid)

#define HAL_PLANE_PORT_TO_CL_PORT(unit, plane, plane_port)                  \
        PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info[plane][plane_port]

/* In CL8570 PP, CPI plane_port is 64 for non-ITM bubble, and plane_port is 32 for ITM bubble.
 * It might need update when there are multiple CPI ports in a plane for later chips
 */
#define HAL_DP_PLANE_PORT_TO_CL_PORT(unit, plane, plane_port)                           \
        ((!HAL_IS_DEVICE_DAWN_FAMILY(unit)) && (plane_port == HAL_CPI_DP_PLANE_PORT) ?                                        \
         PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info[plane][HAL_CPI_PLANE_PORT] :  \
         PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info[plane][plane_port])

#define HAL_SERDES_PORT_TO_CL_PORT(unit, die, serdes_macro, lane)           \
        PTR_HAL_EXT_CHIP_INFO(unit)->ppptr_serdes_port_map_info[die][serdes_macro][lane]

/* Resource management related definitions */
#ifdef  HAL_ENABLE_RESOURCE_LOCK
#define HAL_COMMON_CREATE_LOCK_RESOURCE(ptr_sema_name, ptr_semaphore_id)    \
        osal_createSemaphore(ptr_sema_name, 1, ptr_semaphore_id)
#define HAL_COMMON_DESTROY_LOCK_RESOURCE(ptr_semaphore_id)                  \
        osal_destroySemaphore(ptr_semaphore_id)
#define HAL_COMMON_LOCK_RESOURCE(ptr_sema, timeout)                         \
        osal_takeSemaphore((ptr_sema), (timeout))
#define HAL_COMMON_FREE_RESOURCE(ptr_sema)                                  \
        osal_giveSemaphore((ptr_sema))
#else
#define HAL_COMMON_CREATE_LOCK_RESOURCE(ptr_sema_name, ptr_semaphore_id)    CLX_E_OK
#define HAL_COMMON_DESTROY_LOCK_RESOURCE(ptr_semaphore_id)                  CLX_E_OK
#define HAL_COMMON_LOCK_RESOURCE(ptr_sema, timeout)                         CLX_E_OK
#define HAL_COMMON_FREE_RESOURCE(ptr_sema)                                  CLX_E_OK
#endif /* HAL_ENABLE_RESOURCE_LOCK */

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_CHIP_MODE_SIG = 0,
    HAL_CHIP_MODE_PORT,
    HAL_CHIP_MODE_FAB,
    HAL_CHIP_MODE_LAST
} HAL_CHIP_MODE_T;

typedef enum
{
    HAL_PLANE_MODE_ETH_SIG = 0,
    HAL_PLANE_MODE_ETH_LEAF,
    HAL_PLANE_MODE_FAB_LEAF,
    HAL_PLANE_MODE_FAB_SPINE,
    HAL_PLANE_MODE_LAST
} HAL_PLANE_MODE_T;

typedef struct HAL_PORT_MAP_S
{
    UI32_T              valid;
#define HAL_PORT_MAP_FLAGS_INIT_ACTIVE  (1U << 0)
#define HAL_PORT_MAP_FLAGS_GUARANTEE    (1U << 1)
#define HAL_PORT_MAP_FLAGS_CPI          (1U << 2)
#define HAL_PORT_MAP_FLAGS_RCP          (1U << 3)

    UI32_T              flags;
    UI32_T              eth_macro;       /* eth macro id shown in schematic ethx/ethc */
    UI32_T              lane; /* lane id */
    CLX_PORT_SPEED_T    max_speed;
    /* attributes of this CLX port */
    UI32_T              die; /* die index (die is same as bin on CL8360) */
    UI32_T              bin; /* bin index */
    UI32_T              plane; /* plane index */
    UI32_T              hw_mac_macro; /* hw mac macro index */
    UI32_T              tm_mac_macro; /* tm mac macro index */
    UI32_T              serdes_mac_macro; /* serdes mac macro index */
    UI32_T              mpid; /* MAC port id */
    UI32_T              ppid; /* plane port id */
}HAL_PORT_MAP_T;

/* used to record chip's macro bitmap */
typedef UI32_T HAL_MAC_MACRO_BITMAP_T[HAL_MAX_MAC_MACRO_WORD_SIZE];

/* used to record chip plane port bitmap */
typedef UI32_T HAL_PLANE_PORT_BITMAP_T[HAL_MAX_PLANE_PORT_WORD_SIZE];

typedef struct
{
    UI32_T                  vendor_id;                      /* vendor ID                                */
    UI32_T                  device_id;                      /* device ID                                */
    UI32_T                  revision_id;                    /* revision ID                              */
    UI32_T                  hw_chip_id;                     /* hw chip ID(6 bits), used for pkt module  */
    UI32_T                  lag_epoch_id;                   /* lag epoch ID(1 bit), used for pkt module */
    UI32_T                  frequency;                      /* frequency (MHz)                          */
    UI32_T                  mode;                           /* 720G or 960G mode                        */
#define HAL_CHIP_INFO_FLAGS_USE_UNIT_PORT       (1U << 0)
#define HAL_CHIP_INFO_FLAGS_CPI0_MODE_ETH       (1U << 1)
#define HAL_CHIP_INFO_FLAGS_CPI1_MODE_ETH       (1U << 2)
#define HAL_CHIP_INFO_FLAGS_LAG_EPOCH           (1U << 3)
    UI32_T                  flags;
    UI32_T                  die_bmp[1];                     /* chip die bitmap                          */
    UI32_T                  bin_bmp[1];                     /* chip bin bitmap                          */
    UI32_T                  plane_bmp[1];                   /* chip plane bitmap                        */
    HAL_MAC_MACRO_BITMAP_T  mac_macro_bmp;                  /* chip mac/serdes macro bitmap             */
    HAL_MAC_MACRO_BITMAP_T  mac_macro_100g_bmp;             /* chip mac macro support 100G              */
    UI32_T                  plane_mac_macro_num;            /* plane mac macro numbers                  */
    UI32_T                  plane_fp_num;                   /* plane front port numbers                 */
    UI32_T                  plane_eth_port_num;             /* plane port eth numbers                   */
    UI32_T                  plane_max_port_num;             /* plane maximum port numbers               */
    UI32_T                  cpu_port;                       /* cpu port id                              */
    UI32_T                  total_port;                     /* total port numbers                       */
    CLX_PORT_BITMAP_T       port_bitmap;                    /* total active port bitmap                 */
    CLX_PORT_BITMAP_T       port_bitmap_eth;                /* total active ether port bitmap           */
    CLX_PORT_BITMAP_T       port_bitmap_pp;                 /* total active plane port bitmap (PP)      */
    CLX_PORT_BITMAP_T       port_bitmap_phy;                /* total active PHY (Serdes) port bitmap    */
    CLX_PORT_BITMAP_T       port_bitmap_total;              /* total port bitmap (active and inactive)  */
    HAL_PORT_MAP_T          *ptr_port_map_info;             /* port and mac/lane map info               */
    UI32_T                  cpi_port[HAL_MAX_CPI_PORT_COUNT];
    UI32_T                  **pptr_pport_map_info;          /* plane port to CL port map                */
    UI32_T                  ***ppptr_serdes_port_map_info;  /* serdes lane to CL port map               */
    HAL_PLANE_PORT_BITMAP_T *ptr_plane_port_bitmap;         /* plane active port bitmap (per-plane)     */
    UI32_T                  phy_di_num;                     /* per chip used physical port di num       */
    UI32_T                  lcl_di[CLX_PORT_NUM];           /* local port => local di                   */
    UI32_T                  di_map[CLX_PORT_NUM];           /* local di   => local port                 */
    UI32_T                  *ptr_plane_mode;                /* chassis plane mode                       */
    UI32_T                  rc_port[HAL_MAX_RC_PORT_COUNT];
} HAL_CHIP_INFO_T;

typedef enum
{
    HAL_INIT_STAGE_NONE         = 0,
    HAL_INIT_STAGE_LOW_LEVEL    = (0x1U << 0),
    HAL_INIT_STAGE_TASK_RSRC    = (0x1U << 1),
    HAL_INIT_STAGE_MODULE       = (0x1U << 2),
    HAL_INIT_STAGE_TASK         = (0x1U << 3),
} HAL_INIT_STAGE_T;

typedef struct
{
    HAL_INIT_STAGE_T            inited;
} HAL_MODULE_INFO_T;

typedef struct {
    UI32_T l2_bmp;
    UI32_T l2_grp_bmp;
    UI32_T l3_ipv6_128_bmp;
    UI32_T l3_ipv6_64_bmp;
    UI32_T l3_no_prefix_bmp;
    UI32_T l3_rpf_bmp;
    UI32_T security_bmp;
    UI32_T flow_bmp;
}HAL_HASH_INFO_T;

typedef struct HAL_INTF_OBJ_INFO_S
{
    CLX_PORT_TYPE_T   type;
    UI32_T            di; /* use di to put np port for CL325x */
    UI32_T            is_lag;
    UI32_T            lag_id;
    UI32_T            vm_id;
    UI32_T            encap_idx;
}HAL_INTF_OBJ_INFO_T;

typedef struct HAL_OBJ_LCL_INTF_S
{
    CLX_PORT_TYPE_T   type;
    UI32_T            port_id;
    UI32_T            is_lag;
    UI32_T            vm_id;
    UI32_T            lcl_intf;
    UI32_T            encap_idx;
}HAL_OBJ_LCL_INTF_T;

typedef struct HAL_OBJ_INFO_S
{
    CLX_SEMAPHORE_ID_T    *ptr_obj_sema_id;
    CMLIB_AVL_HEAD_T      *ptr_lcl_intf_avl;
    CMLIB_AVL_HEAD_T      *ptr_lcl_intf_info_avl;
}HAL_OBJ_INFO_T;

typedef struct
{
    HAL_CHIP_INFO_T        *ptr_chip_info;      /* chip information pointer */
    HAL_DRIVER_T           *ptr_driver_info;    /* chip driver information pointer */
    TABLE_INFO_T           **pptr_tbl_info;     /* table information pointer */
    PACKING_INFO_T         **pptr_tbl_key_info; /* table key information pointer for hash */
    TCAM_TBL_META_T        *ptr_tcam_meta_info; /* tcam meta info pointer */
    HASH_TBL_META_T        *ptr_hash_meta_info; /* tcam hash info pointer */
    UI32_T                 ***ppptr_sdb_info;   /* hw shadow database pointer */
    CLX_SEMAPHORE_ID_T     *ptr_sema_id;        /* semaphore information pointer */
    HAL_ALLOC_INFO_T       *ptr_alloc_info;
    HAL_INIT_STAGE_T        init_stage;
    HAL_MODULE_INFO_T      *ptr_module_info;    /* module information pointer */
    HAL_HASH_INFO_T        *ptr_hash_info;
    HAL_ETH_MACRO_INFO_T   *ptr_eth_macro_info; /* pointer of mac macro information of this device */
    HAL_OBJ_INFO_T         *ptr_obj_info;
} HAL_CHIP_CB_T;

typedef struct
{
    UI32_T    field_id;
    union
    {
        UI32_T    *ptr_value;
        UI32_T    value;
    };
} HAL_TBL_FIELD_T;

typedef enum
{
    HAL_TCAM_TYPE_CELL_T     = 0,
    HAL_TCAM_TYPE_CELL_C,
    HAL_TCAM_TYPE_CELL_LAST
} HAL_TCAM_TYPE_T;

typedef struct {
    UI32_T    tbl_id;
    UI32_T    entry_idx;
    UI32_T    *ptr_data_buf;
    UI32_T    *ptr_mask_buf;
}HAL_TBL_TCAM_TBL_T;

typedef struct {
    UI32_T    tbl_id;
    UI32_T    entry_idx;
    UI32_T    *ptr_data_buf;
}HAL_TBL_SRAM_TBL_T;

typedef struct {
    UI32_T       tbl_id;
    UI32_T       entry_idx;
    UI32_T       field_num;
    CDB_FVP_T    *ptr_data_field;
    CDB_FVP_T    *ptr_mask_field;
}HAL_TBL_TCAM_M_FIELD_T;

typedef struct {
    UI32_T       tbl_id;
    UI32_T       entry_idx;
    UI32_T       field_num;
    CDB_FVP_T    *ptr_field;
}HAL_TBL_SRAM_M_FIELD_T;

typedef enum
{
    HAL_HASH_TYPE_L2 = 0,
    HAL_HASH_TYPE_L2_GROUP,
    HAL_HASH_TYPE_L3_IPV6_128,
    HAL_HASH_TYPE_L3_IPV6_64,
    HAL_HASH_TYPE_L3_NO_PREFIX,
    HAL_HASH_TYPE_L3_RPF,
    HAL_HASH_TYPE_SECURITY,
    HAL_HASH_TYPE_FLOW,
    HAL_HASH_TYPE_LAST
}HAL_HASH_TYPE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   hal_init
 * PURPOSE:
 *      hal_init() is responsible for HAL initialization, it will do
 *      the following:
 *      1. Construct chip control block.
 *      2. Initialize chip information.
 *      3. Initialize driver information.
 *
 * INPUT:
 *      unit          -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize HAL.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
hal_init(
    const UI32_T unit);

/* FUNCTION NAME:   hal_deinit
 * PURPOSE:
 *      hal_deinit() is responsible for HAL de-initialization, it will
 *      do the following:
 *      1. Reset driver information.
 *      2. Reset chip information.
 *      3. Free the constructed chip control block.
 *
 * INPUT:
 *      unit          -- The unit number that would like to de-initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully de-initialize HAL.
 *      CLX_E_OTHERS  -- Fail to complete de-initialization procedure.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_deinit(
    const UI32_T unit);

/* FUNCTION NAME:   hal_getSystemUnitNum
 * PURPOSE:
 *      hal_getSystemUnitNum() is an API that allows to get current valid
 *      unit number information for this system.
 *
 * INPUT:
 *      None
 * OUTPUT:
 *      ptr_unit_num         -- The total unit number information.
 * RETURN:
 *      CLX_E_OK             -- Get the system unit information successfully.
 *      CLX_E_BAD_PARAMETER  -- Parameter, ptr_unit_num, is a NULL pointer.
 *
 * NOTES:
 *      Please note this API will return current valid unit number
 *      information. For example, if there are two units on this system,
 *      it will return two from this API. If one of these two units has been
 *      removed, it will return one from this API.
 *
 */
CLX_ERROR_NO_T
hal_getSystemUnitNum(
    UI32_T *ptr_unit_num);

/* FUNCTION NAME:   hal_getUnitPortNum
 * PURPOSE:
 *      hal_getUnitPortNum() is an API that allows to get total port
 *      number information for this unit.
 *
 * INPUT:
 *      unit                 -- The specified unit number.
 * OUTPUT:
 *      ptr_port_num         -- The total port number information on the specified
 *                              unit.
 * RETURN:
 *      CLX_E_OK             -- Get the unit's port number information successfully.
 *      CLX_E_BAD_PARAMETER  -- Parameter, ptr_port_num, is a NULL pointer.
 *      CLX_E_OTHERS         -- Fail to get the port number information.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_getUnitPortNum(
    const UI32_T unit,
    UI32_T       *ptr_port_num);

/* FUNCTION NAME:   hal_dumpChipInfo
 * PURPOSE:
 *      hal_dumpChipInfo() is a function to dump chip information.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Dump chip information successfully.
 *      CLX_E_OTHERS  -- Fail to dump chip information.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dumpChipInfo(
    const UI32_T unit);

/* FUNCTION NAME:   hal_dumpDriverInfo
 * PURPOSE:
 *      hal_dumpDriverInfo() is a function to dump driver information.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Dump driver information successfully.
 *      CLX_E_OTHERS  -- Fail to dump driver information.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dumpDriverInfo(
    const UI32_T unit);

/* FUNCTION NAME:   hal_dumpPortMapInfo
 * PURPOSE:
 *      hal_dumpPortMapInfo() is a function to dump port mapping information.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Dump port mapping information successfully.
 *      CLX_E_OTHERS  -- Fail to dump port mapping information.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dumpPortMapInfo(
    const UI32_T unit);

/* FUNCTION NAME:   hal_readTbl
 * PURPOSE:
 *      hal_readTbl() is responsible for read whole entry from hw shadow database
 *      or hw.
 *
 * INPUT:
 *      unit                -- The unit number.
 *      inst_idx          -- The instance index.
 *      sub_idx          -- The sub instance index.
 *      tbl_id              -- The table id.
 *      entry_idx        -- The entry index in table.
 * OUTPUT:
 *      ptr_src_buf  -- The information of table entry
 * RETURN:
 *      CLX_E_OK          -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_readTbl(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    sub_idx,
    const UI32_T    tbl_id,
    const UI32_T    entry_idx,
    UI32_T          *ptr_src_buf);

/* FUNCTION NAME:   hal_writeTbl
 * PURPOSE:
 *      hal_writeTbl() is responsible for write whole entry to hw and hw shadow
 *      database
 *
 * INPUT:
 *      unit                -- The unit number.
 *      inst_idx          -- The instance index.
 *      sub_idx          -- The sub instance index.
 *      tbl_id              -- The table id.
 *      entry_idx        -- The entry index in table.
 *      ptr_src_buf     -- The information of table entry.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK          -- Successfully write table.
 *      CLX_E_OTHERS  -- Fail to write table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_writeTbl(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    sub_idx,
    const UI32_T    tbl_id,
    const UI32_T    entry_idx,
    const UI32_T    *ptr_src_buf);

/* FUNCTION NAME:   hal_readTcamTblEntry
 * PURPOSE:
 *      hal_readTcamTblEntry() is responsible for read whole entry from hw
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      tbl_id                      -- The table id.
 *      entry_idx                -- The entry index in table.
*       ptr_tcam_entry      -- The information of data with HAL_TBL_TCAM_TBL_T structure.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_readTcamTblEntry(
    const UI32_T                unit,
    HAL_TBL_TCAM_TBL_T          *ptr_tcam_entry,
    HAL_TBL_SRAM_TBL_T          *ptr_sram_entry);

/* FUNCTION NAME:   hal_readTcamTblMultiFields
 * PURPOSE:
 *      hal_readTcamTblMultiFields() is responsible for read multiple fields of table entry from hw
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      ptr_tcam_field       -- The information of data with HAL_TBL_TCAM_M_FIELD_T structure.
 *      ptr_sram_field       -- The information of mask with HAL_TBL_SRAM_M_FIELD_T structure.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK          -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_readTcamTblMultiFields(
    const UI32_T                   unit,
    HAL_TBL_TCAM_M_FIELD_T         *ptr_tcam_field,
    HAL_TBL_SRAM_M_FIELD_T         *ptr_sram_field);

/* FUNCTION NAME:   hal_readHwTcamTblEntry
 * PURPOSE:
 *      hal_readHwTcamTblEntry() is responsible for read whole entry from hw
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      tbl_id                      -- The table id.
 *      entry_idx                -- The entry index in table.
*       ptr_tcam_entry      -- The information of data with HAL_TBL_TCAM_TBL_T structure.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_readHwTcamTblEntry(
    const UI32_T                unit,
    HAL_TBL_TCAM_TBL_T          *ptr_tcam_entry);

/* FUNCTION NAME:   hal_readHwTcamTblMultiFields
 * PURPOSE:
 *      hal_readHwTcamTblMultiFields() is responsible for read multiple fields of table entry from hw
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      ptr_tcam_field       -- The information of data with HAL_TBL_TCAM_M_FIELD_T structure.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK          -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_readHwTcamTblMultiFields(
    const UI32_T                   unit,
    HAL_TBL_TCAM_M_FIELD_T         *ptr_tcam_field);

/* FUNCTION NAME:   hal_writeTcamTblEntry
 * PURPOSE:
 *      hal_writeTcamTblEntry() is responsible for write table entry with tcam type to hw and
 *      hw shadow database
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      tbl_id                      -- The table id.
 *      entry_idx                -- The entry index in table.
*       ptr_tcam_entry      -- The information of data with HAL_TBL_TCAM_TBL_T structure.
 *      ptr_sram_entry      -- The information of data with HAL_TBL_SRAM_TBL_T structure.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_writeTcamTblEntry(
    const UI32_T                unit,
    HAL_TBL_TCAM_TBL_T          *ptr_tcam_entry,
    HAL_TBL_SRAM_TBL_T          *ptr_sram_entry);

/* FUNCTION NAME:   hal_writeTcamTblMultiFields
 * PURPOSE:
 *      hal_writeTcamTblMultiFields() is responsible for write multiple fields of table entry with tcam type to hw and
 *      hw shadow database
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      ptr_tcam_field       -- The information of data with HAL_TBL_TCAM_M_FIELD_T structure.
 *      ptr_sram_field       -- The information of mask with HAL_TBL_SRAM_M_FIELD_T structure.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK          -- Sucessfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_writeTcamTblMultiFields(
    const UI32_T                   unit,
    HAL_TBL_TCAM_M_FIELD_T         *ptr_tcam_field,
    HAL_TBL_SRAM_M_FIELD_T         *ptr_sram_field);

/* FUNCTION NAME:   hal_writeHwTcamTblEntry
 * PURPOSE:
 *      hal_writeHwTcamTblEntry() is responsible for write table entry with tcam type to hw
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      tbl_id                      -- The table id.
 *      entry_idx                -- The entry index in table.
*       ptr_tcam_entry      -- The information of data with HAL_TBL_TCAM_TBL_T structure.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_writeHwTcamTblEntry(
    const UI32_T                unit,
    HAL_TBL_TCAM_TBL_T          *ptr_tcam_entry);

/* FUNCTION NAME:   hal_writeHwTcamTblMultiFields
 * PURPOSE:
 *      hal_writeHwTcamTblMultiFields() is responsible for write multiple fields of table entry with tcam type to hw
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      ptr_tcam_field       -- The information of data with HAL_TBL_TCAM_M_FIELD_T structure.
 *      ptr_sram_field       -- The information of mask with HAL_TBL_SRAM_M_FIELD_T structure.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK          -- Sucessfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_writeHwTcamTblMultiFields(
    const UI32_T                   unit,
    HAL_TBL_TCAM_M_FIELD_T         *ptr_tcam_field);

/* FUNCTION NAME:   hal_sema_lock
 * PURPOSE:
 *      hal_sema_lock() is responsible for lock specific table
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      tbl_id                      -- The table id.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_sema_lock(
    const UI32_T unit,
    const UI32_T tbl_id);

/* FUNCTION NAME:   hal_sema_unlock
 * PURPOSE:
 *      hal_sema_unlock() is responsible for unlock specific table
 *
 * INPUT:
 *      unit                        -- The unit number.
 *      tbl_id                      -- The table id.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_sema_unlock(
    const UI32_T unit,
    const UI32_T tbl_id);

/* FUNCTION NAME:   hal_writeTcamTblValidBit
 * PURPOSE:
 *      hal_writeTcamTblValidBit() is responsible for writing valid bit
 *      of Tcam Entry.
 *
 * INPUT:
 *      unit                   -- The unit number.
 *      inst_idx               -- The instance index.
 *      sub_idx                -- The sub index.
 *      tbl_id                 -- The table id.
 *      entry_idx              -- The entry index.
 *      valid_bit              -- 1 or 0.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK               -- Successfully init table.
 *      CLX_E_OTHERS           -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_writeTcamTblValidBit(
    const UI32_T             unit,
    const UI32_T             inst_idx,
    const UI32_T             sub_idx,
    const UI32_T             tbl_id,
    const UI32_T             entry_idx,
    const UI32_T             valid_bit);

/* FUNCTION NAME:   hal_readTcamTblValidBit
 * PURPOSE:
 *      hal_readTcamTblValidBit() is responsible for reading valid bit
 *      of Tcam Entry.
 *
 * INPUT:
 *      unit                   -- The unit number.
 *      inst_idx               -- The instance index.
 *      sub_idx                -- The sub index.
 *      tbl_id                 -- The table id.
 *      entry_idx              -- The entry index.
 * OUTPUT:
 *      ptr_valid              -- valid_bit.
 * RETURN:
 *      CLX_E_OK               -- Successfully init table.
 *      CLX_E_OTHERS           -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_readTcamTblValidBit(
    const UI32_T             unit,
    const UI32_T             inst_idx,
    const UI32_T             sub_idx,
    const UI32_T             tbl_id,
    const UI32_T             entry_idx,
    UI32_T                   *ptr_valid);

/* FUNCTION NAME:   hal_setHashBankBmp
 * PURPOSE:
 *      hal_setHashBankBmp() is responsible for setting specific hash bank bitmap.
 *
 * INPUT:
 *      unit                  -- The unit number.
 *      type                 -- The hash type.
 *      bank_bmp        -- bank bitmap.
 * OUTPUT:
 *      NULL
 * RETURN:
 *      CLX_E_OK      -- Successfully read table.
 *      CLX_E_OTHERS  -- Fail to read table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_setHashBankBmp(
    const UI32_T             unit,
    const HAL_HASH_TYPE_T    type,
    const UI32_T             bank_bmp);

/* FUNCTION NAME:   hal_updatePortBitmap
 * PURPOSE:
 *      hal_updatePortBitmap is used to update port bitmap
 *
 * INPUT:
 *      unit                -- The chip unit number
 *      port                -- Physical port number
 *      value               -- Bit value (0 or 1)
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK            -- Operation successfully
 *
 * NOTES:
 *      This function only update bitmap of front port.
 *
 */
CLX_ERROR_NO_T
hal_updatePortBitmap(
    const UI32_T            unit,
    const UI32_T            port,
    const UI32_T            value);

/* FUNCTION NAME: hal_packField
 * PURPOSE:
 *      Substitute the specified bits (field) in the entry buffer with the
 *      content in field buffer.
 * INPUT:
 *      unit          -- Unit number.
 *      table_id      -- Table ID.
 *      field_id      -- Field ID.
 *      offset        -- Offset of the field.
 *      length        -- Length of the field.
 *      ptr_entry     -- Pointer to the entry buffer.
 *      ptr_field     -- Pointer to the field buffer.
 * OUTPUT:
 *      ptr_entry     -- Pointer to the entry buffer.
 * RETURN:
 *      None.
 */
void
hal_packField(
    const UI32_T unit,
    const UI32_T table_id,
    const UI32_T field_id,
    const UI32_T offset,
    const UI32_T length,
    UI32_T *ptr_entry,
    const UI32_T *ptr_field);

/* FUNCTION NAME: hal_unpackField
 * PURPOSE:
 *      Extract the specified field from an entry buffer info field buffer.
 * INPUT:
 *      unit          -- Unit number.
 *      table_id      -- Table ID.
 *      field_id      -- Field ID.
 *      offset        -- Offset of the field.
 *      length        -- Length of the field.
 *      ptr_entry     -- Pointer to the entry buffer.
 * OUTPUT:
 *      ptr_field     -- Pointer to the field buffer.
 * RETURN:
 *      None.
 */
void
hal_unpackField(
    const UI32_T unit,
    const UI32_T table_id,
    const UI32_T field_id,
    const UI32_T offset,
    const UI32_T length,
    const UI32_T *ptr_entry,
    UI32_T *ptr_field);

/* FUNCTION NAME: hal_packUi32Field
 * PURPOSE:
 *      Substitute the specified bits (field) in the entry buffer with the
 *      field value.
 * INPUT:
 *      unit          -- Unit number.
 *      table_id      -- Table ID.
 *      field_id      -- Field ID.
 *      offset        -- Offset of the field.
 *      length        -- Length of the field.
 *      ptr_entry     -- Pointer to the entry buffer.
 *      field         -- Field value.
 * OUTPUT:
 *      ptr_entry     -- Pointer to the entry buffer.
 * RETURN:
 *      None.
 */
void
hal_packUi32Field(
    const UI32_T unit,
    const UI32_T table_id,
    const UI32_T field_id,
    const UI32_T offset,
    const UI32_T length,
    UI32_T *ptr_entry,
    const UI32_T field);

/* FUNCTION NAME: hal_unpackUi32Field
 * PURPOSE:
 *      Extract the specified field from an entry buffer.
 * INPUT:
 *      unit          -- Unit number.
 *      table_id      -- Table ID.
 *      field_id      -- Field ID.
 *      offset        -- Offset of the field.
 *      length        -- Length of the field.
 *      ptr_entry     -- Pointer to the entry buffer.
 * OUTPUT:
 *      None.
 * RETURN:
 *      Field value.
 */
UI32_T
hal_unpackUi32Field(
    const UI32_T unit,
    const UI32_T table_id,
    const UI32_T field_id,
    const UI32_T offset,
    const UI32_T length,
    const UI32_T *ptr_entry);

/* FUNCTION NAME: hal_transTcamCom
 * PURPOSE:
 *      Translate tcam cell-t/c view to data/mask view
 *      1. Please use table id whose memory type is "MEMORY_TYPE_TABLE_TCAM_COM".
 * INPUT:
 *      unit          -- Unit number.
 *      table_id      -- Table ID.
 *      ptr_entry     -- Pointer to the entry buffer.
 * OUTPUT:
 *      ptr_entry     -- Pointer to the entry buffer.
 * RETURN:
 *      CLX_E_OK      -- Translate success.
 *      CLX_E_OTHERS  -- Translate fail.
 */
CLX_ERROR_NO_T
hal_transTcamCom(
    const UI32_T    unit,
    const UI32_T    table_id,
    UI32_T          *ptr_entry);

/* FUNCTION NAME:   hal_allocPortDi
 * PURPOSE:
 *      hal_allocPortDi is used to allocate di for a port
 *
 * INPUT:
 *      unit                -- The chip unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Initialized successfully
 *      CLX_E_OTHERS        -- Internal error
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_allocPortDi(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_di);

/* FUNCTION NAME:   hal_updatePortDiMap
 * PURPOSE:
 *      hal_updatePortDiMap is used to update per port used di and di map
 *
 * INPUT:
 *      unit                -- The chip unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Initialized successfully
 *      CLX_E_OTHERS        -- Internal error
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_updatePortDiMap(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    di);

/* FUNCTION NAME:   hal_dumpDb
 * PURPOSE:
 *      hal_dumpDb is used to dump hal swdb
 *
 * INPUT:
 *      unit                -- The chip unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dumpDb(
    const UI32_T    unit,
    const UI32_T    flags);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
*/
extern UI32_T _ext_warm_boot_flag;

extern const UI32_T _ext_hal_zero_buf[HAL_MAX_ENTRY_WORD_SIZE];

extern HAL_FUNC_VEC_T
*_ext_ptr_chip_func_vector[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern HAL_CHIP_INFO_T
*_ext_ptr_chip_info[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern HAL_CHIP_CB_T
_ext_chip_control_block[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern HAL_CMN_FUNC_VEC_T
*_ext_ptr_chip_cmn_func_vector[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
#endif  /* #ifndef HAL_H */
