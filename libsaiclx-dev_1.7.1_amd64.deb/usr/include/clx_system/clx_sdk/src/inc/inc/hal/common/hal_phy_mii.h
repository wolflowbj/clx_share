/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_phy_mii.h
 * PURPOSE:
 *      It provides phy mii action commands.
 * NOTES:
 *
 */

#ifndef HAL_PHY_MII_H
#define HAL_PHY_MII_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <hal/common/hal_phy.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_PHY_MII_SET_FIELD(__reg_value__, \
                              __field_value__, \
                              __field_bit_offset__, \
                              __field_bit_num__) \
    do { \
        UI32_T  __field_mask__ = ((0x1UL << (__field_bit_num__)) - 1) << (__field_bit_offset__); \
        (__reg_value__) = (((__reg_value__) & (~__field_mask__)) | (((__field_value__) << (__field_bit_offset__)) & __field_mask__)); \
    } while (0)

#define HAL_PHY_MII_GET_FIELD(__reg_value__, \
                              __field_bit_offset__, \
                              __field_bit_num__) \
    (((__reg_value__) >> (__field_bit_offset__)) & ((0x1UL << (__field_bit_num__)) - 1))

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_PHY_MII_OP_TYPE_READ = 0x0,
    HAL_PHY_MII_OP_TYPE_WRITE,
    HAL_PHY_MII_OP_TYPE_READ_THERMAL,
    HAL_PHY_MII_OP_TYPE_SET_LED_MODE,
    HAL_PHY_MII_OP_TYPE_READ_UP_STATE,
    HAL_PHY_MII_OP_TYPE_SET_UP_MODE,
    HAL_PHY_MII_OP_TYPE_SET_LANE_MODE,
    HAL_PHY_MII_OP_TYPE_CLR_LINK_CHANGE,
    HAL_PHY_MII_OP_TYPE_SET_MODESWITCH_MASK,              /* Prevent race condition in reseting MAC (AN MODESWITCH) */
    HAL_PHY_MII_OP_TYPE_DUMP_THERMAL_LIST = 0xF8,
    HAL_PHY_MII_OP_TYPE_READ_EACH_THERMAL = 0xF9,
    HAL_PHY_MII_OP_TYPE_SET_UP_HALT = 0xFA,               /* Force uP in HALT state */
    HAL_PHY_MII_OP_TYPE_SET_PXP_UP_EVENT = 0xFB,          /* Insert pseudo events, need port uP pxp firmware */
    HAL_PHY_MII_OP_TYPE_SET_PXP_MAC_EVENT = 0xFC,         /* Insert pseudo events, need port uP pxp firmware */
    HAL_PHY_MII_OP_TYPE_INVOKE_CSO_FUNC = 0xFD,
    HAL_PHY_MII_OP_TYPE_SET_SERDES_UP_MODE = 0xFE,
    HAL_PHY_MII_OP_TYPE_GET_LED_STS = 0xFF,
    HAL_PHY_MII_OP_TYPE_LAST
} HAL_PHY_MII_OP_TYPE_T;  /* NOTE: OP length: 8 bits */

typedef enum
{
    HAL_PHY_MII_LED_MODE_TYPE_DEBUG_ON = 0x0,
    HAL_PHY_MII_LED_MODE_TYPE_DEBUG_BLINK,
    HAL_PHY_MII_LED_MODE_TYPE_NORMAL,
    HAL_PHY_MII_LED_MODE_TYPE_FORCE,
    HAL_PHY_MII_LED_MODE_TYPE_BIT_ON,
    HAL_PHY_MII_LED_MODE_TYPE_BIT_OFF,
    HAL_PHY_MII_LED_MODE_TYPE_LAST
} HAL_PHY_MII_LED_MODE_TYPE_T;

typedef enum
{
    HAL_PHY_MII_LED_STS_TYPE_NORMAL_ON = 0x0,
    HAL_PHY_MII_LED_STS_TYPE_NORMAL_OFF,
    HAL_PHY_MII_LED_STS_TYPE_FORCE_ON,
    HAL_PHY_MII_LED_STS_TYPE_FORCE_OFF,
    HAL_PHY_MII_LED_STS_TYPE_LAST
} HAL_PHY_MII_LED_STS_TYPE_T;

typedef enum
{
    HAL_PHY_MII_UP_STATE_TYPE_STACK_SEGMENT_LEN = 0x0,
    HAL_PHY_MII_UP_STATE_TYPE_STACK_SEGMENT_USED,
    HAL_PHY_MII_UP_STATE_TYPE_DATA_SEGMENT_LEN,
    HAL_PHY_MII_UP_STATE_TYPE_DATA_SEGMENT_USED,
    HAL_PHY_MII_UP_STATE_TYPE_APPLICATION_SEGMENT_LEN,
    HAL_PHY_MII_UP_STATE_TYPE_APPLICATION_SEGMENT_USED,
    HAL_PHY_MII_UP_STATE_TYPE_STATUS_UPDATE_ELAPSED_TIME,
    HAL_PHY_MII_UP_STATE_TYPE_LED_UPDATE_ELAPSED_TIME,
    HAL_PHY_MII_UP_STATE_TYPE_LAST
} HAL_PHY_MII_UP_STATE_TYPE_T;

typedef enum
{
    HAL_PHY_MII_UP_MODE_TYPE_NORMAL = 0x0,
    HAL_PHY_MII_UP_MODE_TYPE_DEBUG,
    HAL_PHY_MII_UP_MODE_TYPE_LAST
} HAL_PHY_MII_UP_MODE_TYPE_T;

typedef enum
{
    HAL_PHY_MII_LANE_MODE_TYPE_DOWN = 0x0,
    HAL_PHY_MII_LANE_MODE_TYPE_UP,
    HAL_PHY_MII_LANE_MODE_TYPE_LAST
} HAL_PHY_MII_LANE_MODE_TYPE_T;

typedef enum
{
    HAL_PHY_MII_SERDES_UP_MODE_TYPE_NORMAL = 0x0,
    HAL_PHY_MII_SERDES_UP_MODE_TYPE_DEBUG,
    HAL_PHY_MII_SERDES_UP_MODE_TYPE_LAST
} HAL_PHY_MII_SERDES_UP_MODE_TYPE_T;

typedef struct
{
    UI32_T      cmd_adr_mmio_addr;
    UI32_T      rsp_stat_mmio_addr;
    UI32_T      cmd_buf_mmio_addr;
    UI32_T      upctl_dev_int_set_mmio_addr;
} HAL_PHY_MII_MMIO_ADDR_CB_T;

typedef CLX_ERROR_NO_T
(*HAL_PHY_MII_GET_PHY_ADDR_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        port_id,
    UI32_T              *ptr_up_id,
    HAL_PHY_PHY_ADDR_T  *ptr_phy_addr);

typedef struct
{
    CLX_SEMAPHORE_ID_T              *ptr_sema;
    UI8_T                           *ptr_sn;
    HAL_PHY_MII_MMIO_ADDR_CB_T      *ptr_mmio_addr_cb;
    UI32_T                          up_num;
    HAL_PHY_MII_GET_PHY_ADDR_FUNC_T getPhyAddr;
} HAL_PHY_MII_DRIVER_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* FUNCTION NAME:   hal_phy_mii_init
 * PURPOSE:
 *      Init MII(Media-Independent Interface) driver per unit
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_mii_init(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_phy_mii_deinit
 * PURPOSE:
 *      Deinit MII(Media-Independent Interface) driver per unit
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_mii_deinit(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_phy_mii_getPhyAddr
 * PURPOSE:
 *      Get PHY address of MDIO(Management Data Input/Output)
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      phy_type        -- Type of PHY such as internal or external
 * OUTPUT:
 *      ptr_up_id       -- Device uP number
 *      ptr_phy_addr    -- PHY address of MDIO
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_mii_getPhyAddr(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_PHY_TYPE_T    phy_type,
    UI32_T                      *ptr_up_id,
    HAL_PHY_PHY_ADDR_T          *ptr_phy_addr);

/* FUNCTION NAME:   hal_phy_mii_txMdioCmd
 * PURPOSE:
 *      Access MDIO register
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      phy_type        -- Type of PHY such as internal or external
 *      dev_type        -- Type of PHY device
 *      reg_addr        -- Register address
 *      op              -- Operation such as write or read
 * OUTPUT:
 *      ptr_reg         -- Register data
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_mii_txMdioCmd(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_PHY_TYPE_T    phy_type,
    const UI32_T                dev_type,
    const UI32_T                reg_addr,
    const HAL_PHY_MII_OP_TYPE_T op,
    UI32_T                      *ptr_reg);

/* FUNCTION NAME:   hal_phy_mii_txPhyCfgCmd
 * PURPOSE:
 *      Access PHY config
 * INPUT:
 *      unit            -- Device unit number
 *      up_id           -- Device uP number
 *      phy_addr        -- PHY address of MDIO
 *      phy_type        -- Type of PHY such as internal or external
 *      dev_type        -- Type of PHY device
 *      reg_addr        -- Register address
 *      op              -- Operation such as write or read
 * OUTPUT:
 *      ptr_reg         -- Register data
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_mii_txPhyCfgCmd(
    const UI32_T                unit,
    const UI32_T                up_id,
    const HAL_PHY_PHY_ADDR_T    phy_addr,
    const HAL_PHY_PHY_TYPE_T    phy_type,
    const UI32_T                dev_type,
    const UI32_T                reg_addr,
    const HAL_PHY_MII_OP_TYPE_T op,
    UI32_T                      *ptr_reg);

/* FUNCTION NAME:   hal_phy_mii_txUpCmd
 * PURPOSE:
 *      Issue the command to control port uP
 * INPUT:
 *      unit            -- Device unit number
 *      up_id           -- Device uP number
 *      dev_addr        -- Device address inside port uP
 *      op              -- Operation such as write or read
 *      data_len        -- Length of data
 * OUTPUT:
 *      ptr_data        -- Command data
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_mii_txUpCmd(
    const UI32_T                unit,
    const UI32_T                up_id,
    const UI32_T                dev_addr,
    const HAL_PHY_MII_OP_TYPE_T op,
    UI32_T                      *ptr_data,
    const UI32_T                data_len);

/* FUNCTION NAME:   hal_phy_mii_txI2cCmd
 * PURPOSE:
 *      Issue the command to send I2c cmd
 * INPUT:
 *      unit            -- Device unit number
 *      dev_addr        -- Device address inside port uP
 *      op              -- Operation such as write or read
 *      data_len        -- Length of data
 * OUTPUT:
 *      ptr_data        -- Command data
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_mii_txI2cCmd(
    const UI32_T                unit,
    const UI32_T                mmio_addr,
    const HAL_PHY_MII_OP_TYPE_T op,
    UI32_T                      *ptr_data,
    const UI32_T                data_len);

#endif  /* End of HAL_PHY_MII_H */
