/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_l3t.h
 * PURPOSE:
 *      It provide l3 tunnel hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_L3T_H
#define HAL_L3T_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_l3t.h>
#include <hal/common/hal.h>
#include <hal/common/hal_vlan.h>
#include <hal/common/hal_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* Seg's MSB may be used as control bit, e.g. MPLSoTNL, thus 0 is safer */
#define HAL_L3T_INVALID_SEG             (0x0)

#define HAL_L3T_MAX_NUM_OF_FLEX_TUNNEL  (0x4)

/* MACRO FUNCTION DECLARATIONS
*/

/* DATA TYPE DECLARATIONS
*/

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_l3t_init(
    const UI32_T           unit);

CLX_ERROR_NO_T
hal_l3t_deinit(
    const UI32_T           unit);

CLX_ERROR_NO_T
hal_l3t_addTunnelMac(
    const UI32_T              unit,
    const UI32_T              index,
    const CLX_L3T_MAC_INFO_T *ptr_tunnel_mac_info);

CLX_ERROR_NO_T
hal_l3t_delTunnelMac(
    const UI32_T        unit,
    const UI32_T        index);

CLX_ERROR_NO_T
hal_l3t_getTunnelMac(
    const UI32_T         unit,
    const UI32_T         index,
    CLX_L3T_MAC_INFO_T  *ptr_tunnel_mac_info);

CLX_ERROR_NO_T
hal_l3t_traverseTunnelMac(
    const UI32_T                                unit,
    const CLX_L3T_TUNNEL_MAC_TRAVERSE_FUNC_T    callback,
    void                                        *ptr_cookie);

CLX_ERROR_NO_T
hal_l3t_addInit(
    const UI32_T                   unit,
    const CLX_L3T_INIT_INFO_T     *ptr_tunnel_init_info);

CLX_ERROR_NO_T
hal_l3t_delInit(
    const UI32_T              unit,
    const CLX_L3T_INIT_INFO_T *ptr_tunnel_init_info);

CLX_ERROR_NO_T
hal_l3t_getInit(
    const UI32_T               unit,
    CLX_L3T_INIT_INFO_T       *ptr_tunnel_init_info);

CLX_ERROR_NO_T
hal_l3t_traverseInit(
    const UI32_T                        unit,
    const CLX_L3T_INIT_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_l3t_addTerm(
    const UI32_T                 unit,
    const CLX_L3T_TERM_INFO_T   *ptr_tunnel_term_info);

CLX_ERROR_NO_T
hal_l3t_delTerm(
    const UI32_T                 unit,
    const CLX_L3T_TERM_INFO_T   *ptr_tunnel_term_info);

CLX_ERROR_NO_T
hal_l3t_getTerm(
    const UI32_T            unit,
    CLX_L3T_TERM_INFO_T    *ptr_tunnel_term_info);

CLX_ERROR_NO_T
hal_l3t_traverseTerm(
    const UI32_T                        unit,
    const CLX_L3T_TERM_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_l3t_addNvo3Route(
    const UI32_T                       unit,
    const CLX_L3T_NVO3_ROUTE_INFO_T    *ptr_nvo3_route_info);

CLX_ERROR_NO_T
hal_l3t_delNvo3Route(
    const UI32_T                       unit,
    const CLX_L3T_NVO3_ROUTE_INFO_T    *ptr_nvo3_route_info);

CLX_ERROR_NO_T
hal_l3t_getNvo3Route(
    const UI32_T                 unit,
    CLX_L3T_NVO3_ROUTE_INFO_T    *ptr_nvo3_route_info);

CLX_ERROR_NO_T
hal_l3t_traverseNvo3Route(
    const UI32_T                             unit,
    const CLX_L3T_NVO3_ROUTE_TRAVERSE_FUNC_T callback,
    void                                     *ptr_cookie);

CLX_ERROR_NO_T
hal_l3t_setUnusedEcnAction(
    const UI32_T             unit,
    const CLX_FWD_ACTION_T   action);

CLX_ERROR_NO_T
hal_l3t_getUnusedEcnAction(
    const UI32_T      unit,
    CLX_FWD_ACTION_T  *ptr_action);

CLX_ERROR_NO_T
hal_l3t_addNvo3Adj(
    const UI32_T            unit,
    const CLX_L3_ADJ_INFO_T *ptr_nvo3_adj_info,
    UI32_T                  *ptr_nvo3_adj_id);

CLX_ERROR_NO_T
hal_l3t_delNvo3Adj(
    const UI32_T    unit,
    const UI32_T    nvo3_adj_id);

CLX_ERROR_NO_T
hal_l3t_getNvo3Adj(
    const UI32_T            unit,
    const UI32_T            nvo3_adj_id,
    CLX_L3_ADJ_INFO_T       *ptr_nvo3_adj_info);

CLX_ERROR_NO_T
hal_l3t_traverseNvo3Adj(
    const UI32_T                        unit,
    const CLX_L3_ADJ_TRAVERSE_FUNC_T    callback,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_l3t_createPort(
    const UI32_T            unit,
    const CLX_TUNNEL_KEY_T  *ptr_key,
    const UI32_T            flag,
    CLX_PORT_T              *ptr_port);

CLX_ERROR_NO_T
hal_l3t_destroyPort(
    const UI32_T        unit,
    const CLX_PORT_T    port);

CLX_ERROR_NO_T
hal_l3t_getPort(
    const UI32_T            unit,
    const CLX_TUNNEL_KEY_T  *ptr_key,
    CLX_PORT_T              *ptr_port);

CLX_ERROR_NO_T
hal_l3t_getKey(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    CLX_TUNNEL_KEY_T    *ptr_key);

CLX_ERROR_NO_T
hal_l3t_traversePort(
    const UI32_T                        unit,
    const CLX_L3T_PORT_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_l3t_addFlexTunnel(
    const UI32_T unit,
    const UI32_T index,
    const CLX_L3T_FLEX_TUNNEL_TYPE_T type,
    const UI32_T flags);

CLX_ERROR_NO_T
hal_l3t_delFlexTunnel(
    const UI32_T unit,
    const UI32_T index);

CLX_ERROR_NO_T
hal_l3t_getFlexTunnel(
    const UI32_T unit,
    const UI32_T index,
    CLX_L3T_FLEX_TUNNEL_TYPE_T *ptr_type,
    UI32_T *ptr_flags);

CLX_ERROR_NO_T
hal_l3t_setFlexTunnelUdfProfile(
    const UI32_T unit,
    const UI32_T index,
    CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

CLX_ERROR_NO_T
hal_l3t_getFlexTunnelUdfProfile(
    const UI32_T unit,
    const UI32_T index,
    CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

/* EXPORTED HAL SUBPROGRAM BODIES
*/
CLX_ERROR_NO_T
hal_l3t_getSrcSuppTag(
    const UI32_T                unit,
    UI32_T                      *ptr_src_supp_tag);

CLX_ERROR_NO_T
hal_l3t_getHwVidInfo(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_TUNNEL_KEY_T      *ptr_key,
    const CLX_VLAN_TAG_ACTION_T *ptr_vlan_tag_action,
    const CLX_VLAN_ACTION_T     vlan_action,
    HAL_VLAN_VID_CTL_T          *ptr_vid_info);

CLX_ERROR_NO_T
hal_l3t_getSwVidInfo(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_TUNNEL_KEY_T      *ptr_key,
    const HAL_VLAN_VID_CTL_T    *ptr_vid_info,
    CLX_VLAN_TAG_ACTION_T       *ptr_vlan_tag_action,
    CLX_VLAN_ACTION_T           *ptr_vlan_action);

CLX_ERROR_NO_T
hal_l3t_getHwInitInfo(
    const UI32_T                unit,
    const UI32_T                fdid,
    const CLX_PORT_T            port,
    const CLX_TUNNEL_KEY_T      *ptr_key,
    UI32_T                      *ptr_seg,
    UI32_T                      *ptr_nvo3_encap_idx);

CLX_ERROR_NO_T
hal_l3t_getSwInitInfo(
    const UI32_T                unit,
    const UI32_T                nvo3_encap_idx,
    CLX_PORT_T                  *ptr_port,
    CLX_TUNNEL_KEY_T            *ptr_key);

CLX_ERROR_NO_T
hal_l3t_getLclIntf(
    const UI32_T                unit,
    const CLX_TUNNEL_KEY_T      *ptr_key,
    UI32_T                      *ptr_lcl_intf,
    CLX_DIR_T                   *ptr_dir);

CLX_ERROR_NO_T
hal_l3t_chkPortSrvInfo(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

CLX_ERROR_NO_T
hal_l3t_transNvo3AdjToEcmpPathEpL3(
    const UI32_T    unit,
    const UI32_T    nvo3_adj_id,
    CDB_FVP_T       *ptr_path_info,
    UI32_T          *ptr_buf);

CLX_ERROR_NO_T
hal_l3t_cfgEcmpPathByNvo3AdjInfo(
    const UI32_T unit,
    const UI32_T ecmp_path_idx,
    const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_l3t_addTermGeneral(
    const UI32_T                unit,
    const CLX_L3T_TERM_INFO_T   *ptr_tunnel_term_info,
    const BOOL_T                erspan);

CLX_ERROR_NO_T
hal_l3t_delTermGeneral(
    const UI32_T                unit,
    const CLX_L3T_TERM_INFO_T   *ptr_tunnel_term_info,
    const BOOL_T                erspan);

CLX_ERROR_NO_T
hal_l3t_getTermGeneral(
    const UI32_T            unit,
    CLX_L3T_TERM_INFO_T     *ptr_tunnel_term_info,
    const BOOL_T            erspan);

CLX_ERROR_NO_T
hal_l3t_getErspanTermLclIntf(
    const UI32_T        unit,
    const CLX_IP_ADDR_T *ptr_src_ip,
    const CLX_IP_ADDR_T *ptr_dst_ip,
    UI32_T              *ptr_lcl_intf);

CLX_ERROR_NO_T
hal_l3t_composeClxPort(
    const UI32_T    unit,
    const UI32_T    nvo3_encap_idx,
    CLX_PORT_T      *ptr_port);

CLX_ERROR_NO_T
hal_l3t_cfgAdjEcmpList(
    const UI32_T unit,
    const HAL_CMN_ACTION_T action,
    const UI32_T adj_id,
    const UI32_T grp_id);

UI32_T
hal_l3t_getFlexTnlId(
    const CLX_TUNNEL_TYPE_T tunnel_type);

CLX_ERROR_NO_T
hal_l3t_cfgFlexTnlGtp(
    const UI32_T unit,
    const UI32_T index,
    const UI32_T flags);

CLX_ERROR_NO_T
hal_l3t_cfgFlexTnlUserDefined(
    const UI32_T unit,
    const UI32_T index,
    const UI32_T flags);

CLX_ERROR_NO_T
hal_l3t_cfgFlexTnlGeneve(
    const UI32_T unit,
    const UI32_T index,
    const UI32_T flags);

CLX_ERROR_NO_T
hal_l3t_setExcptAct(
    const UI32_T             unit,
    const CLX_SWC_PROPERTY_T property,
    CLX_FWD_ACTION_T         action);

CLX_ERROR_NO_T
hal_l3t_getExcptAct(
    const UI32_T             unit,
    const CLX_SWC_PROPERTY_T property,
    CLX_FWD_ACTION_T         *ptr_action);

CLX_ERROR_NO_T
hal_l3t_getDbFlexTnlArr(
    const UI32_T                unit,
    CLX_L3T_FLEX_TUNNEL_TYPE_T  *ptr_flex_tnl_arr);
#endif
