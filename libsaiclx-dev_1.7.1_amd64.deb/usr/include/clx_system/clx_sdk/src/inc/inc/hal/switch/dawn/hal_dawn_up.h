/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_up.h
 * PURPOSE:
 *      1. It provides uP download API.
 *
 * NOTES:
 *
 */


#ifndef HAL_DAWN_UP_H
#define HAL_DAWN_UP_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>


/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   hal_dawn_up_initDceUp
 * PURPOSE:
 *      Download DCE uP FW.
 *          Index 0 - for DMA uP
 *          Index 1 - for ZC uP
 *
 * INPUT:
 *      unit        -- unit index
 *      idx         -- uP index:
 *                      Index 0 - for DMA uP
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_up_initDceUp(
    const UI32_T    unit,
    const UI32_T    idx);

/* FUNCTION NAME:   hal_dawn_up_initPortUp
 * PURPOSE:
 *      Download Port uP FW on BIN0.
 *
 * INPUT:
 *      unit        -- unit index
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_up_initPortUp(
    const UI32_T      unit);

/* FUNCTION NAME:   hal_dawn_up_deinitPortUp
 * PURPOSE:
 *      Stop Port uP on BIN0.
 *
 * INPUT:
 *      unit        -- unit index
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- stop success.
 *      CLX_E_OTHERS -- stop fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_up_deinitPortUp(
    const UI32_T      unit);

/* FUNCTION NAME:   hal_dawn_up_initCalUp
 * PURPOSE:
 *      Download Calibration uP FW on BIN0.
 *
 * INPUT:
 *      unit        -- unit index
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_up_initCalUp(
    const UI32_T      unit);

/* FUNCTION NAME:   hal_dawn_up_deinitCalUp
 * PURPOSE:
 *      Stop Calibration uP on BIN0.
 *
 * INPUT:
 *      unit        -- unit index
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- stop success.
 *      CLX_E_OTHERS -- stop fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_up_deinitCalUp(
    const UI32_T      unit);

/* FUNCTION NAME:   hal_dawn_up_initUp
 * PURPOSE:
 *      Download all uP FW.
 *
 * INPUT:
 *      unit        -- unit index
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */

CLX_ERROR_NO_T
hal_dawn_up_initUp(
    const UI32_T      unit);

/* FUNCTION NAME:   hal_dawn_up_deinitUp
 * PURPOSE:
 *      Stop all uP.
 *
 * INPUT:
 *      unit        -- unit index
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- stop success.
 *      CLX_E_OTHERS -- stop fail.
 *
 * NOTES:
 *      NONE.
 */

CLX_ERROR_NO_T
hal_dawn_up_deinitUp(
    const UI32_T      unit);

/* FUNCTION NAME:   hal_dawn_up_resetBinUp
 * PURPOSE:
 *      Reset per bin uP.
 *
 * INPUT:
 *      unit        -- unit index
 *      bin_idx     -- bin index
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- reset success.
 *      CLX_E_OTHERS -- reset fail.
 *
 * NOTES:
 *      NONE.
 */

CLX_ERROR_NO_T
hal_dawn_up_resetBinUp(
    const UI32_T      unit,
    const UI32_T      bin_idx);


#endif /* HAL_DAWN_UP_H */
