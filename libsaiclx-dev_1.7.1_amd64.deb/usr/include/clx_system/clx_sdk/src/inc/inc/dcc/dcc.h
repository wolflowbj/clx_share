/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  dcc.h
 * PURPOSE:
 *  1. Provide the chip Device Control Command(DCC) interfaces, it will include:
 *     a. Per channel init status.
 *     b. DCC Errror handler.
 *  2. Define DCC related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_H
#define DCC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_cfg.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <hal/common/hal_tbl.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* DCC constant definition */
#define DCC_CMD_LENGTH_UNIT             (4) /* words, means 4 bytes */
#define DCC_HIGH_ADDR_WIDTH             (32) /* High address width is 32 bits */
#define DCC_MAX_TIMEOUT_CNT             (1000000)
/* unit of time: us, all times need for further check */
#define DCC_UP_DOWNLOAD_SUSPEND_TIME    (50)

#define DCC_EN_CMD_PERF_RECORD          (1)

/* DCE second level interrupt for DCE channel error */
#define DCC_IOCMD_CORE1_ERR            (1UL << 1)
#define DCC_IOCMD_CORE2_ERR            (1UL << 4)
#define DCC_DMA_TABLEH2D_ERR           (1UL << 20)
#define DCC_DMA_TABLED2H_ERR           (1UL << 21)
#define DCC_CLD_DMA_H2D_ERR            (1UL << 22)
#define DCC_CLD_DMA_D2H_ERR            (1UL << 23)
#define DCC_IOCMD_CORE3_ERR            (1UL << 25)
#define DCC_DMA_TABLED2D_ERR           (1UL << 27)
#define DCC_TDMA_STAUPD_ERR            (1UL << 28)
#define DCC_CLD_STAUPD_ERR             (1UL << 29)
#define DCC_DMA_UPERRIRQ               (1UL << 31)

/* DCE third level interrupt for DCE uP error (DCC_DMA_UPERRIRQ) */
/* uP to host error interrupt status */
#define DCC_WTD_HST_ERR                (1UL << 0)
#define DCC_PMEM_DECC_ERR              (1UL << 1)
#define DCC_DMEM0_DECC_ERR             (1UL << 2)
#define DCC_DMEM1_DECC_ERR             (1UL << 3)
#define DCC_TMEM_DECC_ERR              (1UL << 4)
#define DCC_PMEM_SECC_ERR              (1UL << 5)
#define DCC_DMEM0_SECC_ERR             (1UL << 6)
#define DCC_DMEM1_SECC_ERR             (1UL << 7)
#define DCC_TMEM_SECC_ERR              (1UL << 8)
#define DCC_SHR_ARB_TMO_ERR            (1UL << 9)
#define DCC_DBUS_ARB_TMO_ERR           (1UL << 10)
#define DCC_PMEM_ARB0_TMO_ERR          (1UL << 11)
#define DCC_PMEM_ARB1_TMO_ERR          (1UL << 12)
#define DCC_DMEM_ARB0_TMO_ERR          (1UL << 13)
#define DCC_DMEM_ARB1_TMO_ERR          (1UL << 14)


/* DCE second level interrupt for DCE channel error */
/* Default enable setting */
#define DCC_CH_ERR_INTR_MASK (DCC_IOCMD_CORE1_ERR|DCC_DMA_TABLEH2D_ERR|DCC_DMA_TABLED2H_ERR|DCC_DMA_TABLED2D_ERR| \
                  DCC_CLD_DMA_H2D_ERR|DCC_CLD_DMA_D2H_ERR|DCC_CLD_STAUPD_ERR|DCC_TDMA_STAUPD_ERR|DCC_DMA_UPERRIRQ)

/* DCE third level interrupt for DCE uP error */
/* Default enable setting */
#define DCC_UP_ERR_INTR_MASK (DCC_PMEM_DECC_ERR|DCC_DMEM0_DECC_ERR|DCC_DMEM1_DECC_ERR|DCC_TMEM_DECC_ERR)

/* status update error */
#define DCC_COMPLETION_TIMEOUT_ERR     (1UL << 0)
#define DCC_UNSUPPORT_REQUEST_ERR      (1UL << 1)
#define DCC_COMPLETE_ABORT_ERR         (1UL << 2)
#define DCC_CONFIG_REQUEST_RETRY_ERR   (1UL << 3)
#define DCC_PCIE_RESET_ERR             (1UL << 6)
#define DCC_PCIE_ECC_ERR               (1UL << 7)

/* for host 64 bits address access macro */
#define DCC_HOST_ADDR_HI(dst)                 (dst.ui32[1])
#define DCC_HOST_ADDR_LOW(dst)                (dst.ui32[0])
#define DCC_HOST_ADDR_ASSIGN(dst, high, low)     \
    do {                                \
        DCC_HOST_ADDR_HI(dst) = (high);          \
        DCC_HOST_ADDR_LOW(dst) = (low);          \
    } while(0)
#define DCC_HOST_ADDR_64_BIT_SET(dst, high, low) \
    do { \
        dst = (high); \
        dst = ((dst << DCC_HIGH_ADDR_WIDTH) | (low)); \
    }while(0)

/* DCC semaphore macro */
#define DCC_TAKE_SEMA(sema, timeOut)     osal_takeSemaphore(sema, timeOut)
#define DCC_GIVE_SEMA(sema)              osal_giveSemaphore(sema)

/* DCC MMIO register access macro */
#if defined(CLX_LAMP)
#define DCC_MMIO_REG_READ(unit, offset, ptr_data)   \
    dcc_lamp_readReg(unit, offset, ptr_data, 4)
#define DCC_MMIO_REG_WRITE(unit, offset, ptr_data)  \
    dcc_lamp_writeReg(unit, offset, ptr_data, 4)
#else
#define DCC_MMIO_REG_READ(unit, offset, ptr_data)   \
    aml_readReg(unit, offset, ptr_data, 4)
#define DCC_MMIO_REG_WRITE(unit, offset, ptr_data)  \
    aml_writeReg(unit, offset, ptr_data, 4)
#endif /* #if defined(CLX_LAMP) */

#if defined(DCC_EN_CMD_PERF_RECORD)
#define DCC_CMD_EXEC_TIME_RECORD(unit, cmd_time, cmd_max_time, cmd_min_time) \
    do { \
        cmd_max_time = ((cmd_max_time < cmd_time) ? cmd_time : cmd_max_time); \
        cmd_min_time = ((cmd_min_time > cmd_time) ? cmd_time : cmd_min_time); \
    } while(0)
#endif

#define DCC_INIT_IO_CH_DONE(unit) \
        (dcc_control_block[unit].state.init_io_done)
#define DCC_INIT_DMA_CH_DONE(unit) \
        (dcc_control_block[unit].state.init_dma_done)
#define DCC_INIT_CLD_CH_DONE(unit) \
        (dcc_control_block[unit].state.init_cld_done)
#define DCC_INIT_DCE_DONE(unit) \
        (dcc_control_block[unit].state.init_dce_done)

#define DCC_INVALID_MMIO_ADDR \
        (0xFFFFFFFF)

/* MACRO FUNCTION DECLARATIONS
 */

#define DCC_INIT_A_CMD(ptr_cmd, cmd_act_in, addr_in, ptr_data_in, data_len_in, ptr_rsp_in) \
    do { \
        (ptr_cmd)->action   = (cmd_act_in);  \
        (ptr_cmd)->addr     = (addr_in);     \
        (ptr_cmd)->ptr_data = (ptr_data_in); \
        (ptr_cmd)->data_len = (data_len_in); \
        (ptr_cmd)->ptr_rsp  = (ptr_rsp_in);  \
    } while(0)

/* DATA TYPE DECLARATIONS
 */
/* DCC channel access mode (polling or interrupt) */
typedef enum
{
    DCC_CH_OP_MODE_POLL = 0,
    DCC_CH_OP_MODE_INTR,
    DCC_CH_OP_MODE_LAST
} DCC_CH_OP_MODE_T;

/* A-cmd action */
typedef enum
{
    DCC_CMD_ACT_READ  = 0x0,
    DCC_CMD_ACT_WRITE = 0x1,
    DCC_CMD_ACT_HASH  = 0x2,
    DCC_CMD_ACT_ABORT = 0xE,
    DCC_CMD_ACT_CLR   = 0xF,
    DCC_CMD_ACT_LAST
} DCC_CMD_ACT_T;

/* Hash cmd action */
typedef enum
{
    DCC_CMD_HASH_ACT_INSERT_OVERWRITE    = 0x0,
    DCC_CMD_HASH_ACT_READ                = 0x1,
    DCC_CMD_HASH_ACT_INSERT_NONOVERWRITE = 0x2,
    DCC_CMD_HASH_ACT_DELETE              = 0x3,
    DCC_CMD_HASH_ACT_LAST
} DCC_CMD_HASH_ACT_T;

typedef struct
{
    UI32_T   ui32[2];
} DCC_HOST_ADDR_T;


typedef
CLX_ERROR_NO_T
(*DCC_ISR_HANDLE_FUNC_T)(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* DCC control block state */
typedef struct
{
    BOOL_T init_io_done;          /* indicate IO channel initializing done */
    BOOL_T init_dma_done;         /* indicate DMA channel initializing done */
    BOOL_T init_cld_done;         /* indicate Calendar DMA channel initializing done */
    BOOL_T init_dce_done;         /* indicate DCE error channel initializing done  */

} DCC_CB_STATE_T;

typedef enum
{
    DCC_INTR_IOCMD_CORE1_ERROR = 0,
    DCC_INTR_IOCMD_CORE2_ERROR,
    DCC_INTR_DMA_TABLEH2D_ERROR,
    DCC_INTR_DMA_TABLED2H_ERROR,
    DCC_INTR_CLD_DMA_H2D_ERROR,
    DCC_INTR_CLD_DMA_D2H_ERROR,
    DCC_INTR_IOCMD_CORE3_ERROR,
    DCC_INTR_DMA_TABLED2D_ERROR,
    DCC_INTR_TDMA_STAUPD_ERROR,
    DCC_INTR_CLD_STAUPD_ERROR,
    DCC_INTR_DMA_UP_ERROR,
    DCC_INTR_TYPE_LAST
}DCC_INTR_TYPE_T;

typedef enum
{
    /* uP to host error interrupt status */
    DCC_UP_WTD_HST_ERROR = 0,
    DCC_UP_PMEM_DECC_ERROR,
    DCC_UP_DMEM0_DECC_ERROR,
    DCC_UP_DMEM1_DECC_ERROR,
    DCC_UP_TMEM_DECC_ERROR,
    DCC_UP_PMEM_SECC_ERROR,
    DCC_UP_DMEM0_SECC_ERROR,
    DCC_UP_DMEM1_SECC_ERROR,
    DCC_UP_TMEM_SECC_ERROR,
    DCC_UP_SHR_ARB_TMO_ERROR,
    DCC_UP_DBUS_ARB_TMO_ERROR,
    DCC_UP_PMEM_ARB0_TMO_ERROR,
    DCC_UP_PMEM_ARB1_TMO_ERROR,
    DCC_UP_DMEM_ARB0_TMO_ERROR,
    DCC_UP_DMEM_ARB1_TMO_ERROR,
    DCC_UP_ERROR_LAST
} DCC_UP_INTR_TYPE_T;

typedef UI32_T DCC_INTR_MASK_T;

typedef struct
{
    const DCC_INTR_TYPE_T intr_type;    /* interrupt type */
    const DCC_INTR_MASK_T intr_mask;    /* interrupt mask */
    DCC_ISR_HANDLE_FUNC_T isr_callback; /* interrupt handler function */
    UI32_T                isr_cookie;   /* the cookie of interrupt handler */
    const C8_T*    const  ptr_isr_desc; /* interrupt handler descriptions */
} DCC_INTR_VEC_T;

typedef struct
{
    DCC_INTR_VEC_T* const ptr_intr_vector;           /* INTR vector table */
    const UI16_T          intr_num;                  /* total high-pri INTR number */
    const DCC_INTR_MASK_T intr_all_mask;             /* total high-pri INTR mask bits */
} DCC_ISR_INFO_T;

typedef struct
{
    const C8_T*         const driver_desc;     /* driver description */
    DCC_ISR_INFO_T*     const ptr_isr_info;    /* ISR information pointer */
} DCC_DRIVER_T;

typedef struct DCC_DCE_CB_S
{
    DCC_DRIVER_T        *ptr_driver_info;
}DCC_DCE_CB_T;

typedef struct
{
    UI32_T  dce_int_en_mmio_addr;
    UI32_T  dce_int_mask_mmio_addr;
    UI32_T  dce_int_set_mmio_addr;
    UI32_T  dce_int_clr_mmio_addr;
    UI32_T  dce_int_stat_mmio_addr;
} DCC_DCE_MMIO_ADDR_CB_T;

/* DCC control block structure */
typedef struct
{
    DCC_CB_STATE_T          state; /* DCC control block state */
    DCC_DCE_CB_T            dce_cb; /* dce control block */
    DCC_DCE_MMIO_ADDR_CB_T  dce_mmio_addr_cb; /* dce mmio addr control block */
} DCC_CB_T;

typedef
CLX_ERROR_NO_T
(*DCC_DRIVER_INIT_FUNC_T)(
    DCC_DRIVER_T **pptr_dcc_driver);

typedef struct
{
    DCC_DRIVER_INIT_FUNC_T           dcc_initDriver_callback; /* driver handler function pointer */
} DCC_DEVICE_DRIVER_MAP_T;

/* FUNCTION NAME:   dcc_init
 * PURPOSE:
 *      dcc_init() is responsible for DCC initialization, it will do
 *      the following:
 *      1. Allocate an available DCC control block.
 *      2. Initialize DCC miscellaneous resources(DCC DMA buffers).
 *      3. Initialize DCC IO channel.
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */

CLX_ERROR_NO_T
dcc_init(
    const UI32_T    unit);

/* FUNCTION NAME:   dcc_chInit
 * PURPOSE:
 *      dcc_chInit() is responsible for DCC initialization, it will do
 *      the following:
 *      1. Initialize DCC channels. It will include:
 *         a. DMA channel initialization.
 *         b. Calendar DMA channel initialization.
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */

CLX_ERROR_NO_T
dcc_chInit(
    const UI32_T    unit);

/* FUNCTION NAME:   dcc_deinit
 * PURPOSE:
 *      dcc_deInit() is responsible for DCC de-initialization, it will
 *      do the following:
 *      1. De-initialize DCC channels.
 *      2. De-initialize DCC miscellaneous resource(DCC DMA buffers).
 *      3. De-initialize DCC control block.
 *
 * INPUT:
 *      unit            -- The unit number that would like to de-initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully de-initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete de-initialization procedure.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_deinit(
    const UI32_T    unit);

/* FUNCTION NAME:   dcc_initDceErrorDriver
 * PURPOSE:
 *      dcc_initDceErrorDriver() is a function to set dce common or cp common.
 *
 * INPUT:
 *      pptr_dce_driver           -- The specified dce driver pptr.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- Init DCE error driver successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_initDceErrorDriver(
    DCC_DRIVER_T            **pptr_dce_driver);

/* FUNCTION NAME:   dcc_recoverDoubleEccError
 * PURPOSE:
 *      dcc_recoverDoubleEccError() is a function to handle program memory double bit ECC error for uP.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle io command error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_recoverDoubleEccError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_recoverSingleEccError
 * PURPOSE:
 *      dcc_recoverSingleEccError() is a function to handle program memory single bit ECC error for uP.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle io command error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_recoverSingleEccError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* DMA channel Error ISR */
CLX_ERROR_NO_T
dcc_dceChIsr(
    const UI32_T unit,
    const UI32_T isr_cookie);

extern DCC_CB_T
dcc_control_block[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern DCC_ISR_INFO_T
dcc_up_err_isr_info;

extern DCC_INTR_VEC_T
dcc_up_err_vector[];
#endif /* END of DCC_H*/
