/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_cim.h
 * PURPOSE:
 *  1. Provide Centralized Index Management API.
 * NOTES:
 */

#ifndef HAL_CIM_H
#define HAL_CIM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_cfg.h>
#include <cdb/cdb.h>
#include <hal/common/hal.h>
#include <hal/common/hal_tbl.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   hal_addProfileEntry
 * PURPOSE:
 *      hal_addProfileEntry() is responsible for setting hw table and record
 *      reference count.
 *
 * INPUT:
 *      unit           -- The unit number.
 *      inst_idx        -- The instance index.
 *      table_id       -- The table id.
 *      field_num      -- Number of fields to be set.
 *      ptr_field      -- The structure of CDB_FVP_T.
 * OUTPUT:
 *      entry_idx      -- The return index
 * RETURN:
 *      CLX_E_OK       -- Successfully init table.
 *      CLX_E_OTHERS    -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_addProfileEntry(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    const UI32_T    field_num,
    CDB_FVP_T       *ptr_field,
    const UI32_T    old_entry_idx,
    UI32_T          *ptr_entry_idx);

/* FUNCTION NAME:   hal_cim_delProfileEntry
 * PURPOSE:
 *      hal_cim_delProfileEntry() is responsible for decreasing reference count.
 *
 * INPUT:
 *      unit            -- The unit number.
 *      inst_idx        -- The instance index.
 *      table_id        -- The table id.
 *      entry_idx       -- The return index
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully init table.
 *      CLX_E_OTHERS    -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_delProfileEntry(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    const UI32_T    entry_idx);

/* FUNCTION NAME:   hal_cim_getProfileEntryIndex
 * PURPOSE:
 *      hal_cim_getProfileEntryIndex() is responsible for getting entry index.
 *
 * INPUT:
 *      unit           -- The unit number.
 *      table_id       -- The table id.
 *      field_num      -- Number of fields to be set.
 *      ptr_field      -- The structure of CDB_FVP_T.
 * OUTPUT:
 *      entry_idx      -- The return index
 * RETURN:
 *      CLX_E_OK       -- Successfully init table.
 *      CLX_E_OTHERS   -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_getProfileEntryIndex(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    const UI32_T    field_num,
    CDB_FVP_T       *ptr_field,
    UI32_T          *ptr_entry_idx);

/* FUNCTION NAME:   hal_cim_getProfileEntryRefCnt
 * PURPOSE:
 *      hal_cim_getProfileEntryRefCnt() is responsible for getting reference count.
 *
 * INPUT:
 *      unit            -- The unit number.
 *      inst_idx        -- The instance index.
 *      table_id        -- The table id.
 *      entry_idx       -- The entry index
 * OUTPUT:
 *      ptr_refcnt      -- return reference count
 * RETURN:
 *      CLX_E_OK        -- Successfully init table.
 *      CLX_E_OTHERS    -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_getProfileEntryRefCnt(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    const UI32_T    entry_idx,
    UI32_T          *ptr_refcnt);

/* FUNCTION NAME:   hal_cim_modifyProfileEntryRefCnt
 * PURPOSE:
 *      hal_cim_modifyProfileEntryRefCnt() is responsible for modifying reference count.
 *
 * INPUT:
 *      unit            -- The unit number.
 *      inst_idx        -- The instance index.
 *      table_id        -- The table id.
 *      entry_idx      -- The entry index
 *      count          --  count to be increase or decrease
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK       -- Successfully init table.
 *      CLX_E_OTHERS   -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_modifyProfileEntryRefCnt(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    const UI32_T    entry_idx,
    const I32_T     count);

/* FUNCTION NAME:   hal_cim_allocIndexSwEntry
 * PURPOSE:
 *      hal_cim_allocIndexSwEntry() is responsible for allocating a free index and
 *      setting hw table.
 * INPUT:
 *      unit          -- The unit number.
 *      inst_idx      -- The instance index.
 *      sw_table_id   -- The software table id.
 *      field_num     -- Number of fields to be set.
 *      count         -- The requested consecutive count.
 *      ptr_field     -- The structure of CDB_FVP_T.
 * OUTPUT:
 *      ptr_entry_idx -- The return index
 * RETURN:
 *      CLX_E_OK      -- Successfully init table.
 *      CLX_E_OTHERS  -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_allocIndexSwEntry(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    sw_table_id,
    const UI32_T    field_num,
    const UI32_T    count,
    CDB_FVP_T       *ptr_field,
    UI32_T          *ptr_entry_idx);

/* FUNCTION NAME:   hal_cim_allocIndexEntry
 * PURPOSE:
 *      hal_cim_allocIndexEntry() is responsible for allocating a free index and
 *      setting hw table bitmap.
 *
 * INPUT:
 *      unit          -- The unit number.
 *      inst_idx      -- The instance index.
 *      table_id      -- The hardware table id.
 *      field_num     -- Number of fields to be set.
 *      count         -- The requested consecutive count.
 *      ptr_field     -- The structure of CDB_FVP_T.
 * OUTPUT:
 *      entry_idx     -- The return index
 * RETURN:
 *      CLX_E_OK      -- Successfully init table.
 *      CLX_E_OTHERS  -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_allocIndexEntry(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    const UI32_T    field_num,
    const UI32_T    count,
    CDB_FVP_T       *ptr_field,
    UI32_T          *ptr_entry_idx);

/* FUNCTION NAME:   hal_cim_setIndexEntry
 * PURPOSE:
 *      hal_cim_setIndexEntry() is responsible for setting an index and hw table.
 *      bitmap.
 *
 * INPUT:
 *      unit          -- The unit number.
 *      inst_idx      -- The instance index.
 *      table_id      -- The hardware table id.
 *      entry_idx     -- The entry index.
 *      field_num     -- Number of fields to be set.
 *      ptr_field     -- The structure of CDB_FVP_T.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully init table.
 *      CLX_E_OTHERS  -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_setIndexEntry(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    const UI32_T    entry_idx,
    const UI32_T    field_num,
    CDB_FVP_T       *ptr_field);

/* FUNCTION NAME:   hal_cim_freeIndexEntry
 * PURPOSE:
 *      hal_cim_freeIndexEntry() is responsible for free entry index
 *
 * INPUT:
 *      unit           -- The unit number.
 *      inst_idx       -- The instance index.
 *      table_id       -- The table id.
 *      entry_idx      -- The return index
 *      count          -- The consecutive count.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK       -- Successfully init table.
 *      CLX_E_OTHERS   -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_freeIndexEntry(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    const UI32_T    entry_idx,
    const UI32_T    count);

/* FUNCTION NAME:   hal_cim_getFreeEntryCnt
 * PURPOSE:
 *      hal_cim_getFreeEntryCnt() is responsible for getting free entry index count
 *
 * INPUT:
 *      unit           -- The unit number.
 *      inst_idx       -- The instance index.
 *      table_id       -- The hardware table id.
 *      entry_idx      -- The table index
 * OUTPUT:
 *      ptr_entry_idx  -- return free count.
 * RETURN:
 *      CLX_E_OK       -- Successfully init table.
 *      CLX_E_OTHERS   -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_getFreeEntryCnt(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    UI32_T          *ptr_cnt);

/* FUNCTION NAME:   hal_cim_getFreeSwEntryCnt
 * PURPOSE:
 *      hal_cim_getFreeSwEntryCnt() is responsible for getting free sw entry index count
 *
 * INPUT:
 *      unit          -- The unit number.
 *      inst_idx      -- The instance index.
 *      sw_table_id   -- The software table id.
 *      entry_idx     -- The table index
 * OUTPUT:
 *      ptr_entry_idx -- return free count.
 * RETURN:
 *      CLX_E_OK      -- Successfully init table.
 *      CLX_E_OTHERS  -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_getFreeSwEntryCnt(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    sw_table_id,
    UI32_T          *ptr_cnt);

/* FUNCTION NAME:   hal_cim_checkIndexEntry
 * PURPOSE:
 *      hal_cim_checkIndexEntry() is responsible for checking entry index is valid or not.
 *
 * INPUT:
 *      unit           -- The unit number.
 *      inst_idx       -- The instance index.
 *      table_id       -- The hardware table id.
 *      entry_idx      -- The table index
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK               -- entry is found.
 *      CLX_E_ENTRY_NOT_FOUND  -- entry is not found.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_checkIndexEntry(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    table_id,
    const UI32_T    entry_idx);

/* FUNCTION NAME:   hal_cim_resetBmpSize
 * PURPOSE:
 *      hal_cim_resetBmpSize() is responsible for reseting allocated bmp size
 *
 * INPUT:
 *      unit          -- The unit number.
 *      sw_table_id   -- The software table id.
 *      hw_table_id   -- The hardware table id.
 *      base_index    --  Based Index of this sw table id.
 *      length        --  Length.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK               -- entry is found.
 *      CLX_E_ENTRY_NOT_FOUND  -- entry is not found.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_cim_resetBmpSize(
    const UI32_T    unit,
    const UI32_T    sw_table_id,
    const UI32_T    hw_table_id,
    const UI32_T    base_index,
    const UI32_T    length);

#endif  /* #ifndef HAL_CIM_H */

