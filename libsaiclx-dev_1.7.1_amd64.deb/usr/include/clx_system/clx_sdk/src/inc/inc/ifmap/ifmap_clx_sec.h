/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  ifmap_clx_sec.h
 * PURPOSE:
 *      Define the declartion for Security module in CLX SDK.
 *
 * NOTES:
 *
 */

#ifndef IFMAP_CLX_SEC_H
#define IFMAP_CLX_SEC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* FUNCTION NAME:   ifmap_clx_sec_setDosPortConfig
 * PURPOSE:
 *      set port DoS configuration. (add profile or record reference counter)
 * INPUT:
 *      unit            --  Device unit number.
 *      user_port       --  User port ID.
 *      ptr_entry       --  DoS per port configuration.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_sec_setDosPortConfig (
    const UI32_T                    unit,
    const UI32_T                    user_port,
    const CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry);

/* FUNCTION NAME:   ifmap_clx_sec_getDosPortConfig
 * PURPOSE:
 *      get port DoS configuration. (get the port DoS profile id, and get dos profile entry)
 * INPUT:
 *      unit            --  Device unit number.
 *      user_port       --  User port ID.
 * OUTPUT:
 *      ptr_entry       --  DoS per port configuration.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getDosPortConfig (
    const UI32_T                    unit,
    const UI32_T                    user_port,
    CLX_SEC_DOS_PORT_CONFIG_T       *ptr_entry);

/* FUNCTION NAME:   ifmap_clx_sec_setStormCtrlProperty
 * PURPOSE:
 *      This API is used to set storm control properties.
 * INPUT:
 *      unit  --  Device unit number
 *      user_port  --  User Port ID
 *      ptr_entry  --  The storm control properties for the specified port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation is successful.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_NO_MEMORY  --  No available memory for this operation.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_sec_setStormCtrlProperty (
    const UI32_T                    unit,
    const UI32_T                    user_port,
    const CLX_SEC_STORM_CTRL_T      *ptr_entry);

/* FUNCTION NAME:   ifmap_clx_sec_getStormCtrlProperty
 * PURPOSE:
 *      This API is used to get storm control properties.
 * INPUT:
 *      unit  --  Device unit number
 *      user_port  --  User Port ID
 * OUTPUT:
 *      ptr_entry  --  The storm control properties for the specified port
 * RETURN:
 *      CLX_E_OK  --  Operation is successful.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getStormCtrlProperty (
    const UI32_T                    unit,
    const UI32_T                    user_port,
    CLX_SEC_STORM_CTRL_T            *ptr_entry);

/* FUNCTION NAME:   ifmap_clx_sec_getStormCtrlCnt
 * PURPOSE:
 *      This API is used to get storm control counter information.
 * INPUT:
 *      unit  --  Device unit number
 *      user_port  --  User Port ID
 *      type  --  The storm control traffic type
 * OUTPUT:
 *      ptr_cnt  --  The storm control counter information for the specified traffic type which will be provided
 *                   by the specified port.
 * RETURN:
 *      CLX_E_OK  --  Operation is successful.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getStormCtrlCnt(
    const UI32_T                       unit,
    const UI32_T                       user_port,
    const CLX_SEC_STORM_CTRL_TYPE_T    type,
    CLX_SEC_STORM_CTRL_CNT_T           *ptr_cnt);

/* FUNCTION NAME:   ifmap_clx_sec_setSourceGuardProperty
 * PURPOSE:
 *      This API is used to set source guard properties.
 * INPUT:
 *      unit  --  Device unit number
 *      user_port  --  User Port ID
 *      ptr_entry  --  The source guard properties for the specified port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation is successful.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_NO_MEMORY  --  No available memory for this operation.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_sec_setSourceGuardProperty(
    const UI32_T                    unit,
    const CLX_PORT_T                user_port,
    const CLX_SEC_SG_PROPERTY_T     *ptr_entry);

/* FUNCTION NAME:   ifmap_clx_sec_getSourceGuardProperty
 * PURPOSE:
 *      This API is used to get source guard properties.
 * INPUT:
 *      unit  --  Device unit number
 *      user_port  --  User Port ID
 * OUTPUT:
 *      ptr_entry  --  The source guard properties for the specified port
 * RETURN:
 *      CLX_E_OK  --  Operation is successful.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getSourceGuardProperty(
    const UI32_T                    unit,
    const CLX_PORT_T                user_port,
    CLX_SEC_SG_PROPERTY_T           *ptr_entry);

/* FUNCTION NAME:   ifmap_clx_sec_addSourceGuardEntry
 * PURPOSE:
 *      This API is used to add a source guard entry or set an existing source guard entry.
 * INPUT:
 *      unit  --  Device unit number
 *      ptr_entry  --  The source guard entry which will be added or set. It should at least be filled with the keys.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation is successful.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_NO_MEMORY  --  No available memory for this operation.
 *      CLX_E_TABLE_FULL -- Table is full.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_sec_addSourceGuardEntry(
    const UI32_T                    unit,
    const CLX_SEC_SG_ENTRY_T        *ptr_user_entry);

/* FUNCTION NAME:   ifmap_clx_sec_delSourceGuardEntry
 * PURPOSE:
 *      This API is used to delete a source guard entry.
 * INPUT:
 *      unit  --  Device unit number
 *      ptr_entry  --  The source guard entry which will be deleted. It should at least be filled with the keys.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation is successful.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_NO_MEMORY  --  No available memory for this operation.
 *      CLX_E_ENTRY_NOT_FOUND  --  The entry doesn't exist.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      Once the input source guard entry keys matches an existing source guard entry keys,
 *      no matter the source guard entry contents are matched or not, the entry will be deleted.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_delSourceGuardEntry(
    const UI32_T                    unit,
    const CLX_SEC_SG_ENTRY_T        *ptr_user_entry);

/* FUNCTION NAME:   ifmap_clx_sec_getSourceGuardEntry
 * PURPOSE:
 *      This API is used to get a source guard entry.
 * INPUT:
 *      unit  --  Device unit number
 *      ptr_entry  --  The source guard entry which will be provided. It should be filled with the keys,
 *                     which are used to get the source guard entry.
 * OUTPUT:
 *      ptr_entry  --  The source guard entry which will be provided. It includes keys and checked contents.
 * RETURN:
 *      CLX_E_OK  --  Operation is successful.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getSourceGuardEntry(
    const UI32_T                    unit,
    CLX_SEC_SG_ENTRY_T              *ptr_user_entry);

/* FUNCTION NAME:   ifmap_clx_sec_setEgressPort
 * PURPOSE:
 *      This API is used to set egress ports of an ingress port.
 * INPUT:
 *      unit  --  Device unit number
 *      user_port  --  Ingress user port ID
 *      user_port_bitmap -- Egress user port bitmap
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      For a given ingress port, the packet is allowed to be sent to the egress port only if the corresponding bit
 *      of the port is set in the port bitmap. <CL>
 *      If user wants to add an egress port to the given ingress port, set the corresponding bit to 1
 *      in the port_bitmap. <CL>
 *      If user wants to delete an egress port from the given ingress port, set the corresponding bit to 0
 *      in the port_bitmap.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_setEgressPort(
    const UI32_T                    unit,
    const UI32_T                    user_port,
    const CLX_PORT_BITMAP_T         user_port_bitmap);

/* FUNCTION NAME:   ifmap_clx_sec_getEgressPort
 * PURPOSE:
 *      This API is used to get egress ports of an ingress port.
 * INPUT:
 *      unit  --  Device unit number
 *      user_port  --  Ingress user port ID
 * OUTPUT:
 *      user_port_bitmap -- Egress user port bitmap
 * RETURN:
 *      CLX_E_OK --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      For a given ingress port, the packet is allowed to be sent to the egress port only
 *      if the corresponding bit of the port is set to 1 in the port bitmap.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getEgressPort(
    const UI32_T                    unit,
    const UI32_T                    user_port,
    CLX_PORT_BITMAP_T               user_port_bitmap);

#endif /* CLX_SEC_H */



