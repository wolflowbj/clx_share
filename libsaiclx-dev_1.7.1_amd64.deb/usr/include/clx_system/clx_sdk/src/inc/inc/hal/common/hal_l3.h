/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_l3.h
 * PURPOSE:
 *      It provides hal l3 module API.
 * NOTES:
 *
 *
 */
#ifndef HAL_L3_H
#define HAL_L3_H

/*****************************************************************************
 * INCLUDE FILE DECLARATIONS
 *****************************************************************************
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_swc.h>
#include <clx_fcoe.h>
#include <clx_l3.h>
#include <cmlib/cmlib_util.h>
#include <cmlib/cmlib_avl.h>
#include <cmlib/cmlib_list.h>
#include <cmlib/cmlib_bit.h>
#include <cmlib/cmlib_bitmap.h>
#include <hal/common/hal_vlan.h>
#include <hal/common/hal_tbl.h>
#include <hal/common/hal_io.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
#define HAL_L3_ECMP_SW_MODE_SYNC            (1)
#define HAL_L3_RPF_NUM                      (16384)

/* Capacity and Usage */
#define HAL_L3_PARAM_V4_V6                  (0)
#define HAL_L3_PARAM_V4                     (1)
#define HAL_L3_PARAM_V6                     (2)

/* INTF */
#define HAL_L3_INTF_ENTRY_NUM(unit)         (HAL_TBL_INFO(unit, TBL_IDS_RSLT_SRV_L3_INTF_ID)->entry_max_number)
#define HAL_L3_INTF_ENTRY_MIN(unit)         (1) /* SW-reserved 0 to disable routing with vrf=all-1. */
#define HAL_L3_INTF_ENTRY_MAX(unit)         (HAL_L3_INTF_ENTRY_NUM(unit) - 2) /* HW-reserved all-1 to use outer vid as L3 Intf */

#define HAL_L3_MTU_SIZE                     (16383)

/* Router-MAC */
#define HAL_L3_MY_ROUTEMAC_NUM(unit)        (HAL_TBL_INFO(unit, TBL_IDS_KEY_TCAM_MY_RTE_MAC_ID)->entry_max_number)
#define HAL_L3_MY_ROUTEMAC_MIN(unit)        (0)
#define HAL_L3_MY_ROUTEMAC_MAX(unit)        (HAL_L3_MY_ROUTEMAC_NUM(unit) - 1)

/* VRF */
#define HAL_L3_VRF_ENTRY_NUM(unit)          (HAL_TBL_INFO(unit, TBL_ILE_RSLT_VRF_ID)->entry_max_number / 2)
#define HAL_L3_VRF_ENTRY_MIN(unit)          (0)
#define HAL_L3_VRF_ENTRY_MAX(unit)          (HAL_L3_VRF_ENTRY_NUM(unit) - 2)
#define HAL_L3_VRF_ENTRY_ALL_1(unit)        (HAL_L3_VRF_ENTRY_NUM(unit) - 1) /* HW-reserved all-1 for (*,IP) */

#define HAL_L3_VRF_ADMIN_STATE_ENABLE       (1)
#define HAL_L3_VRF_ADMIN_STATE_DISABLE      (0)

/* ADJ */
#define HAL_L3_FRR_INVALID_GRP_ID           (0xFFFF)
#define HAL_L3_RESERVE_ADJ_ID               (0)

/* ECMP */
#define HAL_L3_ECMP_PATH_ENCAP_IDX_MIN      (8192)

#define HAL_L3_ECMP_PATH_MAX_TOT            (1U << 13) /* act_tot = MAX      */
#define HAL_L3_ECMP_PATH_MAX_TOT_IN_CHIP    (0)        /* act_tot = 0        */
#define HAL_L3_ECMP_HSH_MAX_TOT             (1U << 15) /* sw_spray_tot = MAX */
#define HAL_L3_ECMP_HSH_MAX_TOT_IN_CHIP     (0)        /* sw_spray_tot = 0   */

#define HAL_L3_ECMP_PATH_DFLT_BASE_IDX      (16383)    /* default act_base or orig_base */
#define HAL_L3_ECMP_PATH_DFLT_TOT           (0)        /* default act_tot or orig_tot   */
#define HAL_L3_ECMP_HSH_DFLT_BASE_IDX       (32767)    /* default sw_spray_base         */
#define HAL_L3_ECMP_HSH_DFLT_TOT            (0)        /* default sw_spray_tot          */
#define HAL_L3_ECMP_HSH_DFLT_OFFSET         (8191)     /* default offset                */

/* MCAST */
#define HAL_L3_MCAST_PER_GROUP_PER_PORT_MAX_EGR_INTF_NUM    (8192)

#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UI64_RSHIFT(dst, shift)     ((dst) >>= (shift))
#define UI64_LSHIFT(dst, shift)     ((dst) <<= (shift))
#else
#define UI64_RSHIFT(dst, shift)         \
    do                                  \
    {                                   \
        if (64 == (shift))              \
        {                               \
            UI64_LOW(dst) = 0;          \
            UI64_HI(dst) = 0;           \
        }                               \
        else if ((shift) >= 32)         \
        {                               \
            UI64_LOW(dst) = UI64_HI(dst) >> ((shift) - 32); \
            UI64_HI(dst) = 0;           \
        }                               \
        else if ((shift) > 0)           \
        {                               \
            UI32_T temp = 0;            \
            UI64_LOW(dst) >>= (shift);  \
            temp = UI64_HI(dst) & ((1U << (shift)) - 1);    \
            UI64_LOW(dst) |= temp << (32 - (shift));        \
            UI64_HI(dst) >>= (shift);   \
        }                               \
    } while(0)

#define UI64_LSHIFT(dst, shift)         \
    do                                  \
    {                                   \
        if (64 == (shift))              \
        {                               \
            UI64_HI(dst) = 0;           \
            UI64_LOW(dst) = 0;          \
        }                               \
        else if ((shift) >= 32)         \
        {                               \
            UI64_HI(dst) = UI64_LOW(dst) << ((shift) - 32); \
            UI64_LOW(dst) = 0;          \
        }                               \
        else if ((shift) > 0)           \
        {                               \
            UI32_T temp = 0;            \
            UI64_HI(dst) <<= (shift);   \
            temp = UI64_LOW(dst) & (~(32 - (shift)));       \
            UI64_HI(dst) |= temp >> (32 - (shift));         \
            UI64_LOW(dst) <<= (shift);  \
        }                               \
    } while(0)

#endif

/*****************************************************************************
 * MACRO FUNCTION DECLARATIONS
 *****************************************************************************
 */
/* Checker */
#define HAL_L3_IP_IS_MULTICAST(ptr_ip) \
    ((TRUE == (ptr_ip)->ipv4)? \
        CLX_IPV4_IS_MULTICAST((ptr_ip)->ip_addr.ipv4_addr) : \
        CLX_IPV6_IS_MULTICAST((ptr_ip)->ip_addr.ipv6_addr))

#define HAL_L3_IP_IS_ZERO(ptr_ip) \
    ((TRUE == (ptr_ip)->ipv4)? \
        (0x0 == (ptr_ip)->ip_addr.ipv4_addr) : \
        (0x0 == (ptr_ip)->ip_addr.ipv6_addr[0] && \
         0 == osal_memcmp((ptr_ip)->ip_addr.ipv6_addr, (ptr_ip)->ip_addr.ipv6_addr + 1, 15)))

#define HAL_L3_IP_MASK_IS_ZERO(ptr_ip) \
    ((TRUE == (ptr_ip)->ipv4)? \
        (0x0 == (ptr_ip)->ip_mask.ipv4_addr) : \
        (0x0 == (ptr_ip)->ip_mask.ipv6_addr[0] && \
         0 == osal_memcmp((ptr_ip)->ip_mask.ipv6_addr, (ptr_ip)->ip_mask.ipv6_addr + 1, 15)))

#define HAL_L3_IP_MASK_IS_FULLMSK(ptr_ip) \
    ((TRUE == (ptr_ip)->ipv4)? \
        (0xFFFFFFFFU == (ptr_ip)->ip_mask.ipv4_addr) : \
        (0xFF == (ptr_ip)->ip_mask.ipv6_addr[0] && \
         0 == osal_memcmp((ptr_ip)->ip_mask.ipv6_addr, (ptr_ip)->ip_mask.ipv6_addr + 1, 15)))

#define HAL_L3_CHK_IP_VER_MATCH(ip1, ip2) \
    do { \
        if ((ip1).ipv4 != (ip2).ipv4) \
        { \
            HAL_CHECK_ERROR(CLX_E_BAD_PARAMETER); \
        } \
    } while(0)

#define HAL_L3_CHK_FLW_LBL(__unit__, __tbl_id__, __field_id__, __flw_lbl__) \
    do { \
        if (!HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __flw_lbl__)) \
        { \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid group_label=%d\n", __unit__, __flw_lbl__); \
            return CLX_E_BAD_PARAMETER; \
        } \
    } while(0)

/* utility */
#define HAL_L3_PLANE_BMP_FOREACH(__unit__, __plane__) \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM; (__plane__)++) \
        if (CMLIB_BITMAP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

/*****************************************************************************
 * DATA TYPE DECLARATIONS
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- Common */
/* Warmboot */
typedef enum
{
    HAL_L3_WBDB_INTF_IEV_L2UC_DROP_IDX = 0, /* iev_l2uc_drop_idx     */
    HAL_L3_WBDB_INTF_INTF2FDID,             /* ptr_intf2fdid         */
    HAL_L3_WBDB_INTF_FDID2INTF,             /* ptr_fdid2intf         */
    HAL_L3_WBDB_INTF_INTF2VRF,              /* ptr_fdid2vrf          */
    HAL_L3_WBDB_INTF_LAST

} HAL_L3_WBDB_INTF_T;

typedef enum
{
    HAL_L3_WBDB_VRF_IEV_L3UC_DROP_IDX = 0,  /* iev_l3uc_drop_idx     */
    HAL_L3_WBDB_VRF_IEV_L3UC_TO_CPU_IDX,    /* iev_l3uc_to_cpu_idx   */
    HAL_L3_WBDB_VRF_GROUP_LABEL,            /* ptr_group_label       */
    HAL_L3_WBDB_VRF_TO_CPU_BMP,             /* ptr_to_cpu_bmp        */
    HAL_L3_WBDB_VRF_IPV4_STATE_BMP,         /* ptr_ipv4_state_bmp    */
    HAL_L3_WBDB_VRF_IPV6_STATE_BMP,         /* ptr_ipv4_state_bmp    */
    HAL_L3_WBDB_VRF_GLOBAL_TO_CPU,          /* global_to_cpu         */
    HAL_L3_WBDB_VRF_LAST

} HAL_L3_WBDB_VRF_T;

typedef enum
{
    HAL_L3_WBDB_ADJ_AVL = 0,                /* ptr_avl               */
    HAL_L3_WBDB_ADJ_URPF_USE_NUM,           /* ptr_urpf_use_num      */
    HAL_L3_WBDB_ADJ_LAST

} HAL_L3_WBDB_ADJ_T;

typedef enum
{
    HAL_L3_WBDB_ECMP_AVL = 0,               /* ptr_avl               */
    HAL_L3_WBDB_ECMP_SW_ECMP_PATH_BASE,     /* sw_ecmp_path_base     */
    HAL_L3_WBDB_ECMP_SW_ECMP_PATH_TOT,      /* sw_ecmp_path_tot      */
    HAL_L3_WBDB_ECMP_SW_ECMP_PATH_USE_NUM,  /* sw_ecmp_path_use_num  */
    HAL_L3_WBDB_ECMP_SW_ECMP_PATH_BLOCK_SZ, /* sw_ecmp_path_block_sz */
    HAL_L3_WBDB_ECMP_FDL_EN,                /* fdl_en                */
    HAL_L3_WBDB_ECMP_FDL_PATH_TO_GRP_ID,    /* fdl_path_to_grp_id    */
    HAL_L3_WBDB_ECMP_FDL_PATH_TO_ADJ_ID,    /* fdl_path_to_adj_id    */
    HAL_L3_WBDB_ECMP_FDL_ADJ_BASE,          /* fdl_adj_base          */
    HAL_L3_WBDB_ECMP_FDL_PATH_BASE,         /* fdl_path_base         */

    HAL_L3_WBDB_ECMP_LAST

} HAL_L3_WBDB_ECMP_T;

typedef enum
{
    HAL_L3_WBDB_HOST_IPV4_HASH_1X_CNT = 0,  /* ipv4_hash_1x_cnt      */
    HAL_L3_WBDB_HOST_IPV6_HASH_4X_CNT,      /* ipv6_hash_4x_cnt      */
    HAL_L3_WBDB_HOST_LAST

} HAL_L3_WBDB_HOST_T;

typedef enum
{
    HAL_L3_WBDB_ROUTE_TCAM_SIP_EN = 0,      /* tcam_sip_en           */
    HAL_L3_WBDB_ROUTE_TCAM_BANK_2X_CNT,     /* tcam_bank_2x_cnt      */
    HAL_L3_WBDB_ROUTE_TCAM_BANK_4X_CNT,     /* tcam_bank_4x_cnt      */
    HAL_L3_WBDB_ROUTE_TCAM_BANK,            /* tcam_bank             */
    HAL_L3_WBDB_ROUTE_TCAM_BLOCK_1X,        /* tcam_block_1x         */
    HAL_L3_WBDB_ROUTE_TCAM_BLOCK_2X,        /* tcam_block_2x         */
    HAL_L3_WBDB_ROUTE_TCAM_BLOCK_4X,        /* tcam_block_4x         */
    HAL_L3_WBDB_ROUTE_EXM_VRF_VLD,          /* exm_vrf_vld           */
    HAL_L3_WBDB_ROUTE_EXM_V4_MSK_BTOT,      /* exm_v4_msk_btot       */
    HAL_L3_WBDB_ROUTE_EXM_V6_MSK_BTOT,      /* exm_v6_msk_btot       */
    HAL_L3_WBDB_ROUTE_EXM_V4_CNT,           /* exm_v4_cnt            */
    HAL_L3_WBDB_ROUTE_EXM_V6_CNT,           /* exm_v6_cnt            */
    HAL_L3_WBDB_ROUTE_EXM_STATIC,           /* exm_static            */
    HAL_L3_WBDB_ROUTE_IPV4_HASH_1X_CNT,     /* ipv4_hash_1x_cnt      */
    HAL_L3_WBDB_ROUTE_IPV6_HASH_2X_CNT,     /* ipv6_hash_2x_cnt      */
    HAL_L3_WBDB_ROUTE_IPV6_HASH_4X_CNT,     /* ipv6_hash_4x_cnt      */
    HAL_L3_WBDB_ROUTE_IPV4_TCAM_1X_CNT,     /* ipv4_tcam_1x_cnt      */
    HAL_L3_WBDB_ROUTE_IPV6_TCAM_2X_CNT,     /* ipv6_tcam_2x_cnt      */
    HAL_L3_WBDB_ROUTE_IPV6_TCAM_4X_CNT,     /* ipv6_tcam_4x_cnt      */
    HAL_L3_WBDB_ROUTE_LAST

} HAL_L3_WBDB_ROUTE_T;

typedef enum
{
    HAL_L3_WBDB_MCAST_L3RC_BMP = 0,         /* l3rc_bmp              */
    HAL_L3_WBDB_MCAST_MET_BMP,              /* met_bmp               */
    HAL_L3_WBDB_MCAST_RP_ID_BMP,            /* rp_id_bmp             */
    HAL_L3_WBDB_MCAST_RPA_AVL,              /* ptr_rpa_avl           */
    HAL_L3_WBDB_MCAST_RPF_USE_NUM,          /* ptr_rpf_use_num       */
    HAL_L3_WBDB_MCAST_LAST

} HAL_L3_WBDB_MCAST_T;

#define HAL_L3_WBDB_INTF_BASE   (0)
#define HAL_L3_WBDB_VRF_BASE    (HAL_L3_WBDB_INTF_BASE  + HAL_L3_WBDB_INTF_LAST)
#define HAL_L3_WBDB_ADJ_BASE    (HAL_L3_WBDB_VRF_BASE   + HAL_L3_WBDB_VRF_LAST)
#define HAL_L3_WBDB_ECMP_BASE   (HAL_L3_WBDB_ADJ_BASE   + HAL_L3_WBDB_ADJ_LAST)
#define HAL_L3_WBDB_HOST_BASE   (HAL_L3_WBDB_ECMP_BASE  + HAL_L3_WBDB_ECMP_LAST)
#define HAL_L3_WBDB_ROUTE_BASE  (HAL_L3_WBDB_HOST_BASE  + HAL_L3_WBDB_HOST_LAST)
#define HAL_L3_WBDB_MCAST_BASE  (HAL_L3_WBDB_ROUTE_BASE + HAL_L3_WBDB_ROUTE_LAST)
#define HAL_L3_WBDB_NUM         (HAL_L3_WBDB_MCAST_BASE + HAL_L3_WBDB_MCAST_LAST)

/* Dump SWDB */
typedef enum
{
    HAL_L3_DB_DUMP_FLAGS_INTF = 0,
    HAL_L3_DB_DUMP_FLAGS_HOST,
    HAL_L3_DB_DUMP_FLAGS_ROUTE,
    HAL_L3_DB_DUMP_FLAGS_ADJ,
    HAL_L3_DB_DUMP_FLAGS_ECMP,
    HAL_L3_DB_DUMP_FLAGS_MCAST,
    HAL_L3_DB_DUMP_FLAGS_VRF,
    HAL_L3_DB_DUMP_FLAGS_LAST,

} HAL_L3_DB_DUMP_FLAGS_T;

typedef struct HAL_L3_IEV_RSRC_S
{
    /* hal_l3_allocIev      get iev_idx by User data
     * hal_l3_freeIev       free iev_idx
     * hal_l3_getIev        read HW data
     * hal_l3_resolveIev    resolve HW data to User data
     * hal_l3_transIevInfo  resolve port and intf_id to HW data (packPathBuf)
     *                      resolve HW data to port and intf_id (unpackPathBuf)
     */

    /* HW data */
    UI32_T                  typ;            /* SubnetBcast|Mcast            */
    UI32_T                  adj_idx;        /* Host|Route                   */
    UI32_T                  ueid_mgid;      /* Host|Route|SubnetBcast|Mcast */
    UI32_T                  seg_vmid;       /* Host|Route                   */
    UI32_T                  decr_ttl;       /* SubnetBcast                  */

    /* User data */
    CLX_L3_OUTPUT_TYPE_T    output_type;    /* Host|Route             */
    UI32_T                  output_id;      /* Host|Route             */
    UI32_T                  subnet_bc_id;   /* SubnetBcast            */
    UI32_T                  subnet_bc_en;   /* SubnetBcast            */
    UI32_T                  mcast_id;       /* Mcast                  */
    UI32_T                  mcast_en;       /* Mcast                  */
    UI32_T                  mpls_label;     /* Host|Route             */
    UI32_T                  mpls_en;        /* Host|Route             */
    UI32_T                  uc_drop;        /* Host|Route             */
    UI32_T                  mc_drop;        /* Mcast                  */
    UI32_T                  pim_reg;        /* Mcast                  */

    /* Both */
    UI32_T                  cp_to_cpu_idx;      /* Mcast              */
    UI32_T                  pim_sm_spt_rdy;     /* Mcast              */
    UI32_T                  mrpf_fail_act;      /* Mcast              */
    UI32_T                  l3_intf_id;         /* Mcast              */
    UI32_T                  acc_intf_is_sig;    /* Mcast              */

} HAL_L3_IEV_RSRC_T;

/* ----------------------------------------------------------------------------------- INTF */
typedef struct HAL_L3_INTF_RSRC_S
{
    /* resources waited to be free */
    UI32_T                  ids_mtu_idx;    /* l3_mtu_idx       : IDS_RSLT_L3_MTU        */
    UI32_T                  ids_prof_idx;   /* cnt_mtr_prof_idx : ICIA_RSLT_CNT|CLR_PROF */
    UI32_T                  iev_mtu_idx;    /* l3_mtu_idx       : IEV_RSLT_L3_MTU        */
    UI32_T                  emi_sa_idx;     /* l2_sa_idx        : EMI_RSLT_MAC_SA        */
    UI32_T                  emi_mtu_idx;    /* l3_mtu_idx       : EMI_RSLT_L3_MTU        */
    UI32_T                  emi_prof_idx;   /* cnt_mtr_prof_idx : ECIA_RSLT_CNT|CLR_PROF */

    /* when these fields are changed, traverse ADJ to find (ecmp|frr, intf) */
    UI32_T                  urpf_mode;
    UI32_T                  icmpv4_redir;
    UI32_T                  icmpv6_redir;

} HAL_L3_INTF_RSRC_T;

/* copy this structer for the purpose use intf vrf field */
typedef struct HAL_L3_INTF_CB_S
{
    UI32_T                      iev_l2uc_drop_idx;  /* Hit my_rte_mac but HW can't route */
    UI32_T                      *ptr_intf2fdid;     /* Array of l3 interface */
    UI32_T                      *ptr_intf2vrf;      /* Array of vrf */
    UI32_T                      *ptr_fdid2intf;     /* Array of bdid */
    CLX_SEMAPHORE_ID_T          sema;

} HAL_L3_INTF_CB_T;

/* ----------------------------------------------------------------------------------- VRF */
typedef struct HAL_L3_VRF_CB_S
{
    UI32_T                  iev_l3uc_drop_idx;      /* VRF or global default route to drop */
    UI32_T                  iev_l3uc_to_cpu_idx;    /* VRF or global default route to cpu  */
    UI32_T                  *ptr_group_label;       /* VRF default group label */
    UI32_T                  *ptr_to_cpu_bmp;        /* VRF default action. 0: drop, 1: to-cpu */
    UI32_T                  *ptr_ipv4_state_bmp;    /* VRF admin state. 0: diable, 1: enable */
    UI32_T                  *ptr_ipv6_state_bmp;    /* VRF admin state. 0: diable, 1: enable */
    UI32_T                  global_to_cpu;          /* system default action. 0: drop, 1: to-cpu */
    CLX_SEMAPHORE_ID_T      sema;

} HAL_L3_VRF_CB_T;

/* ----------------------------------------------------------------------------------- ADJ */
typedef struct HAL_L3_ADJ_NODE_S
{
    /* AVL key */
    UI32_T                  adj_id;         /* hw adj index           */

    /* AVL data */
    UI32_T                  iev_idx;        /* hw iev index           */
    CMLIB_LIST_T            *ptr_ecmp_list; /* hw ecmp group-id list  */
    CMLIB_LIST_T            *ptr_frr_list;  /* hw frr group-id list of this backup adj */
    UI32_T                  use_num;        /* reference count of host, route, ecmp, and frr */
    CLX_PORT_T              port;           /* interface object       */

} HAL_L3_ADJ_NODE_T;

typedef struct HAL_L3_ADJ_INFO_S
{
    UI32_T                  adj_id;         /* hw adj index           */
    UI32_T                  iev_idx;        /* hw iev index           */
    UI32_T                  intf_id;        /* hw intf index          */
    UI32_T                  seg_vmid;       /* hw seg_vmid            */
    UI32_T                  ueid_mgid;      /* hw ueid_mgid           */
    UI32_T                  decr_ttl;       /* flag for decr ttl      */
    UI32_T                  urpf_en;        /* flag for strict urpf   */
    UI32_T                  drop;           /* black hole             */
    UI32_T                  seg_id;         /* sw seg_id, HAL_INVALID_ID means invalid */
    UI16_T                  frr_grp_id;     /* frr group id, HAL_L3_FRR_INVALID_GRP_ID means invalid */
    UI32_T                  use_num;        /* reference count of host, route, ecmp, and frr */
    CLX_PORT_T              port;           /* interface object       */

} HAL_L3_ADJ_INFO_T;

typedef struct HAL_L3_ADJ_TRAV_COOKIE_S
{
    UI32_T                  unit;

    /* [Out] for traverseAdj() API, store the TRAV_DATA in list */
    CMLIB_LIST_T            *ptr_list;

    /* [In] for travGrpUpdateUrpf(), add or del ECMP/FRR uRPF when change intf urpf_mode */
    UI32_T                  intf_id;
    UI32_T                  is_add;

} HAL_L3_ADJ_TRAV_COOKIE_T;

typedef struct HAL_L3_ADJ_TRAV_DATA_S
{
    UI32_T                  adj_id;
    CLX_L3_ADJ_INFO_T       adj_info;

} HAL_L3_ADJ_TRAV_DATA_T;

/* ----------------------------------------------------------------------------------- ECMP */
typedef struct HAL_L3_ECMP_NODE_S
{
    /* AVL key */
    UI32_T                  grp_id;         /* hw ecmp group index    */

    /* AVL data */
    UI32_T                  grp_mode;       /* hw ecmp group mode     */
    UI32_T                  grp_type;       /* hw ecmp group type     */
    UI32_T                  iev_idx;        /* hw iev index           */
    UI32_T                  path_cnt;
    UI32_T                  weight_cnt;
    UI32_T                  weight_vld;     /* only update weight_cnt when this field is 1 */
    UI32_T                  use_num;        /* reference count of host, route, fdl */
    UI32_T                  real_size;      /* real hash buckets for fine grain ECMP */
    UI32_T                  use_default;    /* insert default path */
} HAL_L3_ECMP_NODE_T;

typedef struct HAL_L3_ECMP_INFO_S
{
    UI32_T                  grp_id;         /* hw ecmp group index    */
    CLX_L3_ECMP_MODE_TYPE_T grp_mode;       /* hw ecmp group mode     */
    CLX_L3_OUTPUT_TYPE_T    grp_type;       /* hw ecmp group type     */
    UI32_T                  iev_idx;        /* hw iev index           */
    UI32_T                  decr_ttl;       /* flag for decr ttl      */
    UI32_T                  urpf_en;        /* flag for strict urpf   */
    UI32_T                  path_cnt;
    UI32_T                  weight_cnt;
    UI32_T                  weight_vld;     /* only update weight_cnt when this field is 1 */
    UI32_T                  use_num;        /* reference count of host, route */
    UI32_T                  real_size;      /* real hash buckets for fine grain ECMP */
    UI32_T                  use_default;    /* insert default path */
} HAL_L3_ECMP_INFO_T;

typedef struct HAL_L3_ECMP_PATH_RSRC_S
{
    /* group */
    HAL_L3_ECMP_INFO_T      ecmp_info;      /* SWDB info */
    UI32_T                  grp_tbl_id;     /* ECMP_U */
    union
    {
        UI32_T              hw_buf[CDB_IEV_RSLT_ECMP_U_HW_WORDS];
        UI32_T              sw_buf[CDB_IEV_RSLT_ECMP_U_SW_WORDS];
    } grp_buf;

    /* [add/del] path from user
     * [get] path from hw
     */
    UI32_T                  path_weight;    /* weight or 1 */
    UI32_T                  path_tbl_id;    /* ECMP_PATH_U */
    union
    {
        UI32_T              ep_l3_buf[CDB_IEV_RSLT_ECMP_PATH_U_EP_L3_WORDS];
        UI32_T              ul_l2_buf[CDB_IEV_RSLT_ECMP_PATH_U_UL_L2_WORDS];
        UI32_T              ul_l3_buf[CDB_IEV_RSLT_ECMP_PATH_U_UL_L3_WORDS];
        UI32_T              encap_buf[CDB_IEV_RSLT_ECMP_PATH_ENCAP_WORDS];
    } path_buf;

    /* [add/del] state from user
     * [get] state from hw
     */
    UI32_T                  state_frr_id;
    UI32_T                  state_tbl_id;   /* ECMP_ACT or NVO3_ECMP_ACT */
    union
    {
        UI32_T              act_buf[CDB_IEV_RSLT_ECMP_STATE_ACT_WORDS];
        UI32_T              nvo3_act_buf[CDB_IEV_RSLT_NVO3_ECMP_STATE_ACT_WORDS];
    } state_buf;

    /* metas from HW act */
    UI32_T                  new_num;        /* number of is_new=1 in this group */
    UI32_T                  act_offset;     /* path offset */
    UI32_T                  act_weight;     /* path count for hw, or sw_spray count for sw */
    UI32_T                  act_vld;

    /* metas from HW orig */
    UI32_T                  inact_num;      /* number of is_act=0 in this group */
    UI32_T                  orig_offset;    /* path offset */
    UI32_T                  orig_weight;    /* path count for hw */
    UI32_T                  orig_vld;       /* this path may be out of orig, but in act */
    UI32_T                  reserved_path;  /* path is reserved */

}HAL_L3_ECMP_PATH_RSRC_T;

/* ----------------------------------------------------------------------------------- HOST */
typedef struct HAL_L3_HOST_RSRC_S
{
    UI32_T                  ipv4;
    UI32_T                  tbl_id;         /* ILE table ID           */
    UI32_T                  bank_bmp;       /* ILE bank bitmap        */
    UI32_T                  flw_lbl;        /* ILE in-band IEV result */
    HAL_L3_IEV_RSRC_T       iev_rsrc;       /* IEV result             */
    union
    {
        UI32_T              ipv4_buf[CDB_ILE_HSH_1X_U_L3_IPV4_XA_WORDS];
        UI32_T              ipv6_buf[CDB_ILE_HSH_4X_U_L3_IPV6_XA_WORDS];
    } buf;
    C8_T                    ip_str[CMLIB_UTIL_IP_ADDR_STR_SIZE];

    /* hitbit */
    UI32_T                  dip_hit;
    UI32_T                  sip_hit;

} HAL_L3_HOST_RSRC_T;

/* ----------------------------------------------------------------------------------- ROUTE */
typedef struct HAL_L3_ROUTE_RSRC_S
{
    UI32_T                  tbl_id;         /* ILE table ID             */
    UI32_T                  bank_bmp;       /* ILE bank bitmap [HASH]   */
    UI32_T                  free_exm;       /* ILE free EXM id [HASH]   */
    UI32_T                  flw_lbl;        /* IEV_INDIR result         */
    UI32_T                  iev_idx;        /* IEV index (getFcoe)      */
    HAL_L3_IEV_RSRC_T       iev_rsrc;       /* IEV result               */
    union
    {
        UI32_T              fcoe_tcam_1x_buf[CDB_ILE_COM_TCAM_1X_U_FCOE_FIB_WORDS];
        UI32_T              ipv4_tcam_1x_buf[CDB_ILE_COM_TCAM_1X_U_L3_FIB_IP_XA_WORDS];
        UI32_T              ipv6_tcam_2x_buf[CDB_ILE_COM_TCAM_2X_U_L3_FIB_IPV6_XA_WORDS];
        UI32_T              ipv6_tcam_4x_buf[CDB_ILE_COM_TCAM_4X_U_L3_FIB_IPV6_XA_WORDS];
        UI32_T              ipv4_hash_1x_buf[CDB_ILE_HSH_1X_U_L3_IPV4_XA_WORDS];
        UI32_T              ipv6_hash_2x_buf[CDB_ILE_HSH_2X_U_L3_IPV6_XA_WORDS];
        UI32_T              ipv6_hash_4x_buf[CDB_ILE_HSH_4X_U_L3_IPV6_XA_WORDS];
    } buf;
    C8_T                    ip_str[CMLIB_UTIL_IP_NETWORK_STR_SIZE];

    /* e.g.
     * ip=192.168.0.4/31, root-ip=192.168.0.0/29 (buf)
     * found root ile_idx=8192, iev_indir_idx=327680, trie_bmp=0x111, iev_idx=81920 (read from ADJ)
     *
     * - vrf_vld            is 1      (calculated from flag)
     * - msk_btot           is 3      (calculated from prefix)
     * - real_prefix        is 31
     * - root_prefix        is 29
     * - root_key           is 15
     *
     * - trie_bit           is 5      (0 or calculated from trie-bmp)
     * - rslt_shift         is 1      (0 or calculated from trie-bmp)
     *
     * - root_vld           is 1
     * - root_d_ile_idx     is 8192   (read from AVL)
     * - root_s_ile_idx     is 12288  (read from AVL)
     * - root_rslt_idx      is 327680 (read from HW)
     * - root_rslt_cnt      is 3      (read from HW)
     * - real_vld           is 1
     */
    UI32_T                  is_1x;              /* ILE is_1x                                */
    UI32_T                  vrf_vld;            /* ILE vrf_vld                              */
    UI32_T                  msk_btot;           /* ILE msk_btot                             */
    UI32_T                  real_prefix;
    UI32_T                  root_prefix;
    UI32_T                  root_key;           /* calculated block key [TCAM]              */

    UI32_T                  trie_bit;           /* based on root IP                         */
    UI32_T                  rslt_shift;         /* based on IEV_INDIR index                 */

    UI32_T                  root_vld;           /* root IP exists in HW                     */
    UI32_T                  root_d_ile_idx;     /* root ILE DIP 1x      (only for root_vld) */
    UI32_T                  root_s_ile_idx;     /* root ILE SIP 1x      (only for root_vld) */
    UI32_T                  root_rslt_idx;      /* root IEV indir index (only for root_vld) */
    UI32_T                  root_rslt_cnt;      /* root IEV indir count (only for root_vld) */
    UI32_T                  real_vld;           /* real IP exists in HW                     */

} HAL_L3_ROUTE_RSRC_T;

typedef struct HAL_L3_ROUTE_TRAV_COOKIE_S
{
    UI32_T                  unit;

    /* [In] for traverseRoute() API, directly callback */
    UI32_T                  tbl_id;
    CMLIB_LIST_T            *ptr_list;
    UI32_T                  cnt;

    /* [In] for setIpNode() API, move d_ile_idx/s_ile_idx in this range */
    UI32_T                  is_dip;
    UI32_T                  entry_num;
    UI32_T                  old_idx;
    UI32_T                  new_idx;

} HAL_L3_ROUTE_TRAV_COOKIE_T;

/* ----------------------------------------------------------------------------------- MCAST */
/* Mcast Egress Interface */
typedef struct HAL_L3_MCAST_MEL_SUB_ENTRY_S
{
    /* ETM_RSLT_MEL_INFO */
    UI32_T                  src_supp_ck_vid;
    UI32_T                  src_supp_tag;
    HAL_VLAN_VID_CTL_T      vid_info;

    /* EMI_RSLT_MC_SC */
    UI32_T                  nvo3_adj_idx;
    UI32_T                  nvo3_encap_idx;
    UI32_T                  seg_vmid;

} HAL_L3_MCAST_MEL_SUB_ENTRY_T;

typedef struct HAL_L3_MCAST_MEL_INFO_S
{
    /* ETM_RSLT_MEL_INFO */
    UI32_T                  l3_intf_id;
    UI32_T                  decr_ttl;
    UI32_T                  src_supp_ck_vid;
    UI32_T                  src_supp_tag;

    /* EMI_RSLT_MEL */
    UI32_T                  nvo3_adj_idx;
    UI32_T                  nvo3_encap_idx;
    UI32_T                  seg_vmid;

    /* EMI_RSLT_ADJ */
    UI32_T                  da_mod;
    UI32_T                  sa_mod;
    CLX_MAC_T               dmac;
    HAL_VLAN_VID_CTL_T      vid_info;

} HAL_L3_MCAST_MEL_INFO_T;

typedef struct HAL_L3_MCAST_EGR_ENTRY_S
{
    BOOL_T                  is_fab;
    BOOL_T                  is_routed;
    UI32_T                  entry_num;
    HAL_L3_MCAST_MEL_INFO_T *ptr_mel_info;

} HAL_L3_MCAST_EGR_ENTRY_T;

typedef struct HAL_L3_MCAST_EGR_RSRC_S
{
    /* from user */
    UI32_T                  plane;
    UI32_T                  plane_port;

    /* from hw */
    UI32_T                  pbm[HAL_ITM_PBM_WORDS];
    UI32_T                  plane_port_num;

} HAL_L3_MCAST_EGR_RSRC_T;

/* Mcast Group */
typedef struct HAL_L3_MCAST_GRP_NODE_S
{
    /* AVL key */
    UI32_T                  mcast_id;

    /* AVL data */
    UI32_T                  l3rc[HAL_PLANE_NUM][HAL_PLANE_PORT + 1]; /* 1 for CPI */
    UI32_T                  use_num;

} HAL_L3_MCAST_GRP_NODE_T;

typedef struct HAL_L3_MCAST_GRP_RSRC_S
{
    UI32_T                  ipv4;
    UI32_T                  tbl_id;         /* ILE table ID           */
    UI32_T                  bank_bmp;       /* ILE bank bitmap        */
    UI32_T                  flw_lbl;        /* ILE in-band IEV result */
    HAL_L3_IEV_RSRC_T       iev_rsrc;       /* IEV result             */
    union
    {
        UI32_T              ipv4_xg_buf[CDB_ILE_HSH_1X_U_L3_IPV4_XA_WORDS];
        UI32_T              ipv4_sg_buf[CDB_ILE_HSH_2X_U_L3_IPV4_SG_WORDS];
        UI32_T              ipv6_xg_buf[CDB_ILE_HSH_4X_U_L3_IPV6_XA_WORDS];
        UI32_T              ipv6_sg_buf[CDB_ILE_HSH_4X_U_L3_IPV6_SG_WORDS];
    } buf;
    C8_T                    ip_str[CMLIB_UTIL_IP_ADDR_STR_SIZE];

    /* hitbit */
    UI32_T                  grp_hit;

} HAL_L3_MCAST_GRP_RSRC_T;

/* DF Interface */
typedef struct HAL_L3_MCAST_RPA_NODE_S
{
    /* AVL key */
    CLX_IP_ADDR_T           rp_addr;

    /* AVL data */
    UI32_T                  rp_id;
    UI32_T                  use_num;

} HAL_L3_MCAST_RPA_NODE_T;

typedef struct HAL_L3_MCAST_RPA_TRAV_COOKIE_S
{
    UI32_T                  unit;

    /* [In] for getDfIntf() API, get all RPAs from intf ID */
    UI32_T                  intf_id;
    UI32_T                  cnt;
    UI32_T                  real_cnt;

    /* [In] for getGroup() API, get RPA from RP-ID */
    UI32_T                  rp_id;

    /* [Out] RPA */
    CLX_IP_ADDR_T           *ptr_rp_addr;

} HAL_L3_MCAST_RPA_TRAV_COOKIE_T;

/* ----------------------------------------------------------------------------------- Function */
typedef CLX_ERROR_NO_T
(*HAL_L3_ECMP_CALLBACK_FUNC_T)(
    const UI32_T            unit,
    const UI32_T            adj_id,
    const UI32_T            ecmp_grp_id,
    const void              *ptr_cookie);

typedef CLX_ERROR_NO_T
(*HAL_L3_FRR_CALLBACK_FUNC_T)(
    const UI32_T            unit,
    const UI32_T            adj_id,
    const UI32_T            frr_grp_id,
    const void              *ptr_cookie);

/*****************************************************************************
 * LOCAL SUBPROGRAM BODIES
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- MAIN */
/* Utility */
CLX_ERROR_NO_T
hal_l3_dumpBitmap(
    const UI32_T    *ptr_bmp,
    const UI32_T    bmp_cnt);

/* IEV */
CLX_ERROR_NO_T
hal_l3_allocIev(
    const UI32_T                unit,
    const HAL_L3_IEV_RSRC_T     *ptr_iev_rsrc,
    UI32_T                      *ptr_iev_idx);

CLX_ERROR_NO_T
hal_l3_freeIev(
    const UI32_T                unit,
    const UI32_T                iev_idx);

CLX_ERROR_NO_T
hal_l3_getIev(
    const UI32_T                unit,
    const UI32_T                iev_idx,
    HAL_L3_IEV_RSRC_T           *ptr_iev_rsrc);

CLX_ERROR_NO_T
hal_l3_resolveIev(
    const UI32_T                unit,
    HAL_L3_IEV_RSRC_T           *ptr_iev_rsrc);

CLX_ERROR_NO_T
hal_l3_transIevInfo( /* for addAdj, setAdj */
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const UI32_T                intf_id,
    const UI32_T                sess_id,
    UI32_T                      *ptr_ueid_mgid,
    UI32_T                      *ptr_seg_vmid,
    UI32_T                      *ptr_seg_vmid_vld);

CLX_ERROR_NO_T
hal_l3_transIevPathInfo( /* for addFrrGrpPath, setFrrGrpPath, packPathBuf, setAdjEcmpList */
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const UI32_T                intf_id,
    const UI32_T                sess_id,
    UI32_T                      *ptr_ueid_mgid,
    UI32_T                      *ptr_seg_vmid,
    UI32_T                      *ptr_seg_vmid_vld,
    UI32_T                      *ptr_normal_port);

/* IEV_INDIR */
CLX_ERROR_NO_T
hal_l3_allocIevIndir(
    const UI32_T                unit,
    const UI32_T                iev_idx,
    const UI32_T                flw_lbl,
    const UI32_T                entry_count,
    UI32_T                      *ptr_iev_indir_idx);

CLX_ERROR_NO_T
hal_l3_freeIevIndir(
    const UI32_T                unit,
    const UI32_T                iev_indir_idx,
    const UI32_T                entry_count);

CLX_ERROR_NO_T
hal_l3_setIevIndir(
    const UI32_T                unit,
    const UI32_T                iev_indir_idx,
    const UI32_T                iev_idx,
    const UI32_T                flw_lbl);

CLX_ERROR_NO_T
hal_l3_getIevIndir(
    const UI32_T                unit,
    const UI32_T                iev_indir_idx,
    UI32_T                      *ptr_iev_idx,
    UI32_T                      *ptr_flw_lbl);

/* DMA */
CLX_ERROR_NO_T
hal_l3_moveTblDma(
    const UI32_T        unit,
    const UI32_T        tbl_id,
    const BOOL_T        delete_offset,
    const UI32_T        offset,
    const UI32_T        base_old,
    const UI32_T        num_old,
    const UI32_T        base_new);

CLX_ERROR_NO_T
hal_l3_clearTblDma(
    const UI32_T        unit,
    const UI32_T        tbl_id,
    const UI32_T        clear_base,
    const UI32_T        clear_num);

/* Properties */
CLX_ERROR_NO_T
hal_l3_setGlobalRouteMissAction(
    const UI32_T        unit,
    const UI32_T        action);

CLX_ERROR_NO_T
hal_l3_getGlobalRouteMissAction(
    const UI32_T        unit,
    UI32_T              *ptr_action);

CLX_ERROR_NO_T
hal_l3_setUrpfCheck(
    const UI32_T        unit,
    const UI32_T        is_enable);

CLX_ERROR_NO_T
hal_l3_getUrpfCheck(
    const UI32_T        unit,
    UI32_T              *ptr_is_enable);

CLX_ERROR_NO_T
hal_l3_setIcmpRedirect(
    const UI32_T        unit,
    const UI32_T        is_enable);

CLX_ERROR_NO_T
hal_l3_getIcmpRedirect(
    const UI32_T        unit,
    UI32_T              *ptr_is_enable);

CLX_ERROR_NO_T
hal_l3_setSelfForward(
    const UI32_T        unit,
    const UI32_T        is_enable);

CLX_ERROR_NO_T
hal_l3_getSelfForward(
    const UI32_T        unit,
    UI32_T              *ptr_is_enable);

CLX_ERROR_NO_T
hal_l3_setValidateIp(
    const UI32_T        unit,
    const UI32_T        enable,
    const UI32_T        fail_act);

CLX_ERROR_NO_T
hal_l3_getValidateIp(
    const UI32_T        unit,
    UI32_T              *ptr_enable,
    UI32_T              *ptr_fail_act);

/* Exceptions */
CLX_ERROR_NO_T
hal_l3_setL3ExcptAct(
    const UI32_T                unit,
    const CLX_SWC_PROPERTY_T    property,
    const CLX_FWD_ACTION_T      action);

CLX_ERROR_NO_T
hal_l3_getL3ExcptAct(
    const UI32_T                unit,
    const CLX_SWC_PROPERTY_T    property,
    CLX_FWD_ACTION_T            *ptr_action);

/* Resources */
CLX_ERROR_NO_T
hal_l3_getCapacity(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_size);

CLX_ERROR_NO_T
hal_l3_getUsage(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_cnt);

/* Chip Dispatcher */
CLX_ERROR_NO_T
hal_l3_fdid2intf(
    const UI32_T                unit,
    const CLX_BRIDGE_DOMAIN_T   bdid,
    UI32_T                      *ptr_intf_id);

CLX_ERROR_NO_T
hal_l3_intf2fdid(
    const UI32_T                unit,
    const UI32_T                intf_id,
    CLX_BRIDGE_DOMAIN_T         *ptr_bdid);

CLX_ERROR_NO_T
hal_l3_setGlobalRouteMissAction(
    const UI32_T                unit,
    const UI32_T                action);

CLX_ERROR_NO_T
hal_l3_getGlobalRouteMissAction(
    const UI32_T                unit,
    UI32_T                      *ptr_action);

CLX_ERROR_NO_T
hal_l3_getAdjInfo(
    const UI32_T                unit,
    const UI32_T                adj_id,
    HAL_L3_ADJ_INFO_T           *ptr_adj_info);

CLX_ERROR_NO_T
hal_l3_updateAdjUseNum(
    const UI32_T                unit,
    const UI32_T                adj_id,
    const BOOL_T                inc);

CLX_ERROR_NO_T
hal_l3_getEcmpInfo(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    HAL_L3_ECMP_INFO_T          *ptr_ecmp_info);

CLX_ERROR_NO_T
hal_l3_updateEcmpGrpUseNum(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const BOOL_T                inc);

CLX_ERROR_NO_T
hal_l3_getPathIdxByGrpAdjId(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const CLX_L3_OUTPUT_TYPE_T  output_type,
    const UI32_T                adj_id,
    UI32_T                      *ptr_act_idx,
    UI32_T                      *ptr_act_cnt,
    UI32_T                      *ptr_orig_idx,
    UI32_T                      *ptr_orig_cnt);

CLX_ERROR_NO_T
hal_l3_setEcmpBlockSize(
    const UI32_T                unit,
    const UI32_T                size);

CLX_ERROR_NO_T
hal_l3_getEcmpBlockSize(
    const UI32_T                unit,
    UI32_T                      *ptr_size);

CLX_ERROR_NO_T
hal_l3_addFcoeTcamEntry(
    const UI32_T                unit,
    const UI32_T                is_vrf,
    const UI32_T                intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T  *ptr_fcid_addr,
    const UI32_T                group_label,
    const UI32_T                iev_rslt_idx);

CLX_ERROR_NO_T
hal_l3_delFcoeTcamEntry(
    const UI32_T                unit,
    const UI32_T                is_vrf,
    const UI32_T                intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T  *ptr_fcid_addr);

CLX_ERROR_NO_T
hal_l3_getFcoeTcamEntry(
    const UI32_T                unit,
    const UI32_T                is_vrf,
    const UI32_T                intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T  *ptr_fcid_addr,
    UI32_T                      *ptr_group_label,
    UI32_T                      *ptr_iev_rslt_idx);

CLX_ERROR_NO_T
hal_l3_delMemberAll(
    const UI32_T                        unit,
    const UI32_T                        mcast_id);

CLX_ERROR_NO_T
hal_l3_addMelSubEntryByPort(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T  *ptr_sub_entry);

CLX_ERROR_NO_T
hal_l3_delMelSubEntryByPort(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T  *ptr_sub_entry);

CLX_ERROR_NO_T
hal_l3_getMelSubEntryByPort(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        entry_num,
    HAL_L3_MCAST_MEL_SUB_ENTRY_T        *ptr_sub_entry,
    UI32_T                              *ptr_actual_num);

CLX_ERROR_NO_T
hal_l3_getMelSubEntryNumByPort(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    UI32_T                              *ptr_entry_num);

/* Init and Deinit */
CLX_ERROR_NO_T
hal_l3_init(
    const UI32_T    unit);

CLX_ERROR_NO_T
hal_l3_deinit(
    const UI32_T    unit);

/* Router-MAC */
CLX_ERROR_NO_T
hal_l3_addMyRouterMac(
    const UI32_T                    unit,
    const UI32_T                    index,
    const CLX_L3_ROUTER_MAC_INFO_T  *ptr_router_mac_info);

CLX_ERROR_NO_T
hal_l3_delMyRouterMac(
    const UI32_T                    unit,
    const UI32_T                    index);

CLX_ERROR_NO_T
hal_l3_getMyRouterMac(
    const UI32_T                    unit,
    const UI32_T                    index,
    CLX_L3_ROUTER_MAC_INFO_T        *ptr_router_mac_info);

/* VRRP-MAC */
CLX_ERROR_NO_T
hal_l3_addVrrp(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

CLX_ERROR_NO_T
hal_l3_delVrrp(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

CLX_ERROR_NO_T
hal_l3_getVrrp(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

/* BFD */
CLX_ERROR_NO_T
hal_l3_setBfdInfo(
    const UI32_T                unit,
    const CLX_L3_BFD_INFO_T     *ptr_bfd_info);

CLX_ERROR_NO_T
hal_l3_getBfdInfo(
    const UI32_T                unit,
    CLX_L3_BFD_INFO_T           *ptr_bfd_info);

/* FRR-state */
CLX_ERROR_NO_T
hal_l3_createFrrStateId(
    const UI32_T                unit,
    const CLX_L3_OUTPUT_TYPE_T  type,
    UI32_T                      *ptr_state_id);

CLX_ERROR_NO_T
hal_l3_destroyFrrStateId(
    const UI32_T                unit,
    const CLX_L3_OUTPUT_TYPE_T  type,
    const UI32_T                state_id);

CLX_ERROR_NO_T
hal_l3_setFrrState(
    const UI32_T                unit,
    const CLX_L3_OUTPUT_TYPE_T  type,
    const UI32_T                state_id,
    const BOOL_T                link_up);
CLX_ERROR_NO_T
hal_l3_getFrrState(
    const UI32_T                unit,
    const CLX_L3_OUTPUT_TYPE_T  type,
    const UI32_T                state_id,
    BOOL_T                      *ptr_link_up);

/* Dump SWDB */
CLX_ERROR_NO_T
hal_l3_dumpSwdb(
    const UI32_T    unit,
    const UI32_T    flags);

/* ----------------------------------------------------------------------------------- INTF */
CLX_ERROR_NO_T
hal_l3_intf_init(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_intf_deinit(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_intf_getRsrc(
    const UI32_T                unit,
    const UI32_T                intf_id,
    HAL_L3_INTF_RSRC_T          *ptr_intf_rsrc);

CLX_ERROR_NO_T
hal_l3_intf_fdid2intf(
    const UI32_T                unit,
    const CLX_BRIDGE_DOMAIN_T   bdid,
    UI32_T                      *ptr_intf_id);

CLX_ERROR_NO_T
hal_l3_intf_intf2fdid(
    const UI32_T                unit,
    const UI32_T                intf_id,
    CLX_BRIDGE_DOMAIN_T         *ptr_bdid);

CLX_ERROR_NO_T
hal_l3_intf_getIntf_ext(
    const UI32_T            unit,
    const UI32_T            intf_id,
    CLX_L3_INTF_INFO_T      *ptr_l3_intf);

CLX_ERROR_NO_T
hal_l3_intf_addIntf_ext(
    const UI32_T            unit,
    const UI32_T            intf_id,
    CLX_L3_INTF_INFO_T      *ptr_l3_intf);

CLX_ERROR_NO_T
hal_l3_intf_getcb_ext(
    const UI32_T            unit,
    HAL_L3_INTF_CB_T        **ptr_intf_cb);

/* CLX API */
CLX_ERROR_NO_T
hal_l3_intf_addIntf(
    const UI32_T                unit,
    const CLX_BRIDGE_DOMAIN_T   bdid,
    CLX_L3_INTF_INFO_T          *ptr_l3_intf);

CLX_ERROR_NO_T
hal_l3_intf_delIntf(
    const UI32_T                unit,
    const CLX_BRIDGE_DOMAIN_T   bdid);

CLX_ERROR_NO_T
hal_l3_intf_getIntf(
    const UI32_T                unit,
    const CLX_BRIDGE_DOMAIN_T   bdid,
    CLX_L3_INTF_INFO_T          *ptr_l3_intf);

CLX_ERROR_NO_T
hal_l3_intf_traverseIntf(
    const UI32_T                        unit,
    const CLX_L3_INTF_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_l3_intf_getUsage(
    const UI32_T                unit,
    UI32_T                      *ptr_cnt);

CLX_ERROR_NO_T
hal_l3_intf_dumpSwdb(
    const UI32_T    unit);

/* ----------------------------------------------------------------------------------- VRF */
CLX_ERROR_NO_T
hal_l3_vrf_init(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_vrf_deinit(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_vrf_addDfltRoute(
    const UI32_T                unit,
    const CLX_L3_ROUTE_INFO_T   *ptr_route_info);

CLX_ERROR_NO_T
hal_l3_vrf_delDfltRoute(
    const UI32_T                unit,
    const CLX_L3_ROUTE_INFO_T   *ptr_route_info);

CLX_ERROR_NO_T
hal_l3_vrf_getDfltRoute(
    const UI32_T                unit,
    CLX_L3_ROUTE_INFO_T         *ptr_route_info);

CLX_ERROR_NO_T
hal_l3_vrf_travDfltRoute(
    const UI32_T                unit,
    CMLIB_LIST_T                *ptr_list);

/* SWC property */
CLX_ERROR_NO_T
hal_l3_vrf_setGlobalRouteMissAction(
    const UI32_T                unit,
    const UI32_T                action);

CLX_ERROR_NO_T
hal_l3_vrf_getGlobalRouteMissAction(
    const UI32_T                unit,
    UI32_T                      *ptr_action);

CLX_ERROR_NO_T
hal_l3_vrf_getcb_ext(
    const UI32_T            unit,
    HAL_L3_VRF_CB_T         **ptr_vrf_cb);

/* CLX API */
CLX_ERROR_NO_T
hal_l3_vrf_setVrf(
    const UI32_T                unit,
    const UI32_T                vrf_id,
    const CLX_L3_VRF_INFO_T     *ptr_vrf_info);

CLX_ERROR_NO_T
hal_l3_vrf_getVrf(
    const UI32_T                unit,
    const UI32_T                vrf_id,
    CLX_L3_VRF_INFO_T           *ptr_vrf_info);

CLX_ERROR_NO_T
hal_l3_vrf_dumpSwdb(
    const UI32_T    unit);

/* ----------------------------------------------------------------------------------- ADJ */
CLX_ERROR_NO_T
hal_l3_adj_init(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_adj_deinit(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_adj_getAdjInfo(
    const UI32_T                unit,
    const UI32_T                adj_id,
    HAL_L3_ADJ_INFO_T           *ptr_adj_info);

CLX_ERROR_NO_T
hal_l3_adj_updateAdjUseNum(
    const UI32_T                unit,
    const UI32_T                adj_id,
    const BOOL_T                inc);

/* handle URPF */
CLX_ERROR_NO_T
hal_l3_adj_addEcmpGrpUrpf( /* for addEcmpPath */
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const UI32_T                intf_id);

CLX_ERROR_NO_T
hal_l3_adj_addFrrGrpUrpf( /* for addFrrPath, setFrrPath */
    const UI32_T                unit,
    const UI32_T                frr_grp_id,
    const UI32_T                intf_id);

CLX_ERROR_NO_T
hal_l3_adj_delEcmpGrpUrpf( /* for delEcmp, delEcmpPath */
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const UI32_T                intf_id);

CLX_ERROR_NO_T
hal_l3_adj_delFrrGrpUrpf( /* for delFrrPath, setEcmpPath */
    const UI32_T                unit,
    const UI32_T                frr_grp_id,
    const UI32_T                intf_id);

CLX_ERROR_NO_T
hal_l3_adj_travGrpUpdateUrpf( /* for setIntf, delIntf */
    const UI32_T                unit,
    const UI32_T                is_add,
    const UI32_T                intf_id);

/* handle FRR or ECMP List */
CLX_ERROR_NO_T
hal_l3_adj_addEcmpGrpIdToList( /* for addEcmpPath */
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const UI32_T                adj_id);

CLX_ERROR_NO_T
hal_l3_adj_delEcmpGrpIdFromList( /* for delEcmp, delEcmpPath */
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const UI32_T                adj_id);

CLX_ERROR_NO_T
hal_l3_adj_addFrrGrpIdToList( /* for addFrrPath, setFrrPath */
    const UI32_T                unit,
    const UI32_T                frr_grp_id,
    const UI32_T                adj_id);

CLX_ERROR_NO_T
hal_l3_adj_delFrrGrpIdFromList( /* for delFrrPath, setFrrPath */
    const UI32_T                unit,
    const UI32_T                frr_grp_id,
    const UI32_T                adj_id);
CLX_ERROR_NO_T
hal_l3_adj_addGrpList( /* for addEcmpPath, addNvo3EcmpPath, addFrrPath, setFrrPath */
    const UI32_T                grp_id,
    CMLIB_LIST_T                *ptr_list);

CLX_ERROR_NO_T
hal_l3_adj_delGrpList( /* for delEcmp, delNvo3Ecmp, delEcmpPath, delNvo3EcmpPath, delFrrPath, setFrrPath */
    const UI32_T                grp_id,
    CMLIB_LIST_T                *ptr_list);

/* traverse ECMP, nvo3-ECMP or FRR group-list by adj-id */
CLX_ERROR_NO_T
hal_l3_adj_travGrpList( /* for setAdj, setNvo3Adj */
    const UI32_T                unit,
    CMLIB_LIST_T                *ptr_list,
    const UI32_T                adj_id,
    void                        *ptr_cookie,
    HAL_L3_FRR_CALLBACK_FUNC_T  callback);

/* CLX API */
CLX_ERROR_NO_T
hal_l3_adj_addAdj(
    const UI32_T                unit,
    const CLX_L3_ADJ_INFO_T     *ptr_adj_info,
    UI32_T                      *ptr_adj_id);

CLX_ERROR_NO_T
hal_l3_adj_delAdj(
    const UI32_T                unit,
    const CLX_L3_ADJ_TYPE_T     adj_type,
    const UI32_T                adj_id);

CLX_ERROR_NO_T
hal_l3_adj_getAdj(
    const UI32_T                unit,
    const UI32_T                adj_id,
    CLX_L3_ADJ_INFO_T           *ptr_adj_info);

CLX_ERROR_NO_T
hal_l3_adj_traverseAdj(
    const UI32_T                        unit,
    const CLX_L3_ADJ_TYPE_T             adj_type,
    const CLX_L3_ADJ_TRAVERSE_FUNC_T    callback,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_l3_adj_getUsage(
    const UI32_T                unit,
    UI32_T                      *ptr_cnt);

CLX_ERROR_NO_T
hal_l3_adj_dumpSwdb(
    const UI32_T    unit);

/* ----------------------------------------------------------------------------------- ECMP */
CLX_ERROR_NO_T
hal_l3_ecmp_init(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_ecmp_deinit(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_ecmp_getEcmpInfo(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    HAL_L3_ECMP_INFO_T          *ptr_ecmp_info);

CLX_ERROR_NO_T
hal_l3_ecmp_updateEcmpUseNum(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const BOOL_T                inc);

/* set physical ECMP path by grp-id and adj-id */
CLX_ERROR_NO_T
hal_l3_ecmp_setAdjEcmpList( /* for setAdj */
    const UI32_T                unit,
    const UI32_T                adj_id,
    const UI32_T                ecmp_grp_id,
    const void                  *ptr_cookie);

/* get physical ECMP path index by grp-id and adj-id */
CLX_ERROR_NO_T
hal_l3_ecmp_getPathIdxByGrpAdjId( /* for setAdj, setNvo3Adj */
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const CLX_L3_OUTPUT_TYPE_T  output_type,
    const UI32_T                adj_id,
    UI32_T                      *ptr_act_idx,
    UI32_T                      *ptr_act_cnt,
    UI32_T                      *ptr_orig_idx,
    UI32_T                      *ptr_orig_cnt);

/* CLX API */
CLX_ERROR_NO_T
hal_l3_ecmp_createEcmpGrp(
    const UI32_T                    unit,
    const CLX_L3_ECMP_GRP_INFO_T    *ptr_ecmp_grp_info,
    UI32_T                          *ptr_ecmp_grp_id);
CLX_ERROR_NO_T
hal_l3_ecmp_setEcmpGrp(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_GRP_INFO_T    *ptr_ecmp_grp_info);

CLX_ERROR_NO_T
hal_l3_ecmp_delEcmpGrp(
    const UI32_T                    unit,
    const CLX_L3_OUTPUT_TYPE_T      type,
    const UI32_T                    ecmp_grp_id);

CLX_ERROR_NO_T
hal_l3_ecmp_getEcmpGrp(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    CLX_L3_ECMP_GRP_INFO_T          *ptr_ecmp_grp_info);

CLX_ERROR_NO_T
hal_l3_ecmp_traverseEcmpGrp(
    const UI32_T                            unit,
    const CLX_L3_OUTPUT_TYPE_T              type,
    const CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T   callback,
    void                                    *ptr_cookie);

CLX_ERROR_NO_T
hal_l3_ecmp_addEcmpGrpPath(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info);

CLX_ERROR_NO_T
hal_l3_ecmp_delEcmpGrpPath(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info);

CLX_ERROR_NO_T
hal_l3_ecmp_getEcmpGrpPathByIdx(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const UI32_T                    path_idx,
    CLX_L3_ECMP_PATH_INFO_T         *ptr_ecmp_path_info);

CLX_ERROR_NO_T
hal_l3_ecmp_setEcmpGrpHashPath(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const UI32_T                    *ptr_hash_val_list,
    const UI32_T                    hash_val_cnt,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info);

CLX_ERROR_NO_T
hal_l3_ecmp_getEcmpGrpHashPath(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const UI32_T                    hash_val_cnt,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info,
    UI32_T                          *ptr_hash_val_list,
    UI32_T                          *ptr_actual_hash_val_cnt);

CLX_ERROR_NO_T
hal_l3_ecmp_addFdlEcmpGroup(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const CLX_FDL_INFO_T        *ptr_fdl_info);

CLX_ERROR_NO_T
hal_l3_ecmp_delFdlEcmpGroup(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id);

CLX_ERROR_NO_T
hal_l3_ecmp_getFdlEcmpGroup(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    CLX_FDL_INFO_T              *ptr_fdl_info);

CLX_ERROR_NO_T
hal_l3_ecmp_getUsageGrp(
    const UI32_T                unit,
    UI32_T                      *ptr_cnt);

CLX_ERROR_NO_T
hal_l3_ecmp_getUsagePath(
    const UI32_T                unit,
    UI32_T                      *ptr_cnt);

CLX_ERROR_NO_T
hal_l3_ecmp_getUsageHash(
    const UI32_T                unit,
    UI32_T                      *ptr_cnt);

CLX_ERROR_NO_T
hal_l3_ecmp_setBlockSize(
    const UI32_T                unit,
    const UI32_T                size);

CLX_ERROR_NO_T
hal_l3_ecmp_getBlockSize(
    const UI32_T                unit,
    UI32_T                      *ptr_size);

CLX_ERROR_NO_T
hal_l3_ecmp_dumpSwdb(
    const UI32_T    unit);

/* ----------------------------------------------------------------------------------- HOST */
CLX_ERROR_NO_T
hal_l3_host_init(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_host_deinit(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

/* CLX API */
CLX_ERROR_NO_T
hal_l3_host_addHost(
    const UI32_T                unit,
    const CLX_L3_HOST_INFO_T    *ptr_host_info);

CLX_ERROR_NO_T
hal_l3_host_delHost(
    const UI32_T                unit,
    const CLX_L3_HOST_INFO_T    *ptr_host_info);

CLX_ERROR_NO_T
hal_l3_host_getHost(
    const UI32_T                unit,
    CLX_L3_HOST_INFO_T          *ptr_host_info);

CLX_ERROR_NO_T
hal_l3_host_traverseHost(
    const UI32_T                        unit,
    const CLX_L3_HOST_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_l3_host_addSubnetBcast(
    const UI32_T                        unit,
    const CLX_L3_SUBNET_BCAST_INFO_T    *ptr_subnet_info);

CLX_ERROR_NO_T
hal_l3_host_delSubnetBcast(
    const UI32_T                        unit,
    const CLX_L3_SUBNET_BCAST_INFO_T    *ptr_subnet_info);

CLX_ERROR_NO_T
hal_l3_host_getSubnetBcast(
    const UI32_T                        unit,
    CLX_L3_SUBNET_BCAST_INFO_T          *ptr_subnet_info);

CLX_ERROR_NO_T
hal_l3_host_getCapacity(
    const UI32_T                unit,
    const UI32_T                param,
    UI32_T                      *ptr_size);

CLX_ERROR_NO_T
hal_l3_host_getUsage(
    const UI32_T                unit,
    const UI32_T                param,
    UI32_T                      *ptr_cnt);

CLX_ERROR_NO_T
hal_l3_host_dumpSwdb(
    const UI32_T    unit);

/* ----------------------------------------------------------------------------------- ROUTE */
CLX_ERROR_NO_T
hal_l3_route_init(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_route_deinit(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_route_getIevRsrc(
    const UI32_T                unit,
    const CLX_L3_ROUTE_INFO_T   *ptr_route_info,
    HAL_L3_IEV_RSRC_T           *ptr_iev_rsrc);

/* FCoE */
CLX_ERROR_NO_T
hal_l3_route_addFcoeTcamEntry(
    const UI32_T                unit,
    const UI32_T                is_vrf,
    const UI32_T                intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T  *ptr_fcid_addr,
    const UI32_T                group_label,
    const UI32_T                iev_rslt_idx);

CLX_ERROR_NO_T
hal_l3_route_delFcoeTcamEntry(
    const UI32_T                unit,
    const UI32_T                is_vrf,
    const UI32_T                intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T  *ptr_fcid_addr);

CLX_ERROR_NO_T
hal_l3_route_getFcoeTcamEntry(
    const UI32_T                unit,
    const UI32_T                is_vrf,
    const UI32_T                intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T  *ptr_fcid_addr,
    UI32_T                      *ptr_group_label,
    UI32_T                      *ptr_iev_rslt_idx);

/* Mcast PIM register */
CLX_ERROR_NO_T
hal_l3_route_addIpMcTcamEntry(
    const UI32_T                unit,
    const CLX_L3_PIM_REG_INFO_T *ptr_info);

CLX_ERROR_NO_T
hal_l3_route_delIpMcTcamEntry(
    const UI32_T                unit,
    const CLX_L3_PIM_REG_INFO_T *ptr_info);

CLX_ERROR_NO_T
hal_l3_route_getIpMcTcamEntry(
    const UI32_T                unit,
    CLX_L3_PIM_REG_INFO_T       *ptr_info);

/* CLX API */
CLX_ERROR_NO_T
hal_l3_route_addRoute(
    const UI32_T                unit,
    const CLX_L3_ROUTE_INFO_T   *ptr_route_info);

CLX_ERROR_NO_T
hal_l3_route_delRoute(
    const UI32_T                unit,
    const CLX_L3_ROUTE_INFO_T   *ptr_route_info);

CLX_ERROR_NO_T
hal_l3_route_getRoute(
    const UI32_T                unit,
    CLX_L3_ROUTE_INFO_T         *ptr_route_info);

CLX_ERROR_NO_T
hal_l3_route_traverseRoute(
    const UI32_T                        unit,
    const CLX_L3_ROUTE_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_l3_route_getCapacity(
    const UI32_T                unit,
    const UI32_T                param,
    UI32_T                      *ptr_size);

CLX_ERROR_NO_T
hal_l3_route_getUsage(
    const UI32_T                unit,
    const UI32_T                param,
    UI32_T                      *ptr_cnt);

CLX_ERROR_NO_T
hal_l3_route_dumpSwdb(
    const UI32_T    unit);

/* ----------------------------------------------------------------------------------- MCAST */
CLX_ERROR_NO_T
hal_l3_mcast_init(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_l3_mcast_deinit(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

/* MEL for VEPA */
CLX_ERROR_NO_T
hal_l3_mcast_delMemberAll(
    const UI32_T    unit,
    const UI32_T    mcast_id);

CLX_ERROR_NO_T
hal_l3_mcast_addMelSubEntryByPort(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T  *ptr_sub_entry);

CLX_ERROR_NO_T
hal_l3_mcast_delMelSubEntryByPort (
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T  *ptr_sub_entry);

CLX_ERROR_NO_T
hal_l3_mcast_getMelSubEntryByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    const UI32_T                    entry_num,
    HAL_L3_MCAST_MEL_SUB_ENTRY_T    *ptr_sub_entry,
    UI32_T                          *ptr_actual_num);

CLX_ERROR_NO_T
hal_l3_mcast_getMelSubEntryNumByPort(
     const UI32_T                   unit,
     const UI32_T                   mcast_id,
     const UI32_T                   port_id,
     UI32_T                         *ptr_entry_num);

/* CLX API */
CLX_ERROR_NO_T
hal_l3_mcast_addId(
    const UI32_T                unit,
    const UI32_T                flags,
    UI32_T                      *ptr_mcast_id);

CLX_ERROR_NO_T
hal_l3_mcast_delId(
    const UI32_T                unit,
    const UI32_T                mcast_id);

CLX_ERROR_NO_T
hal_l3_mcast_getId(
    const UI32_T                unit,
    const UI32_T                mcast_id,
    UI32_T                      *ptr_flags,
    CLX_PORT_BITMAP_T           port_bitmap);

CLX_ERROR_NO_T
hal_l3_mcast_addEgrIntfByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    const UI32_T                    egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T   *ptr_egr_intf);

CLX_ERROR_NO_T
hal_l3_mcast_delEgrIntfByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    const UI32_T                    egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T   *ptr_egr_intf);

CLX_ERROR_NO_T
hal_l3_mcast_setEgrIntfByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    const UI32_T                    egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T   *ptr_egr_intf);

CLX_ERROR_NO_T
hal_l3_mcast_getEgrIntfByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    const UI32_T                    egr_intf_cnt,
    CLX_L3_MCAST_EGR_INTF_T         *ptr_egr_intf,
    UI32_T                          *ptr_actual_egr_intf_cnt);

CLX_ERROR_NO_T
hal_l3_mcast_getEgrIntfCntByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    UI32_T                          *ptr_egr_intf_cnt);

CLX_ERROR_NO_T
hal_l3_mcast_addGroup(
    const UI32_T                    unit,
    const CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

CLX_ERROR_NO_T
hal_l3_mcast_delGroup(
    const UI32_T                    unit,
    const CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

CLX_ERROR_NO_T
hal_l3_mcast_getGroup(
    const UI32_T                    unit,
    CLX_L3_MCAST_GROUP_INFO_T       *ptr_group_info);

CLX_ERROR_NO_T
hal_l3_mcast_traverseGroup(
    const UI32_T                                unit,
    const CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T    callback,
    void                                        *ptr_cookie);

CLX_ERROR_NO_T
hal_l3_mcast_addDfIntf(
    const UI32_T            unit,
    const UI32_T            intf_id,
    const CLX_IP_ADDR_T     *ptr_rp_addr);

CLX_ERROR_NO_T
hal_l3_mcast_delDfIntf(
    const UI32_T            unit,
    const UI32_T            intf_id,
    const CLX_IP_ADDR_T     *ptr_rp_addr);

CLX_ERROR_NO_T
hal_l3_mcast_getDfIntf(
    const UI32_T            unit,
    const UI32_T            intf_id,
    const UI32_T            rp_addr_cnt,
    UI32_T                  *ptr_actual_rp_addr_cnt,
    CLX_IP_ADDR_T           *ptr_rp_addr);

CLX_ERROR_NO_T
hal_l3_mcast_addSrcForPimReg(
    const UI32_T                    unit,
    const CLX_L3_PIM_REG_INFO_T     *ptr_info);

CLX_ERROR_NO_T
hal_l3_mcast_delSrcForPimReg(
    const UI32_T                    unit,
    const CLX_L3_PIM_REG_INFO_T     *ptr_info);

CLX_ERROR_NO_T
hal_l3_mcast_getSrcForPimReg(
    const UI32_T                    unit,
    CLX_L3_PIM_REG_INFO_T           *ptr_info);

CLX_ERROR_NO_T
hal_l3_mcast_dumpSwdb(
    const UI32_T    unit);

#endif  /* End of HAL_L3_H */
