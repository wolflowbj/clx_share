/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  diag.h
 * PURPOSE:
 *      1. It provides DIAG (Diagnosis) module internal API
 *      2. It provides debug console and buffer functionalities
 *
 * NOTES:
 *
 */

#ifndef DIAG_H
#define DIAG_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_module.h>
#include <hal/common/hal_tbl.h>
#include <cdb/cdb.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

extern UI32_T _ext_module_dbg_flag[CLX_MODULE_LAST];

#ifdef CLX_EN_DEBUG

#ifdef CLX_EN_COMPILER_SUPPORT_FUNCTION
#define DIAG_SET_MODULE_INFO(__module_id__, __file_name__) \
    static CLX_MODULE_T __CLX_MODULE__ = (__module_id__)

#define DIAG_PRINT(__flag__,...) do                                                                 \
{                                                                                                   \
    if (0 != ((HAL_DBG_ERR) & (__flag__)))                                                          \
    {                                                                                               \
        diag_printToInternalLog(__CLX_MODULE__,__flag__,__func__,__LINE__,##__VA_ARGS__);           \
    }                                                                                               \
    if (0 != ((__flag__) & (_ext_module_dbg_flag[__CLX_MODULE__])))                                 \
    {                                                                                               \
        diag_print(__CLX_MODULE__,__func__,__LINE__,##__VA_ARGS__);                                 \
        if (0 == ((HAL_DBG_ERR) & (__flag__)))                                                      \
        {                                                                                           \
            diag_printToInternalLog(__CLX_MODULE__,__flag__,__func__,__LINE__,##__VA_ARGS__);       \
        }                                                                                           \
    }                                                                                               \
}while (0)

#else /* !CLX_EN_COMPILER_SUPPORT_FUNCTION */
#define DIAG_SET_MODULE_INFO(__module_id__, __file_name__) \
    static CLX_MODULE_T __CLX_MODULE__ = (__module_id__); \
    static C8_T* __CLX_FILE__ = (__file_name__)

#define DIAG_PRINT(__flag__,...) do                                                                 \
{                                                                                                   \
    if (0 != ((HAL_DBG_ERR) & (__flag__)))                                                          \
    {                                                                                               \
        diag_printToInternalLog(__CLX_MODULE__,__flag__,__CLX_FILE__,__LINE__,##__VA_ARGS__);       \
    }                                                                                               \
    if (0 != ((__flag__) & (_ext_module_dbg_flag[__CLX_MODULE__])))                                 \
    {                                                                                               \
        diag_print(__CLX_MODULE__,__CLX_FILE__,__LINE__,##__VA_ARGS__);                             \
        if (0 == ((HAL_DBG_ERR) & (__flag__)))                                                      \
        {                                                                                           \
            diag_printToInternalLog(__CLX_MODULE__,__flag__,__CLX_FILE__,__LINE__,##__VA_ARGS__);   \
        }                                                                                           \
    }                                                                                               \
}while (0)

#endif /* #ifdef CLX_EN_COMPILER_SUPPORT_FUNCTION */

#define DIAG_PRINT_RAW(__flag__,...) do                                         \
{                                                                               \
    if (0 != ((__flag__) & (_ext_module_dbg_flag[__CLX_MODULE__])))             \
    {                                                                           \
        diag_print_raw(__CLX_MODULE__,##__VA_ARGS__);                           \
    }                                                                           \
}while (0)

#define DIAG_PRINT_HEX_BUF(__flag__,__ptr_buf__,__buf_size__) do                \
{                                                                               \
    if (0 != ((__flag__) & (_ext_module_dbg_flag[__CLX_MODULE__])))             \
    {                                                                           \
        diag_printHexBuf(__CLX_MODULE__,__ptr_buf__,__buf_size__);              \
    }                                                                           \
} while (0)


#define DIAG_PRINT_HEX_TBL(__flag__,__ptr_buf__,__buf_word_size__) do           \
{                                                                               \
    if (0 != ((__flag__) & (_ext_module_dbg_flag[__CLX_MODULE__])))             \
    {                                                                           \
        diag_printWideField(__CLX_MODULE__,__buf_word_size__,__ptr_buf__);      \
    }                                                                           \
} while (0)


#define DIAG_EN_TBL_TRACK
#ifdef DIAG_EN_TBL_TRACK

#define DIAG_PRINT_MULTI_FEILDS_INFO(__flag__,__unit__,__tbl_id__,__inst__,                 \
                               __subinst__,__entry__,__list__,__count__,__buf__) do         \
{                                                                                           \
    if (0 != ((__flag__) & (_ext_module_dbg_flag[__CLX_MODULE__])))                         \
    {                                                                                       \
        DIAG_PRINT(__flag__,"[C] %s inst=%u sub-inst=%u entry=%u:\n",                       \
            CDB_TABLE(__unit__,__tbl_id__)->ptr_table_name,__inst__,__subinst__,__entry__); \
        diag_printMultiFields(__CLX_MODULE__,__unit__,__tbl_id__,__list__,__count__);       \
        diag_printTblInfo(__CLX_MODULE__,__unit__,__tbl_id__,__buf__);                      \
    }                                                                                       \
}while (0)

#define DIAG_PRINT_SINGLE_FEILD_INFO(__flag__,__unit__,__tbl_id__, __inst__,                    \
                               __subinst__,__entry__,__value__,__fid__,__buf__) do              \
{                                                                                               \
    if (0 != ((__flag__) & (_ext_module_dbg_flag[__CLX_MODULE__])))                             \
    {                                                                                           \
        DIAG_PRINT(__flag__,"[C] %s inst=%u sub-inst=%u entry=%u:\n",                           \
            CDB_TABLE(__unit__,__tbl_id__)->ptr_table_name,__inst__,__subinst__,__entry__);     \
        diag_printSingleField(__CLX_MODULE__,__unit__,__tbl_id__,__value__,__fid__);            \
        diag_printTblInfo(__CLX_MODULE__,__unit__,__tbl_id__,__buf__);                          \
    }                                                                                           \
}while (0)

#define DIAG_PRINT_TBL_INFO(__flag__,__unit__,__tbl_id__,__inst__,                          \
                               __subinst__,__entry__,__buf__) do                            \
{                                                                                           \
    if (0 != ((__flag__) & (_ext_module_dbg_flag[__CLX_MODULE__])))                         \
    {                                                                                       \
        DIAG_PRINT(__flag__,"[C] %s inst=%u sub-inst=%u entry=%u:\n",                       \
            CDB_TABLE(__unit__,__tbl_id__)->ptr_table_name,__inst__,__subinst__,__entry__); \
        diag_printTblInfo(__CLX_MODULE__,__unit__,__tbl_id__,__buf__);                      \
    }                                                                                       \
}while (0)



#else /* !DIAG_EN_TBL_TRACK */
#define DIAG_PRINT_MULTI_FEILDS_INFO(...)
#define DIAG_PRINT_SINGLE_FEILD_INFO(...)
#define DIAG_PRINT_TBL_INFO(...)
#endif


#else /* !CLX_EN_DEBUG */
#define DIAG_SET_MODULE_INFO(__module_id__, __file_name__)
#define DIAG_PRINT(__flag__,...)
#define DIAG_PRINT_HEX_BUF(__flag__, __ptr_buf__, __buf_size__)
#define DIAG_PRINT_HEX_TBL(__flag__, __ptr_buf__, __buf_word_size__)
#define DIAG_PRINT_RAW(...)
#define DIAG_PRINT_MULTI_FEILDS_INFO(...)
#define DIAG_PRINT_SINGLE_FEILD_INFO(...)
#define DIAG_PRINT_TBL_INFO(...)

#endif /* #ifdef CLX_EN_DEBUG */

#define DIAG_BYTES_OF_WORD              (4)
#define DIAG_MAX_ENTRY_LEN              (MAX_ENTRY_SIZE)
#define DIAG_MAX_FIELD_LEN              (MAX_FIELD_SIZE)
#define DIAG_MAX_FIELD_NUM              (MAX_FIELD_NUM)
#define DIAG_PRINT_BUF_SIZE             (128)
#define DIAG_LOG_ENTRY_MAX_NUM          (4 * 1024)

/* DATA TYPE DECLARATIONS
 */
/* DIAG Table CLI Input Type selection */
typedef enum
{
    DIAG_INPUT_TYPE_NAME = 0,
    DIAG_INPUT_TYPE_ID,
    DIAG_INPUT_TYPE_RAW,
    DIAG_INPUT_TYPE_LAST
} DIAG_INPUT_TYPE_T;

/* DIAG Show cmd format option */
typedef enum
{
    DIAG_SHOW_CMD_FIELD_OPT_NORMAL = 0,
    DIAG_SHOW_CMD_FIELD_OPT_FILTER0,
    DIAG_SHOW_CMD_FIELD_OPT_RAW,
    DIAG_SHOW_CMD_FIELD_OPT_LAST
} DIAG_SHOW_CMD_FIELD_OPT_T;

typedef enum
{
    DIAG_SHOW_CMD_ENTRY_OPT_NORMAL = 0,
    DIAG_SHOW_CMD_ENTRY_OPT_FILTER0,
    DIAG_SHOW_CMD_ENTRY_OPT_LAST
} DIAG_SHOW_CMD_ENTRY_OPT_T;

typedef struct DIAG_FIELD_S
{
    UI32_T              field_id;
    UI32_T              data[DIAG_MAX_FIELD_LEN];
    UI32_T              mask[DIAG_MAX_FIELD_LEN];
    UI32_T              data_size;
    UI32_T              mask_size;
    BOOL_T              zero;
} DIAG_FIELD_T;

typedef struct DIAG_FIELDS_META_S
{
    UI32_T              valid_field_num;
    DIAG_FIELD_T        field_info[DIAG_MAX_FIELD_NUM];
    UI32_T              raw_data[DIAG_MAX_ENTRY_LEN];
    UI32_T              raw_mask[DIAG_MAX_ENTRY_LEN];
    BOOL_T              valid_entry;
    BOOL_T              allZero;
} DIAG_FIELDS_META_T;

typedef enum
{
    DIAG_SET_MODE_SET_ONLY = 0,
    DIAG_SET_MODE_VERIFY_ONLY,
    DIAG_SET_MODE_SET_AND_VERIFY,
    DIAG_SET_MODE_LAST
} DIAG_SET_MODE_T;

typedef struct DIAG_LOG_ENTRY_S
{
    OSAL_TM_T       timestamp;
    CLX_MODULE_T    module;
    UI32_T          dbg_level;
    C8_T            log[DIAG_PRINT_BUF_SIZE];
} DIAG_LOG_ENTRY_T;

typedef struct DIAG_LOG_CB_S
{
    UI32_T              inited;
    CLX_SEMAPHORE_ID_T  sema;
    BOOL_T              wrap_mode;
    UI32_T              nonwrap_count;
    UI32_T              entry_index;
    UI32_T              entry_count;
    DIAG_LOG_ENTRY_T    *ptr_entry;
} DIAG_LOG_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* FUNCTION NAME:   diag_init
 * PURPOSE:
 *      This function is used to initilize the dia module
 * INPUT:
 *      None
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
diag_init(
    void);

/* FUNCTION NAME:   diag_deinit
 * PURPOSE:
 *      This function is to used de-initilize the dia module
 * INPUT:
 *      None
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
diag_deinit(
    void);

/* FUNCTION NAME:   diag_setDebugFlag
 * PURPOSE:
 *      This function is used to enable/disable module's debug message recording
 * INPUT:
 *      module -- selected module item
 *      dbg_flag -- filter of selected module item
 *      is_enabled -- Enable or disable debug flag
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
diag_setDebugFlag(
    const CLX_MODULE_T          module,
    const UI32_T                dbg_flag,
    const BOOL_T                is_enabled);

/* FUNCTION NAME:   diag_getDebugFlag
 * PURPOSE:
 *      This function is used to get current debug message recording status
 * INPUT:
 *      module_id -- selected module item
 *      ptr_dbg_flag -- pointer to get the debug flag status
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
diag_getDebugFlag(
    const CLX_MODULE_T  module_id,
    UI32_T              *ptr_dbg_flag);

void
diag_print_raw(
    const CLX_MODULE_T  module,
    const C8_T          *ptr_fmt,
    ... );

void
diag_printWideField(
    const CLX_MODULE_T  module,
    const UI32_T        data_size_in_word,
    const UI32_T        *value_list);

void
diag_printTblInfo(
    const CLX_MODULE_T  module,
    const UI32_T        unit,
    const UI32_T        table_id,
    const UI32_T        *ptr_buf);

void
diag_printSingleField(
    const CLX_MODULE_T  module,
    const UI32_T        unit,
    const UI32_T        table_id,
    const UI32_T        *value_list,
    const UI32_T        field_id);

void
diag_printMultiFields(
    const CLX_MODULE_T  module,
    const UI32_T        unit,
    const UI32_T        table_id,
    const CDB_FVP_T     *value_list,
    const UI32_T        field_count);

/* FUNCTION NAME:   diag_print
 * PURPOSE:
 *      This function is used to output debug message to console or/and save to DIAG buffer
 * INPUT:
 *      module          -- selected module item
 *      ptr_func        -- function or file name string
 *      line            -- line number
 *      ptr_fmt         -- input string pointer
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 * NOTES:
 *      None
 */
void
diag_print(
    const CLX_MODULE_T  module,
    const C8_T          *ptr_func,
    const UI32_T        line,
    const C8_T          *ptr_fmt,
    ...);

/* FUNCTION NAME:   diag_printToInternalLog
 * PURPOSE:
 *      This function is used to output debug message into internal log
 * INPUT:
 *      module          -- selected module item
 *      dbg_level       -- debug level
 *      ptr_func        -- function or file name string
 *      line            -- line number
 *      ptr_fmt         -- input string pointer
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 * NOTES:
 *      None
 */
void
diag_printToInternalLog(
    const CLX_MODULE_T  module,
    const UI32_T        dbg_level,
    const C8_T          *ptr_func,
    const UI32_T        line,
    const C8_T          *ptr_fmt,
    ... );

/* FUNCTION NAME:   diag_getInternalLog
 * PURPOSE:
 *      This function is used to get internal log _diag_log_buf
 * INPUT:
 *      None
 * OUTPUT:
 *      ptr_entry_index    -- the curent index of internal log
 *      ptr_entry_count    -- the entry count of internal log
 *      ptr_entry          -- the snapshot of all internal logs
 * RETURN:
 *      None
 * NOTES:
 *      None
 */
void
diag_getInternalLog(
    UI32_T              *ptr_entry_index,
    UI32_T              *ptr_entry_count,
    DIAG_LOG_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   diag_clearInternalLog
 * PURPOSE:
 *      This function is used to clear all internal log
 * INPUT:
 *      None
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 * NOTES:
 *      None
 */
void
diag_clearInternalLog(void);

/* FUNCTION NAME:   diag_setInternalLogWrapMode
 * PURPOSE:
 *      This function is used to enable internal log mode to wrap mode or not
 * INPUT:
 *      wrap_mode_enable        -- enable wrap mode or not
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 * NOTES:
 *      None
 */
void
diag_setInternalLogWrapMode(
    const BOOL_T      wrap_mode_enable);

/* FUNCTION NAME:   diag_getInternalLogWrapMode
 * PURPOSE:
 *      This function is used to get internal log if wrap mode or not
 * INPUT:
 *      None
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 * NOTES:
 *      None
 */
void
diag_getInternalLogWrapMode(
    BOOL_T      *ptr_mode);

/* FUNCTION NAME:   diag_showMem
 * PURPOSE:
 *      Show table/reg by field data according to the DIAG_FIELDS_META_T
 *
 * INPUT:
 *      unit                -- unit index
 *      inst_idx            -- instance index
 *      sub_inst_idx        -- sub instance index
 *      entry_idx           -- entry index
 *      tbl_id              -- table index
 *      ptr_field_meta      -- pointer of  DIAG_FIELDS_META_T
 *                             to indicate which field shoud be shown
 *      opt                 -- show option
 *
 * OUTPUT:
 *      none
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_OTHERS        -- Operate failed.
 *
 * NOTES:
 *     none
 */
CLX_ERROR_NO_T
diag_showMem(
    UI32_T                      unit,
    UI32_T                      inst_idx,
    UI32_T                      sub_inst_idx,
    UI32_T                      entry_idx,
    UI32_T                      tbl_id,
    DIAG_FIELDS_META_T          *ptr_diag_field_meta,
    DIAG_SHOW_CMD_FIELD_OPT_T   opt);


/* FUNCTION NAME:   diag_showTCAM
 * PURPOSE:
 *      Show TCAM by field data and mask according to the DIAG_FIELDS_META_T
 *
 * INPUT:
 *      unit                -- unit index
 *      inst_idx            -- instance index
 *      sub_inst_idx        -- sub instance index
 *      entry_idx           -- entry index
 *      tbl_id              -- table index
 *      ptr_field_meta      -- pointer of  DIAG_FIELDS_META_T
 *                             to indicate which field shoud be shown
 *      opt                 -- show option
 *
 * OUTPUT:
 *      none
 *
 * RETURN:
 *      CLX_E_OK            -- operate success
 *      CLX_E_OTHERS        -- operate failed
 *
 * NOTES:
 *     none
 */
CLX_ERROR_NO_T
diag_showTCAM(
    UI32_T                      unit,
    UI32_T                      inst_idx,
    UI32_T                      sub_inst_idx,
    UI32_T                      entry_idx,
    UI32_T                      tbl_id,
    DIAG_FIELDS_META_T          *ptr_diag_field_meta,
    DIAG_SHOW_CMD_FIELD_OPT_T   opt);

/* FUNCTION NAME:   diag_setMem
 * PURPOSE:
 *      set table/reg by field data and mask according to the DIAG_FIELDS_META_T
 *
 * INPUT:
 *      unit                -- unit index
 *      inst_idx            -- instance index
 *      sub_inst_idx        -- sub instance index
 *      entry_idx           -- entry index
 *      tbl_id              -- table index
 *      ptr_field_meta      -- pointer of DIAG_FIELDS_META_T
 *      mode                -- set mode
 *
 * OUTPUT:
 *      none
 *
 * RETURN:
 *      CLX_E_OK            -- operate success
 *      CLX_E_OTHERS        -- operate failed
 *
 * NOTES:
 *     none
 */
CLX_ERROR_NO_T
diag_setMem(
    UI32_T              unit,
    UI32_T              inst_idx,
    UI32_T              sub_inst_idx,
    UI32_T              entry_idx,
    UI32_T              tbl_id,
    DIAG_FIELDS_META_T  *ptr_field_meta,
    DIAG_SET_MODE_T     mode);

/* FUNCTION NAME:   diag_setMemOverwrite
 * PURPOSE:
 *      set table/reg by overwrite data
 *
 * INPUT:
 *      unit            -- unit index
 *      inst_idx        -- instance index
 *      sub_inst_idx    -- sub instance index
 *      entry_idx       -- entry index
 *      tbl_id          -- table index
 *      ptr_data        -- pointer of overwrite raw data buffer
 *      mode            -- set mode
 *
 * OUTPUT:
 *      none
 *
 * RETURN:
 *      CLX_E_OK        -- operate success
 *      CLX_E_OTHERS    -- operate failed
 *
 * NOTES:
 *     none
 */
CLX_ERROR_NO_T
diag_setMemOverwrite(
    UI32_T              unit,
    UI32_T              inst_idx,
    UI32_T              sub_inst_idx,
    UI32_T              entry_idx,
    UI32_T              tbl_id,
    UI32_T              *ptr_data,
    DIAG_SET_MODE_T     mode);

/* FUNCTION NAME:   diag_setTCAM
 * PURPOSE:
 *      set tcam by field data and mask according to the DIAG_FIELDS_META_T
 *
 * INPUT:
 *      unit                -- unit index
 *      inst_idx            -- instance index
 *      sub_inst_idx        -- sub instance index
 *      entry_idx           -- entry index
 *      tbl_id              -- table index
 *      ptr_field_meta      -- pointer of  DIAG_FIELDS_META_T
 *      mode                -- set mode
 *
 * OUTPUT:
 *      none
 *
 * RETURN:
 *      CLX_E_OK            -- operate success
 *      CLX_E_OTHERS        -- operate failed
 *
 * NOTES:
 *     none
 */
CLX_ERROR_NO_T
diag_setTCAM(
    UI32_T              unit,
    UI32_T              inst_idx,
    UI32_T              sub_inst_idx,
    UI32_T              entry_idx,
    UI32_T              tbl_id,
    DIAG_FIELDS_META_T  *ptr_field_meta,
    DIAG_SET_MODE_T     mode);

/* FUNCTION NAME:   diag_setTcamOverwrite
 * PURPOSE:
 *      set tcam by overwrite data
 *
 * INPUT:
 *      unit            -- unit index
 *      inst_idx        -- instance index
 *      sub_inst_idx    -- sub instance index
 *      entry_idx       -- entry index
 *      tbl_id          -- table index
 *      ptr_data        -- pointer of overwrite raw mask buffer
 *      ptr_mask        -- pointer of overwrite raw data buffer
 *      mode            -- set mode
 *
 * OUTPUT:
 *      none
 *
 * RETURN:
 *      CLX_E_OK        -- operate success
 *      CLX_E_OTHERS    -- operate failed
 *
 * NOTES:
 *     none
 */
CLX_ERROR_NO_T
diag_setTcamOverwrite(
    UI32_T              unit,
    UI32_T              inst_idx,
    UI32_T              sub_inst_idx,
    UI32_T              entry_idx,
    UI32_T              tbl_id,
    UI32_T              *ptr_data,
    UI32_T              *ptr_mask,
    DIAG_SET_MODE_T     mode);

/* FUNCTION NAME:   diag_addHash
 * PURPOSE:
 *      Add hash by field data according to the DIAG_FIELDS_META_T
 *
 * INPUT:
 *      unit                -- unit index
 *      inst_idx            -- instance index
 *      sub_inst_idx        -- sub instance index
 *      entry_idx           -- entry index
 *      tbl_id              -- table index
 *      ptr_diag_field_meta -- pointer of DIAG_FIELDS_META_T
 *
 * OUTPUT:
 *      ptr_entry_idx       -- added entry idx
 *
 * RETURN:
 *      CLX_E_OK            -- operate success
 *      CLX_E_OTHERS        -- operate failed
 *
 * NOTES:
 *     none
 */
CLX_ERROR_NO_T
diag_addHash(
    UI32_T              unit,
    UI32_T              inst_idx,
    UI32_T              sub_inst_idx,
    UI32_T              bank_bmp,
    UI32_T              tbl_id,
    DIAG_FIELDS_META_T  *ptr_diag_field_meta,
    UI32_T              *ptr_entry_idx);

/* FUNCTION NAME:   diag_delHash
 * PURPOSE:
 *      Delete hash by field data according to the DIAG_FIELDS_META_T
 *
 * INPUT:
 *      unit                -- unit index
 *      inst_idx            -- instance index
 *      sub_inst_idx        -- sub instance index
 *      entry_idx           -- entry index
 *      tbl_id              -- table index
 *      ptr_diag_field_meta -- pointer of DIAG_FIELDS_META_T
 *
 * OUTPUT:
 *      ptr_entry_idx       -- deleted entry index
 *
 * RETURN:
 *      CLX_E_OK            -- operate success
 *      CLX_E_OTHERS        -- operate failed
 *
 * NOTES:
 *     none
 */
CLX_ERROR_NO_T
diag_delHash(
    UI32_T              unit,
    UI32_T              inst_idx,
    UI32_T              sub_inst_idx,
    UI32_T              bank_bmp,
    UI32_T              tbl_id,
    DIAG_FIELDS_META_T  *ptr_diag_field_meta,
    UI32_T              *ptr_entry_idx);

/* FUNCTION NAME:   diag_lookupHash
 * PURPOSE:
 *      Lookup hash by field data according to the DIAG_FIELDS_META_T
 *
 * INPUT:
 *      unit                -- unit index
 *      inst_idx            -- instance index
 *      sub_inst_idx        -- sub instance index
 *      entry_idx           -- entry index
 *      tbl_id              -- table index
 *      ptr_diag_field_meta -- pointer of DIAG_FIELDS_META_T
 *
 * OUTPUT:
 *      ptr_entry_idx       -- lookup result
 *
 * RETURN:
 *      CLX_E_OK            -- operate success
 *      CLX_E_OTHERS        -- operate failed
 *
 * NOTES:
 *     none
 */
CLX_ERROR_NO_T
diag_lookupHash(
    UI32_T              unit,
    UI32_T              inst_idx,
    UI32_T              sub_inst_idx,
    UI32_T              bank_bmp,
    UI32_T              tbl_id,
    DIAG_FIELDS_META_T  *ptr_diag_field_meta,
    UI32_T              *ptr_entry_idx);

/* FUNCTION NAME:   diag_printHexBuf
 * PURPOSE:
 *      print buf in hex style
 *
 * INPUT:
 *      module          -- selected module item
 *      buf             -- data buf
 *      buf_size        -- print size
 *
 * OUTPUT:
 *      none
 *
 * RETURN:
 *      CLX_E_OK        -- operate success
 *      CLX_E_OTHERS    -- operate failed
 *
 * NOTES:
 *     none
 */
void
diag_printHexBuf(
    const CLX_MODULE_T  module,
    const UI8_T         *ptr_buf,
    const UI32_T        buf_size);

#endif  /* End of DIAG_H */
