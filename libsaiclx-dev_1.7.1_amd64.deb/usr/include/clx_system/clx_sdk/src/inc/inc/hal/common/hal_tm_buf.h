/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_tm_buf.h
 * PURPOSE:
 *      It provides hal traffic management module API.
 * NOTES:
 *
 *
 */

#ifndef HAL_TM_BUF_H
#define HAL_TM_BUF_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */


#define HAL_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_GREEN             (32)
#define HAL_MAX_NUM_OF_TM_DCTCP_THD_G_PROFILE                       (32)

#define HAL_TM_WRED_PROFILE_SW_NUM          (HAL_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_GREEN)

#define HAL_TM_DCTCP_PROFILE_SW_NUM         (HAL_MAX_NUM_OF_TM_DCTCP_THD_G_PROFILE)

#define HAL_TM_BUF_BANK_LENGTH 32

typedef enum
{
    HAL_TM_ADM_SC_TYPE_LOSSY    = 0x0,
    HAL_TM_ADM_SC_TYPE_LOSSLESS = 0x2,
    HAL_TM_ADM_SC_TYPE_CTRL     = 0x3,
    HAL_TM_ADM_SC_TYPE_LAST
} HAL_TM_ADM_SC_TYPE_T;


/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_TM_BMM_LOCK(unit)                        (hal_tm_buf_lockBufferResource(unit))
#define HAL_TM_BMM_UNLOCK(unit)                      (hal_tm_buf_unLockBufferResource(unit))

#define HAL_TM_HANDLER_ID_GET(handler, id) do {                   \
        (id) = ((handler) & ((1U << HAL_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while(0)


/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_TM_BUF_RELEASE_NONE           = 0,
    HAL_TM_BUF_RELEASE_SEMAPHORE      = (1U << 0),
    HAL_TM_BUF_RELEASE_RESOURCE_1     = (1U << 1),
    HAL_TM_BUF_RELEASE_RESOURCE_2     = (1U << 2),
    HAL_TM_BUF_RELEASE_LAST           = (1U << 3)
} HAL_TM_BUF_RELEASE_ACTION_T;

/* TM Flow Control Mode*/
typedef enum {
    HAL_TM_FC_DISABLE = 0,          /* lossy mode.                              */
    HAL_TM_FC_802_3X,               /* lossless mode & 802.3X flow control.     */
    HAL_TM_FC_PFC,                  /* lossless mode & priority flow control.   */
    HAL_TM_FC_LAST
} HAL_TM_FC_T;

/* TM port resource reallocated with status*/
typedef enum {
    HAL_TM_PS_ACTIVED = 0,              /* port resource allocated when port actived*/
    HAL_TM_PS_NO_ACTIVED,               /* port resource reallocated wehn port actived*/
    HAL_TM_PS_LAST
} HAL_TM_SC_T;


typedef struct HAL_TM_WRED_PROFILE_SW_ENTRY_S {
    BOOL_T is_valid;                /* set to TRUE when create this profile,
                                     * set to FALSE when destroy this profile
                                     */
} HAL_TM_WRED_PROFILE_SW_ENTRY_T;

typedef struct HAL_TM_DCTCP_PROFILE_SW_ENTRY_S {
    BOOL_T is_valid;                /* set to TRUE when create this profile,
                                     * set to FALSE when destroy this profile
                                     */
} HAL_TM_DCTCP_PROFILE_SW_ENTRY_T;

typedef struct HAL_TM_BUF_CB_S
{
    HAL_TM_WRED_PROFILE_SW_ENTRY_T       *ptr_sw_wred_profile;
    HAL_TM_DCTCP_PROFILE_SW_ENTRY_T      *ptr_sw_dctcp_profile;
    UI32_T bank_bmp[HAL_BIN_NUM];
    CLX_SEMAPHORE_ID_T  buf_sema;

} HAL_TM_BUF_CB_T;






/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_tm_buf_dumpBankDb(
    const UI32_T        unit);

CLX_ERROR_NO_T
hal_tm_buf_dumpWredDb(
    const UI32_T        unit);

CLX_ERROR_NO_T
hal_tm_buf_dumpDctcpDb(
    const UI32_T        unit);

/* FUNCTION NAME: hal_tm_lockBufferResource
 * PURPOSE:
 *      The function is used to lock buffer resource
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_tm_buf_lockBufferResource(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_tm_unLockBufferResource
 * PURPOSE:
 *      The function is used to unlock buffer resource
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_tm_buf_unLockBufferResource(
    const UI32_T                            unit);

extern CLX_ERROR_NO_T
hal_tm_getBufferCtrlBlock(
    const UI32_T                            unit,
    HAL_TM_BUF_CB_T                  **ptr_cb);

/* FUNCTION NAME: hal_tm_buf_initRsrc
 * PURPOSE:
 *      The function is used to init TM buffer management HW & SW DB
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_tm_buf_initRsrc(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_tm_buf_deinitRsrc
 * PURPOSE:
 *      The function is used to deinit TM buffer management HW & SW DB
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_tm_buf_deinitRsrc(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_tm_buf_deinitCfg
 * PURPOSE:
 *      The function is used to deinit TM buffer management configuration
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_tm_buf_deinitCfg(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_tm_buf_initThread
 * PURPOSE:
 *      The function is used to init TM buffer management Thread
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_tm_buf_initThread(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_tm_buf_deinitThread
 * PURPOSE:
 *      The function is used to deinit TM buffer management Thread
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_tm_buf_deinitThread(
    const UI32_T                            unit);



#endif /*end of HAL_TM_BUF_H*/
