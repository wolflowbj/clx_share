/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  HAL_LAG.h
 * PURPOSE:
 *  Define the declartion for LAG module.
 *
 * NOTES:
 *
 */

#ifndef HAL_LAG_H
#define HAL_LAG_H

/* NAMING CONSTANT DECLARATIONS
*/

#define HAL_LAG_GROUP_MAX_MEMBER_NUM    (256)
#define HAL_LAG_PORT_LIST_ENTRY_NUM     (1024)
#define HAL_LAG_MEMBER_PBM_WORD_NUM     ((HAL_PHY_PORT_NUM + 31) / 32)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_LAG_LOCK(unit)                                                                       \
    HAL_COMMON_LOCK_RESOURCE(&_ext_hal_lag_cb[(unit)].mutex_sema_id, CLX_SEMAPHORE_WAIT_FOREVER)

#define HAL_LAG_UNLOCK(unit)                                                                     \
    HAL_COMMON_FREE_RESOURCE(&_ext_hal_lag_cb[(unit)].mutex_sema_id)

/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_LAG_FDL_GRP_HSH_INFO_S
{
    UI32_T                      grp_id;
    UI32_T                      hsh_base;
    UI32_T                      hsh_use_num;
}HAL_LAG_FDL_GRP_HSH_INFO_T;

typedef struct HAL_LAG_CB_S
{
    UI32_T                      port_list_cont_entry_num_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    UI32_T                      port_list_alloc_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    CLX_SEMAPHORE_ID_T          mutex_sema_id;
    UI32_T                      *ptr_lag_sel_dma_buf_not_align;
    UI32_T                      *ptr_lag_sel_dma_buf;
    UI32_T                      fdl_grp[HAL_FDL_GROUP_NUM];         /* store lag id */
    /* use for add/del member when link up/down in di view */
    UI32_T                      sw_lag_member_pbm[HAL_LAG_PORT_NUM][HAL_LAG_MEMBER_PBM_WORD_NUM];
    UI32_T                      lag_member_auto_update;
    UI32_T                      lag_mc_resilient;
}HAL_LAG_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   hal_lag_init
 * PURPOSE:
 *     Init LAG module.
 * INPUT:
 *      unit -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_NO_MEMORY -- No memory.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_init(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_lag_deinit
 * PURPOSE:
 *     De-init LAG module.
 * INPUT:
 *      unit -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_deinit(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_lag_createPort
 * PURPOSE:
 *      This API is used to create LAG port.
 * INPUT:
 *      unit -- Device unit number
 *      lag_id -- IEEE802.1AX link aggregation ID
 * OUTPUT:
 *      ptr_lag_port -- The pointer of the LAG port
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS -- Entry exists.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_createPort(
    const UI32_T    unit,
    const UI32_T    lag_id,
    CLX_PORT_T      *ptr_lag_port);

/* FUNCTION NAME:   hal_lag_destroyPort
 * PURPOSE:
 *      This API is used to destroy LAG port.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- Entry not found.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_destroyPort(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port);

/* FUNCTION NAME:   hal_lag_setMember
 * PURPOSE:
 *      This API is used to set LAG member.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 *      member_cnt -- Member port count
 *      ptr_member -- Member port list
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_setMember(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    const UI32_T        member_cnt,
    const CLX_PORT_T    *ptr_member);

/* FUNCTION NAME:   hal_lag_getMember
 * PURPOSE:
 *      This API is used to get LAG member.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 *      member_cnt -- Get member port count
 * OUTPUT:
 *      ptr_member -- Member port list
 *      ptr_actual_member_cnt -- Actual member port count
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_getMember(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    const UI32_T        member_cnt,
    CLX_PORT_T          *ptr_member,
    UI32_T              *ptr_actual_member_cnt);

/* FUNCTION NAME:   hal_lag_getMemberCnt
 * PURPOSE:
 *      This API is used to get LAG member count.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 * OUTPUT:
 *      ptr_member_cnt -- Member port count
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_getMemberCnt(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    UI32_T              *ptr_member_cnt);

/* FUNCTION NAME: hal_lag_traversePort
 * PURPOSE:
 *      The API is used to traverse LAG.
 * INPUT:
 *      unit                -- Device unit number
 *      callback            -- The callback function of type CLX_LAG_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
hal_lag_traversePort(
    const UI32_T                     unit,
    const CLX_LAG_TRAVERSE_FUNC_T    callback,
    void                             *ptr_cookie);

/* FUNCTION NAME:   hal_lag_getRange
 * PURPOSE:
 *      This API is used to get LAG range.
 * INPUT:
 *      unit -- Device unit number
 * OUTPUT:
 *      ptr_range -- LAG range information
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_getRange(
    const UI32_T        unit,
    CLX_RANGE_INFO_T    *ptr_range);

/* FUNCTION NAME:   hal_lag_getPort
 * PURPOSE:
 *      This API is used to get LAG port from LAG ID.
 * INPUT:
 *      unit -- Device unit number
 *      lag_id -- IEEE802.1AX link aggregation ID
 * OUTPUT:
 *      ptr_lag_port -- The pointer of the LAG port
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_getPort(
    const UI32_T    unit,
    const UI32_T    lag_id,
    CLX_PORT_T      *ptr_lag_port);

/* FUNCTION NAME:   hal_lag_getKey
 * PURPOSE:
 *      This API is used to get LAG ID from LAG port.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 * OUTPUT:
 *      ptr_lag_id -- The pointer of the LAG Id
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lag_getKey(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    UI32_T              *ptr_lag_id);

CLX_ERROR_NO_T
hal_lag_getSrcSuppTag(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    UI32_T              *ptr_value);

CLX_ERROR_NO_T
hal_lag_getCapacity(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_size);

CLX_ERROR_NO_T
hal_lag_getUsage(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_cnt);

CLX_ERROR_NO_T
hal_lag_allocPortlistIdx(
    const UI32_T    unit,
    const UI32_T    alloc_num,
    UI32_T          *ptr_alloc_idx);

CLX_ERROR_NO_T
hal_lag_freePortlistIdx(
    const UI32_T    unit,
    const UI32_T    free_idx);

CLX_ERROR_NO_T
hal_lag_addFdlGroup(
    const UI32_T                unit,
    const CLX_PORT_T            lag_port,
    const CLX_FDL_INFO_T        *ptr_fdl_info);

CLX_ERROR_NO_T
hal_lag_getFdlGroup(
    const UI32_T                unit,
    const CLX_PORT_T            lag_port,
    CLX_FDL_INFO_T              *ptr_fdl_info);

CLX_ERROR_NO_T
hal_lag_delFdlGroup(
    const UI32_T                unit,
    const CLX_PORT_T            lag_port);

void
hal_lag_linkCallback(
    const UI32_T            unit,
    const UI32_T            port,
    const UI32_T            link,
    void                    *ptr_cookie);

void
hal_lag_updateMember(
    const   UI32_T      unit,
    const   UI32_T      port,
    const   UI32_T      link,
    void                *ptr_cookie);

extern HAL_LAG_CB_T    _ext_hal_lag_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

#endif /* End of HAL_LAG_H */

