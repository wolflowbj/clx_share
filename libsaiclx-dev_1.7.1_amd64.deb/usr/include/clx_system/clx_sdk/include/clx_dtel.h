/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_dtel.h
 * PURPOSE:
 *      It provides DTEL module API.
 *
 * NOTES:
 *
 */


#ifndef CLX_DTEL_H
#define CLX_DTEL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef struct CLX_DTEL_DPP_HDR_S
{

    UI32_T          probe_mark_1;
    UI32_T          probe_mark_2;
    UI32_T          probe_mask;
    UI32_T          hop_lim;
    UI32_T          max_len;
    UI32_T          cur_len;
    UI32_T          send_id;
    UI32_T          seq_num;

} CLX_DTEL_DPP_HDR_T;

typedef struct CLX_DTEL_DPP_S
{
    CLX_IPV4_T          ipv4_addr;
    CLX_IPV6_T          ipv6_addr;
    BOOL_T              check_threshold;
    UI32_T              udp_dp;
    UI32_T              v6_nhdr;
    UI32_T              opq_id;
    UI32_T              dev_id;
    CLX_DTEL_DPP_HDR_T  dpp_hdr;
} CLX_DTEL_DPP_T;

/* refers to https://tools.ietf.org/html/draft-ietf-ippm-ioam-data-00 */

typedef enum
{
    CLX_DTEL_IOAM_TRACE_TYPE_HOP_LIM_NODE_ID       = (1UL << 15),
    CLX_DTEL_IOAM_TRACE_TYPE_IF_ID                 = (1UL << 14),
    CLX_DTEL_IOAM_TRACE_TYPE_TS_SEC                = (1UL << 13),
    CLX_DTEL_IOAM_TRACE_TYPE_TS_NSEC               = (1UL << 12),
    CLX_DTEL_IOAM_TRACE_TYPE_TRANS_DELAY           = (1UL << 11),
    CLX_DTEL_IOAM_TRACE_TYPE_APP_DATA              = (1UL << 10),
    CLX_DTEL_IOAM_TRACE_TYPE_QUEUE_DEPTH           = (1UL << 9),
    CLX_DTEL_IOAM_TRACE_TYPE_OPACK_INFO            = (1UL << 8),
    CLX_DTEL_IOAM_TRACE_TYPE_HOP_LIM_NODE_ID_WIDE  = (1UL << 7),
    CLX_DTEL_IOAM_TRACE_TYPE_IF_ID_WIDE            = (1UL << 6),
    CLX_DTEL_IOAM_TRACE_TYPE_APP_DATA_WIDE         = (1UL << 5),
    CLX_DTEL_IOAM_TRACE_TYPE_CHKSM                 = (1UL << 4),
} CLX_DTEL_IOAM_TRACE_TYPE_T;


typedef enum
{
    CLX_DTEL_TYPE_NONE,
    CLX_DTEL_TYPE_IOAM,
    CLX_DTEL_TYPE_IOAM_TRANSIT,
    CLX_DTEL_TYPE_DPP,
    CLX_DTEL_TYPE_IFA_LIVE_MODE,
    CLX_DTEL_TYPE_IFA_SAMPLE_MODE,
    CLX_DTEL_TYPE_IFA_TRANSIT,
    CLX_DTEL_TYPE_IFA_TERM,
    CLX_DTEL_TYPE_LAST,
} CLX_DTEL_TYPE_T;

typedef struct CLX_DTEL_CFG_S
{
    CLX_DTEL_DPP_HDR_T  ifa_hdr;
    CLX_DTEL_TYPE_T     type;
    UI32_T              ioam_opt_header; /* Only for IOAM, refer to CLX_DTEL_IOAM_TRACE_TYPE_T */
    UI32_T              ioam_node_len;
    UI32_T              ioam_node_id;
    UI32_T              ioam_max_len;
    UI32_T              opq_id;
    UI32_T              dev_id;
    UI32_T              udp_dp;
    UI32_T              ifa_tid;
    UI32_T              ifa_user_defined_0;
    UI32_T              ifa_user_defined_1;
    UI32_T              sampling_rate;
} CLX_DTEL_CFG_T;

/* dtel profile */
/* FUNCTION NAME:   clx_dtel_setProfile
 * PURPOSE:
 *    Set DTEL profile information with IOAM option header and sampling rate.
 *
 * INPUT:
 *    unit                --  Device unit number.
 *    profile_id          --  Profile id.
 *    ptr_cfg             --  DTEL profile config
 * OUTPUT:
 *      None.
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_TABLE_FULL    --  No more handler can be created.
 *    CLX_E_NOT_INITED    --  SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_dtel_setProfile(
    const UI32_T                unit,
    const UI32_T                profile_id,
    const CLX_DTEL_CFG_T        *ptr_cfg);

/* FUNCTION NAME:   clx_dtel_getProfile
 * PURPOSE:
 *    Get DTEL profile information with IOAM option header and sampling rate.
 *
 * INPUT:
 *    unit                --  Device unit number.
 *    profile_id          --  Profile id.
 * OUTPUT:
 *    ptr_cfg             --  DTEL profile config
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_TABLE_FULL    --  No more handler can be created.
 *    CLX_E_NOT_INITED    --  SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_dtel_getProfile(
    const UI32_T                unit,
    const UI32_T                profile_id,
    CLX_DTEL_CFG_T              *ptr_cfg);

/* dpp loopback */
/* FUNCTION NAME:   clx_dtel_setDppLoopback
 * PURPOSE:
 *    Set loopback path information for DPP usage
 *
 * INPUT:
 *    unit                --  Device unit number.
 *    ptr_dpp             --  Loopback path information.
 * OUTPUT:
 *    None.
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_TABLE_FULL    --  No more handler can be created.
 *    CLX_E_NOT_INITED    --  SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_dtel_setDppLoopback(
    const UI32_T                unit,
    const CLX_DTEL_DPP_T        *ptr_dpp);

/* FUNCTION NAME:   clx_dtel_getDppLoopback
 * PURPOSE:
 *    Get loopback path information for DPP usage
 *
 * INPUT:
 *    unit                --  Device unit number.
 * OUTPUT:
 *    ptr_dpp             --  Loopback path information.
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_TABLE_FULL    --  No more handler can be created.
 *    CLX_E_NOT_INITED    --  SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_dtel_getDppLoopback(
    const UI32_T                unit,
    CLX_DTEL_DPP_T              *ptr_dpp);

#endif  /* End of CLX_DTEL_H */
