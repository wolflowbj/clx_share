/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_stp.h
 * PURPOSE:
 *      It provides STP module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_STP_H
#define CLX_STP_H


/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_vlan.h>


/* NAMING CONSTANT DECLARATIONS
 */


/* MACRO FUNCTION DECLARATIONS
 */


/* DATA TYPE DECLARATIONS
 */

/* STP port state type */
typedef enum CLX_STP_PORTSTATE_E
{
    CLX_STP_PORTSTATE_DISCARD = 0,      /* Discard */
    CLX_STP_PORTSTATE_LEARN,            /* Learn */
    CLX_STP_PORTSTATE_FORWARD,          /* Forward */
    CLX_STP_PORTSTATE_LAST
} CLX_STP_PORTSTATE_T;


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_stp_createStg
 * PURPOSE:
 *      Create a STG with user specified STG ID.
 * INPUT:
 *      unit                -- Device unit number
 *      stg                 -- STG ID which will be created
 * OUTPUT:
        None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No avaliable entry
 *      CLX_E_NO_MEMORY     -- No available memory
 *      CLX_E_OTHERS        -- Operate failed
 * NOTES:
 *      This API is used to create a user specified STG. User should specify the
 *      STG ID to be created. <CL>
 *      STG 0 has been created in STP module initialization process, and
 *      it should not be created again.
 */
CLX_ERROR_NO_T
clx_stp_createStg(
    const UI32_T    unit,
    const UI32_T    stg);

/* FUNCTION NAME:   clx_stp_destroyStg
 * PURPOSE:
 *      Destroy a STG with user specified STG ID.
 * INPUT:
 *      unit                 -- Device unit number
 *      stg                  -- STG ID which will be deleted
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry does not exist
 *      CLX_E_OTHERS          -- Operate failed
 * NOTES:
 *      If some Bridge Domains are associated with the STG, user should
 *      associate them with other existing STG(s) before destroying this STG.
 *      clx_stp_setBridgeDomainStg is used to associate a Bridge Domain with a STG.
 *      STG 0 is always active and should not be deleted.
 */
CLX_ERROR_NO_T
clx_stp_destroyStg(
    const UI32_T    unit,
    const UI32_T    stg);

/* FUNCTION NAME:   clx_stp_setBridgeDomainStg
 * PURPOSE:
 *      Allocate a Bridge Domain with a STG.
 * INPUT:
 *      unit                  -- Device unit number
 *      bdid                  -- Bridge domain ID
 *      stg                   -- STG ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry does not exist
 *      CLX_E_OTHERS          -- Operate failed
 * NOTES:
 *      When a bridge domain created, it is allocated to STG 0 by default.
 */
CLX_ERROR_NO_T
clx_stp_setBridgeDomainStg(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid,
    const UI32_T                 stg);

/* FUNCTION NAME:   clx_stp_getBridgeDomainStg
 * PURPOSE:
 *      Get the STG ID to which the specific Bridge Domain is allocated.
 * INPUT:
 *      unit                  -- Device unit number
 *      bdid                  -- Bridge domain ID
 * OUTPUT:
 *      ptr_stg               -- STG ID
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry does not exist
 *      CLX_E_OTHERS          -- Operate failed
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_stp_getBridgeDomainStg(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid,
    UI32_T                       *ptr_stg);

/* FUNCTION NAME:   clx_stp_setPortstate
 * PURPOSE:
 *      Set the STP port state for a specified port on a STG.
 * INPUT:
 *      unit                  -- Device unit number
 *      stg                   -- STG ID
 *      port                  -- Port ID
 *      portstate             -- STP port state
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry does not exist
 *      CLX_E_OTHERS          -- Operate failed
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_stp_setPortstate(
    const UI32_T                 unit,
    const UI32_T                 stg,
    const UI32_T                 port,
    const CLX_STP_PORTSTATE_T    portstate);

/* FUNCTION NAME:   clx_stp_getPortstate
 * PURPOSE:
 *      Get the STP port state for a specified port on a STG.
 * INPUT:
 *      unit                  -- Device unit number
 *      stg                   -- STG ID
 *      port                  -- Port ID
 * OUTPUT:
 *      ptr_portstate         -- STP port state
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry does not exist
 *      CLX_E_OTHERS          -- Operate failed
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_stp_getPortstate(
    const UI32_T           unit,
    const UI32_T           stg,
    const UI32_T           port,
    CLX_STP_PORTSTATE_T    *ptr_portstate);

/* FUNCTION NAME:   clx_stp_isStgValid
 * PURPOSE:
 *      Check whether a specified STG is created.
 * INPUT:
 *      unit                  -- Device unit number
 *      stg                   -- STG ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- The STG has been created
 *      CLX_E_ENTRY_NOT_FOUND -- The STG has not been created
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_OTHERS          -- Operate failed
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_stp_isStgValid(
    const UI32_T    unit,
    const UI32_T    stg);

#endif /* End of CLX_STP_H */
