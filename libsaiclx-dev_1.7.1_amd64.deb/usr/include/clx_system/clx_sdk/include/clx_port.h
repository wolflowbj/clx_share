/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   clx_port.h
 * PURPOSE:
 *      It provides PORT module API.
 * NOTES:
 */

#ifndef CLX_PORT_H
#define CLX_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_qos.h>
#include <clx_meter.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_PORT_NUM                (288)
#define CLX_PORT_BITMAP_SIZE        CLX_BITMAP_SIZE(CLX_PORT_NUM)
#define CLX_PORT_PROFILE_INVALID    (UI32_T)(-1)

/* Port MAP API flags */
#define CLX_PORT_FLAGS_INIT_ACTIVE  (1U << 0)
#define CLX_PORT_FLAGS_GUARANTEED   (1U << 1)
#define CLX_PORT_FLAGS_SET_MAP_DONE (1U << 2)
#define CLX_PORT_FLAGS_CPI          (1U << 3)
#define CLX_PORT_FLAGS_RCP          (1U << 4)

#define CLX_PORT_ANLT_DISABLE       (0)
#define CLX_PORT_ANLT_ENABLE        (1)
#define CLX_PORT_ANLT_ENABLE_LT     (2)         /* enable LT only */
#define CLX_PORT_ANLT_LAST          (3)

#define CLX_PORT_FEC_DISABLE        (0)
#define CLX_PORT_FEC_ENABLE         (1)
#define CLX_PORT_FEC_RS528          (2)
#define CLX_PORT_FEC_RS544          (3)
#define CLX_PORT_FEC_RS272          (4)
#define CLX_PORT_FEC_LAST           (5)
#define CLX_PORT_FEC_RS             CLX_PORT_FEC_RS528

#define CLX_PORT_LINK_DOWN          (0)
#define CLX_PORT_LINK_UP            (1)

#define CLX_PORT_FAULT_NONE         (0)
#define CLX_PORT_FAULT_LOCAL        (1)
#define CLX_PORT_FAULT_REMOTE       (2)

#define CLX_PORT_FC_STATUS_OFF      (0)
#define CLX_PORT_FC_STATUS_ON       (1)

#define CLX_PORT_TS_REPLACE_MAC_SA_WITH_IGR     (0)
#define CLX_PORT_TS_REPLACE_MAC_SA_WITH_EGR     (1)
#define CLX_PORT_TS_REPLACE_MAC_DA_WITH_IGR     (2)
#define CLX_PORT_TS_REPLACE_MAC_DA_WITH_EGR     (3)

/* MACRO FUNCTION DECLARATIONS
*/
#define CLX_PORT_ADD(bitmap, port) (((bitmap)[(port)/32]) |=  (1U << ((port)%32)))
#define CLX_PORT_DEL(bitmap, port) (((bitmap)[(port)/32]) &= ~(1U << ((port)%32)))
#define CLX_PORT_CHK(bitmap, port) ((((bitmap)[(port)/32] &   (1U << ((port)%32)))) != 0)

#define CLX_PORT_FOREACH(bitmap, port)                 \
            for(port = 0; port < CLX_PORT_NUM; port++) \
                if(CLX_PORT_CHK(bitmap, port))

#define CLX_PORT_BITMAP_CLEAR(bitmap) \
            ((bitmap)[0] =            \
             (bitmap)[1] =            \
             (bitmap)[2] =            \
             (bitmap)[3] =            \
             (bitmap)[4] =            \
             (bitmap)[5] =            \
             (bitmap)[6] =            \
             (bitmap)[7] =            \
             (bitmap)[8] = 0)

#define CLX_PORT_BITMAP_EMPTY(bitmap) \
            (((bitmap)[0] == 0) &&    \
             ((bitmap)[1] == 0) &&    \
             ((bitmap)[2] == 0) &&    \
             ((bitmap)[3] == 0) &&    \
             ((bitmap)[4] == 0) &&    \
             ((bitmap)[5] == 0) &&    \
             ((bitmap)[6] == 0) &&    \
             ((bitmap)[7] == 0) &&    \
             ((bitmap)[8] == 0))

#define CLX_PORT_BITMAP_EQUAL(bitmap_a, bitmap_b) \
            (((bitmap_a)[0] == (bitmap_b)[0]) &&  \
             ((bitmap_a)[1] == (bitmap_b)[1]) &&  \
             ((bitmap_a)[2] == (bitmap_b)[2]) &&  \
             ((bitmap_a)[3] == (bitmap_b)[3]) &&  \
             ((bitmap_a)[4] == (bitmap_b)[4]) &&  \
             ((bitmap_a)[5] == (bitmap_b)[5]) &&  \
             ((bitmap_a)[6] == (bitmap_b)[6]) &&  \
             ((bitmap_a)[7] == (bitmap_b)[7]) &&  \
             ((bitmap_a)[8] == (bitmap_b)[8]))

/* DATA TYPE DECLARATIONS
 */

/* VLAN Tag Mode */
typedef enum
{
    CLX_PORT_VLAN_TAG_MODE_1Q = 0,
    CLX_PORT_VLAN_TAG_MODE_1AD,
    CLX_PORT_VLAN_TAG_MODE_EXTVLAN,
    CLX_PORT_VLAN_TAG_MODE_LAST
} CLX_PORT_VLAN_TAG_MODE_T;

/* Acceptable Frame Type */
typedef enum
{
    CLX_PORT_ACCEPTABLE_TYPE_ALL = 0,
    CLX_PORT_ACCEPTABLE_TYPE_NONE,
    CLX_PORT_ACCEPTABLE_TYPE_TAGGED,
    CLX_PORT_ACCEPTABLE_TYPE_UNTAGGED,
    CLX_PORT_ACCEPTABLE_TYPE_LAST
} CLX_PORT_ACCEPTABLE_TYPE_T;

/* Port Speed */
typedef enum
{
    CLX_PORT_SPEED_1G   = 1000,
    CLX_PORT_SPEED_10G  = 10000,
    CLX_PORT_SPEED_25G  = 25000,
    CLX_PORT_SPEED_40G  = 40000,
    CLX_PORT_SPEED_50G  = 50000,
    CLX_PORT_SPEED_100G = 100000,
    CLX_PORT_SPEED_200G = 200000,
    CLX_PORT_SPEED_400G = 400000,
    CLX_PORT_SPEED_LAST
} CLX_PORT_SPEED_T;

/* Flow Control */
typedef enum
{
    CLX_PORT_FC_OFF = 0,    /* Both TX, RX disabled */
    CLX_PORT_FC_TXONLY,     /* Only TX enabled */
    CLX_PORT_FC_RXONLY,     /* Only RX enabled */
    CLX_PORT_FC_ON,         /* Both TX, RX enabled */
    CLX_PORT_FC_LAST
} CLX_PORT_FC_T;

/* EEE Mode */
typedef enum
{
    CLX_PORT_EEE_MODE_DISABLE = 0,
    CLX_PORT_EEE_MODE_FASTWAKEUP,
    CLX_PORT_EEE_MODE_DEEPSLEEP,
    CLX_PORT_EEE_MODE_LAST,
} CLX_PORT_EEE_MODE_T;

/* Auto-negotiation Ability Bitmap for Port Speed */
typedef enum
{
    CLX_PORT_ABILITY_SPEED_1000BASE_X          = (1U << 0),
    CLX_PORT_ABILITY_SPEED_10GBASE_KR          = (1U << 1),
    CLX_PORT_ABILITY_SPEED_40GBASE_KR4         = (1U << 2),
    CLX_PORT_ABILITY_SPEED_40GBASE_CR4         = (1U << 3),
    CLX_PORT_ABILITY_SPEED_100GBASE_CR10       = (1U << 4),
    CLX_PORT_ABILITY_SPEED_100GBASE_KR4        = (1U << 5),
    CLX_PORT_ABILITY_SPEED_100GBASE_CR4        = (1U << 6),
    CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR_S     = (1U << 7),
    CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR       = (1U << 8),
    CLX_PORT_ABILITY_SPEED_50GBASE_KR2_CR2     = (1U << 9),
    CLX_PORT_ABILITY_SPEED_50GBASE_KR_CR       = (1U << 10),
    CLX_PORT_ABILITY_SPEED_100GBASE_KR2_CR2    = (1U << 11),
    CLX_PORT_ABILITY_SPEED_200GBASE_KR4_CR4    = (1U << 12),
    CLX_PORT_ABILITY_SPEED_400GBASE_CONSORTIUM = (1U << 13),
} CLX_PORT_ABILITY_SPEED_T;

#define CLX_PORT_ABILITY_SPEED_50GBASE_CR2    CLX_PORT_ABILITY_SPEED_50GBASE_KR2_CR2

/* Auto-negotiation Ability Bitmap for Flow Control */
typedef enum
{
    CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE = (1U << 0),
    CLX_PORT_ABILITY_PAUSE_SYM_PAUSE  = (1U << 1),
} CLX_PORT_ABILITY_PAUSE_T;

/* Auto-negotiation Ability Bitmap for EEE */
typedef enum
{
    CLX_PORT_ABILITY_EEE_10GBASE_KR    = (1U << 0),
    CLX_PORT_ABILITY_EEE_40GBASE_KR4   = (1U << 1),
    CLX_PORT_ABILITY_EEE_40GBASE_CR4   = (1U << 2),
    CLX_PORT_ABILITY_EEE_100GBASE_CR10 = (1U << 3),
    CLX_PORT_ABILITY_EEE_100GBASE_KR4  = (1U << 4),
    CLX_PORT_ABILITY_EEE_100GBASE_CR4  = (1U << 5),
    CLX_PORT_ABILITY_EEE_25GBASE_R     = (1U << 6),
} CLX_PORT_ABILITY_EEE_T;

/* Auto-negotiation Ability Bitmap for Forward Error Correction */
typedef enum
{
    CLX_PORT_ABILITY_FEC_ABILITY        = (1U << 0),
    CLX_PORT_ABILITY_FEC_REQUEST        = (1U << 1),
    CLX_PORT_ABILITY_FEC_RS_REQUEST     = (1U << 2),
    CLX_PORT_ABILITY_FEC_BASE_R_REQUEST = (1U << 3),
} CLX_PORT_ABILITY_FEC_T;

/*  Auto-negotiation Ability Bitmap for Interface */
typedef enum
{
    CLX_PORT_ABILITY_INTERFACE_GMII    = (1U << 0),
    CLX_PORT_ABILITY_INTERFACE_XGMII   = (1U << 1),
    CLX_PORT_ABILITY_INTERFACE_XLGMII  = (1U << 2),
    CLX_PORT_ABILITY_INTERFACE_CGMII   = (1U << 3),
    CLX_PORT_ABILITY_INTERFACE_25GMII  = (1U << 4),
    CLX_PORT_ABILITY_INTERFACE_50GMII  = (1U << 5),
    CLX_PORT_ABILITY_INTERFACE_200GMII = (1U << 6),
    CLX_PORT_ABILITY_INTERFACE_400GMII = (1U << 7),
    CLX_PORT_ABILITY_INTERFACE_LAST
} CLX_PORT_ABILITY_INTERFACE_T;

/*  Auto-negotiation Ability Bitmap for Medium */
typedef enum
{
    CLX_PORT_ABILITY_MEDIUM_FIBER  = (1U << 0),
    CLX_PORT_ABILITY_MEDIUM_COPPER = (1U << 1),
    CLX_PORT_ABILITY_MEDIUM_LAST
} CLX_PORT_ABILITY_MEDIUM_T;

/* Local Loopback Types */
typedef enum
{
    CLX_PORT_LOOPBACK_DISABLE = 0,
    CLX_PORT_LOOPBACK_MAC,
    CLX_PORT_LOOPBACK_PHY,
    CLX_PORT_LOOPBACK_EXTERNAL_PHY,
    CLX_PORT_LOOPBACK_LAST
} CLX_PORT_LOOPBACK_T;

/* PHY Type */
typedef enum
{
    CLX_PORT_PHY_LOCATION_INT = 0,
    CLX_PORT_PHY_LOCATION_EXT_SS,
    CLX_PORT_PHY_LOCATION_EXT_LS,
    CLX_PORT_PHY_LOCATION_LAST
} CLX_PORT_PHY_LOCATION_T;

/* Medium Type */
typedef enum
{
    CLX_PORT_MEDIUM_TYPE_SGMII = 0,
    CLX_PORT_MEDIUM_TYPE_1000BASE_X,
    CLX_PORT_MEDIUM_TYPE_10GBASE_CR,
    CLX_PORT_MEDIUM_TYPE_10GBASE_KR,
    CLX_PORT_MEDIUM_TYPE_10GBASE_SR,
    CLX_PORT_MEDIUM_TYPE_10GBASE_LR,
    CLX_PORT_MEDIUM_TYPE_10GBASE_ER,
    CLX_PORT_MEDIUM_TYPE_40GBASE_CR4,
    CLX_PORT_MEDIUM_TYPE_40GBASE_KR4,
    CLX_PORT_MEDIUM_TYPE_40GBASE_SR4,
    CLX_PORT_MEDIUM_TYPE_40GBASE_LR4,
    CLX_PORT_MEDIUM_TYPE_40GBASE_ER4,
    CLX_PORT_MEDIUM_TYPE_100GBASE_CR10,
    CLX_PORT_MEDIUM_TYPE_100GBASE_SR10,
    CLX_PORT_MEDIUM_TYPE_100GBASE_CR4,
    CLX_PORT_MEDIUM_TYPE_100GBASE_KR4,
    CLX_PORT_MEDIUM_TYPE_100GBASE_SR4,
    CLX_PORT_MEDIUM_TYPE_100GBASE_LR4,
    CLX_PORT_MEDIUM_TYPE_100GBASE_ER4,
    CLX_PORT_MEDIUM_TYPE_25GBASE_CR,
    CLX_PORT_MEDIUM_TYPE_25GBASE_KR,
    CLX_PORT_MEDIUM_TYPE_25GBASE_SR,
    CLX_PORT_MEDIUM_TYPE_25GBASE_LR,
    CLX_PORT_MEDIUM_TYPE_25GBASE_ER,
    CLX_PORT_MEDIUM_TYPE_50GBASE_CR2,
    CLX_PORT_MEDIUM_TYPE_50GBASE_SR2,
    CLX_PORT_MEDIUM_TYPE_50GBASE_CR,
    CLX_PORT_MEDIUM_TYPE_50GBASE_KR,
    CLX_PORT_MEDIUM_TYPE_50GBASE_SR,
    CLX_PORT_MEDIUM_TYPE_100GBASE_CR2,
    CLX_PORT_MEDIUM_TYPE_100GBASE_KR2,
    CLX_PORT_MEDIUM_TYPE_100GBASE_SR2,
    CLX_PORT_MEDIUM_TYPE_200GBASE_CR4,
    CLX_PORT_MEDIUM_TYPE_200GBASE_KR4,
    CLX_PORT_MEDIUM_TYPE_200GBASE_SR4,
    CLX_PORT_MEDIUM_TYPE_400GBASE_LR8,
    CLX_PORT_MEDIUM_TYPE_400GBASE_CR8,
    CLX_PORT_MEDIUM_TYPE_LAST
} CLX_PORT_MEDIUM_TYPE_T;

/* PHY Configuration */
typedef enum
{
    CLX_PORT_PHY_PROPERTY_LANE_SWAP_TX = 0,
    CLX_PORT_PHY_PROPERTY_LANE_SWAP_RX,
    CLX_PORT_PHY_PROPERTY_POL_REV_TX,
    CLX_PORT_PHY_PROPERTY_POL_REV_RX,
    CLX_PORT_PHY_PROPERTY_TX_COEF_CN1,
    CLX_PORT_PHY_PROPERTY_TX_COEF_C0,
    CLX_PORT_PHY_PROPERTY_TX_COEF_C1,
    CLX_PORT_PHY_PROPERTY_TX_COEF_C2,
    CLX_PORT_PHY_PROPERTY_TX_COEF_CN2,
    CLX_PORT_PHY_PROPERTY_LAST
} CLX_PORT_PHY_PROPERTY_T;

typedef enum
{
    CLX_PORT_PROPERTY_ADMIN_STATE,
    CLX_PORT_PROPERTY_AUTONEG_STATUS,
    CLX_PORT_PROPERTY_BD_LABEL,
    CLX_PORT_PROPERTY_BYPASS_STP,
    CLX_PORT_PROPERTY_ECN,
    CLX_PORT_PROPERTY_FEC,
    CLX_PORT_PROPERTY_GROUP_LABEL,
    CLX_PORT_PROPERTY_LEARNING,
    CLX_PORT_PROPERTY_NVGRE_UPLINK,
    CLX_PORT_PROPERTY_PORT_BRIDGING,
    CLX_PORT_PROPERTY_LANE_CNT,
    CLX_PORT_PROPERTY_VXLAN_UPLINK,
    CLX_PORT_PROPERTY_CUT_THROUGH,
    CLX_PORT_PROPERTY_UNI_PORT,
    CLX_PORT_PROPERTY_BYPASS_VLAN2FDID,
    CLX_PORT_PROPERTY_LEARN_FAIL_ACTION,
    CLX_PORT_PROPERTY_SA_MISS_ACTION,
    CLX_PORT_PROPERTY_VLAN_MISS_ACTION,
    CLX_PORT_PROPERTY_IGR_MIR_SESSION_BITMAP,
    CLX_PORT_PROPERTY_EGR_MIR_SESSION_BITMAP,
    CLX_PORT_PROPERTY_TS_EN,
    CLX_PORT_PROPERTY_IGR_SAMPLING_RATE,        /* param0: sampling_rate  */
    CLX_PORT_PROPERTY_IGR_SAMPLE_TO_MIR_SESSION,/* param0: 0:disable, 1:enable
                                                   param1: mir_session_id */
    CLX_PORT_PROPERTY_EGR_SAMPLING_RATE,        /* param0: sampling_rate  */
    CLX_PORT_PROPERTY_EGR_SAMPLE_TO_MIR_SESSION,/* param0: 0:disable, 1:enable
                                                   param1: mir_session_id */
    CLX_PORT_PROPERTY_EGR_SAMPLE_HIGH_LATENCY,  /* param0: 0:disable, 1:enable */
    CLX_PORT_PROPERTY_IGR_VLAN_FILTER_EN,
    CLX_PORT_PROPERTY_EGR_VLAN_FILTER_EN,
    CLX_PORT_PROPERTY_UNIDIRECTIONAL_LINK,
    CLX_PORT_PROPERTY_1G_MEDIUM_AUTO,
    CLX_PORT_PROPERTY_TX_EN,
    CLX_PORT_PROPERTY_RX_EN,
    CLX_PORT_PROPERTY_MXLINK_EN,
    CLX_PORT_PROPERTY_MIB_MAX_LEN,
    CLX_PORT_PROPERTY_SKIP_MPLS,
    CLX_PORT_PROPERTY_DEL_MPLS,
    CLX_PORT_PROPERTY_TRUNC_MASK,
    CLX_PORT_PROPERTY_CRC_REPLACE,
    CLX_PORT_PROPERTY_PPPOE_EN,
    CLX_PORT_PROPERTY_PPPOE_VLAN_NUM,
    CLX_PORT_PROPERTY_DTEL_IOAM_TRANSIT,
    CLX_PORT_PROPERTY_DTEL_IOAM_DECAP,
    CLX_PORT_PROPERTY_DTEL_IFA_SAMPLE_SUPP_EN,
    CLX_PORT_PROPERTY_SYNCE_MODE,
    CLX_PORT_PROPERTY_ACL_MATCH_TUNNEL_INNER,       /* ingress acl base/udf key would match inner header of ip tnl pkt */
    CLX_PORT_PROPERTY_ACL_MATCH_PACKET_VLAN,        /* ingress acl base key would match packet vlan instead of
                                                       service/l3_intf_group_label */
    CLX_PORT_PROPERTY_TS_INSERT_EOF_IGR,/* insert ingress timestamp before fcs */
    CLX_PORT_PROPERTY_TS_INSERT_EOF_EGR,/* insert egress timestamp before fcs */
    CLX_PORT_PROPERTY_TS_REPLACE_TYPE,   /* reference CLX_PORT_TS_REPLACE_MAC_XXX */
    CLX_PORT_PROPERTY_TS_REPLACE_MAC,    /* enable or disable to replace mac address with timestamp */
    CLX_PORT_PROPERTY_MXHDR_EN,
    CLX_PORT_PROPERTY_DTEL_IFA_DECAP,
    CLX_PORT_PROPERTY_DTEL_IFA_TRANSIT,
    CLX_PORT_PROPERTY_LAST
} CLX_PORT_PROPERTY_T;

typedef enum
{
    CLX_PORT_PRBS_PATTERN_DISABLE = 0x0,
    CLX_PORT_PRBS_PATTERN_9,
    CLX_PORT_PRBS_PATTERN_13,
    CLX_PORT_PRBS_PATTERN_31,
    CLX_PORT_PRBS_PATTERN_SQUARE,
    CLX_PORT_PRBS_PATTERN_LAST
} CLX_PORT_PRBS_PATTERN_T;

typedef enum
{
    CLX_PORT_PRBS_CHECKER_DISABLE = 0x0,
    CLX_PORT_PRBS_CHECKER_ENABLE,
    CLX_PORT_PRBS_CHECKER_LAST
} CLX_PORT_PRBS_CHECKER_T;

typedef enum
{
    CLX_PORT_FEC_CNT_TYPE_CERR = 0x0,
    CLX_PORT_FEC_CNT_TYPE_UCERR,
    CLX_PORT_FEC_CNT_TYPE_LANE_SERR,
    CLX_PORT_FEC_CNT_TYPE_LAST
} CLX_PORT_FEC_CNT_TYPE_T;

typedef enum
{
    CLX_PORT_AUTO_NEG_DISABLE = 0,
    CLX_PORT_AUTO_NEG_ENABLE = 1,
    CLX_PORT_AUTO_NEG_LAST
} CLX_PORT_AUTO_NEG_TYPE_T;

typedef enum
{
    CLX_PORT_LINK_TRAINING_DISABLE  = 0x0,
    CLX_PORT_LINK_TRAINING_ENABLE,
    CLX_PORT_LINK_TRAINING_LAST,
} CLX_PORT_LINK_TRAINING_T;

typedef enum
{
    /** No Error detected */
    CLX_PORT_LINK_TRAINING_FAIL_NO_ERROR,

    /** Failure detected */
    CLX_PORT_LINK_TRAINING_FAIL_FRAME_LOCK_ERROR,

    /** SNR lower than threshold */
    CLX_PORT_LINK_TRAINING_FAIL_SNR_LOWER_THRESHOLD,

    /** Link training timeout */
    CLX_PORT_LINK_TRAINING_FAIL_TIME_OUT,
    CLX_PORT_LINK_TRAINING_FAIL_LAST
} CLX_PORT_LINK_TRAINING_FAIL_T;

typedef enum
{
    CLX_PORT_EYE_SCAN_DIAGRAM = 0x0,
    CLX_PORT_EYE_SCAN_BER,
    CLX_PORT_EYE_SCAN_LAST
} CLX_PORT_EYE_SCAN_T;

typedef enum
{
    CLX_PORT_SYNCE_MODE_DISABLE = 0x0,
    CLX_PORT_SYNCE_MODE_0,
    CLX_PORT_SYNCE_MODE_1,
    CLX_PORT_SYNCE_MODE_LAST

} CLX_PORT_SYNCE_MODE_T;

/* CLX_PORT_BITMAP_T is the data type for physical port bitmap. */
typedef UI32_T   CLX_PORT_BITMAP_T[CLX_PORT_BITMAP_SIZE];

typedef struct CLX_PORT_VLAN_TAG_S
{
    UI16_T                      s_tpid;
    UI16_T                      c_tpid;
    CLX_PORT_VLAN_TAG_MODE_T    mode;
} CLX_PORT_VLAN_TAG_T;

typedef struct CLX_PORT_ABILITY_S
{
    CLX_PORT_ABILITY_SPEED_T        speed;
    CLX_PORT_ABILITY_PAUSE_T        pause;
    CLX_PORT_ABILITY_FEC_T          fec;
    CLX_PORT_ABILITY_EEE_T          eee;
    CLX_PORT_ABILITY_INTERFACE_T    interface;
    CLX_PORT_ABILITY_MEDIUM_T       medium;

#define CLX_PORT_ABILITY_FLAGS_AUTONEG    (1U << 0)
    UI32_T                          flags;
} CLX_PORT_ABILITY_T;

typedef struct  CLX_PORT_PROFILE_ID_S
{
    UI32_T      ingress_id;
    UI32_T      egress_id;
    CLX_DIR_T   dir;
} CLX_PORT_PROFILE_ID_T;

typedef CLX_ERROR_NO_T
(*CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    merged_vid_min,
    const UI32_T    merged_vid_max,
    void            *ptr_cookie);

typedef struct CLX_PORT_SEG_SRV_S
{
    CLX_BRIDGE_DOMAIN_T    bdid;        /* valid while L3_ONLY unset. */
    UI32_T                 l3_intf_id;  /* valid while L3_ONLY set */
    CLX_BUM_INFO_T         bc_info;
    CLX_BUM_INFO_T         umc_info;
    CLX_BUM_INFO_T         uuc_info;
    UI32_T                 igr_group_label;
    UI32_T                 egr_group_label;
    UI32_T                 igr_sampling_rate;
    UI32_T                 igr_sample_to_mir_session_id;
    UI32_T                 egr_sampling_rate;
    UI32_T                 egr_sample_to_mir_session_id;
    UI32_T                 igr_mir_session_bitmap;
    UI32_T                 egr_mir_session_bitmap;
    UI32_T                 pcp_dei_to_phb_profile_id;
    UI32_T                 dscp_to_phb_profile_id;
    UI32_T                 phb_to_pcp_dei_profile_id;
    UI32_T                 phb_to_dscp_profile_id;
    UI32_T                 mstp_id;
    UI32_T                 igr_meter_id;
    UI32_T                 egr_meter_id;
    UI32_T                 igr_counter_id;
    UI32_T                 egr_counter_id;
    UI32_T                 igr_dist_counter_id;
    UI32_T                 egr_dist_counter_id;
    UI32_T                 dtel_profile_id;

#define CLX_PORT_SEG_SRV_FLAGS_ENABLE_LEARN                 (1U << 0)
#define CLX_PORT_SEG_SRV_FLAGS_SA_MOVE_EXCEPTION            (1U << 1)
#define CLX_PORT_SEG_SRV_FLAGS_SA_MISS_EXCEPTION            (1U << 2)
#define CLX_PORT_SEG_SRV_FLAGS_REMOVE_VLAN_TAG              (1U << 3)
#define CLX_PORT_SEG_SRV_FLAGS_QOS_DO_NOT_MODIFY            (1U << 4)
#define CLX_PORT_SEG_SRV_FLAGS_QOS_USE_INNER                (1U << 5)
#define CLX_PORT_SEG_SRV_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID (1U << 6)
#define CLX_PORT_SEG_SRV_FLAGS_DSCP_TO_PHB_PROFILE_VALID    (1U << 7)
#define CLX_PORT_SEG_SRV_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID (1U << 8)
#define CLX_PORT_SEG_SRV_FLAGS_PHB_TO_DSCP_PROFILE_VALID    (1U << 9)
#define CLX_PORT_SEG_SRV_FLAGS_IGR_METER_VALID              (1U << 10)
#define CLX_PORT_SEG_SRV_FLAGS_EGR_METER_VALID              (1U << 11)
#define CLX_PORT_SEG_SRV_FLAGS_IGR_COUNTER_VALID            (1U << 12)
#define CLX_PORT_SEG_SRV_FLAGS_EGR_COUNTER_VALID            (1U << 13)
#define CLX_PORT_SEG_SRV_FLAGS_IGR_DIST_COUNTER_VALID       (1U << 14)
#define CLX_PORT_SEG_SRV_FLAGS_EGR_DIST_COUNTER_VALID       (1U << 15)
#define CLX_PORT_SEG_SRV_FLAGS_TRILL_AF_EN                  (1U << 16)
#define CLX_PORT_SEG_SRV_FLAGS_TRILL_DF_EN                  (1U << 17)
/* while L3_ONLY set, the bdid is invalid, l2 function disable, and use l3_intf_id. */
#define CLX_PORT_SEG_SRV_FLAGS_L3_ONLY                      (1U << 18)
#define CLX_PORT_SEG_SRV_FLAGS_IGR_SAMPLE_TO_MIR            (1U << 19)   /* Sample packets to a mirror session */
#define CLX_PORT_SEG_SRV_FLAGS_EGR_SAMPLE_TO_MIR            (1U << 20)   /* Sample packets to a mirror session */
#define CLX_PORT_SEG_SRV_FLAGS_EGR_SAMPLE_HIGH_LATENCY      (1U << 21)   /* Sample high latency packets */
#define CLX_PORT_SEG_SRV_FLAGS_QINQ_TRANSPARENT_CVID        (1U << 22)
#define CLX_PORT_SEG_SRV_FLAGS_DTEL                         (1U << 23)
    UI32_T                 flags;
} CLX_PORT_SEG_SRV_T;

typedef struct CLX_PORT_INTF_PROPERTY_S
{
    CLX_PORT_ACCEPTABLE_TYPE_T    accept_type;
    CLX_PORT_VLAN_TAG_MODE_T      tag_mode;
    CLX_VLAN_PRECEDENCE_T         precedence;
    UI16_T                        s_tpid;
    UI16_T                        c_tpid;
    UI32_T                        dflt_pcp;
    UI32_T                        dflt_dei;
    UI32_T                        dflt_vid;
    UI32_T                        mtu;
    UI32_T                        igr_sampling_rate;
    UI32_T                        igr_sample_to_mir_session_id; /* Sample packets to a mirror session */
    UI32_T                        egr_sampling_rate;
    UI32_T                        egr_sample_to_mir_session_id;
    UI32_T                        igr_meter_id;
    UI32_T                        egr_meter_id;
    UI32_T                        igr_counter_id;
    UI32_T                        egr_counter_id;
    UI32_T                        igr_dist_counter_id;
    UI32_T                        egr_dist_counter_id;
    UI32_T                        pcp_dei_to_phb_profile_id;
    UI32_T                        phb_to_pcp_dei_profile_id;
    UI32_T                        dscp_to_phb_profile_id;
    UI32_T                        phb_to_dscp_profile_id;
    UI32_T                        exp_to_phb_profile_id;
    UI32_T                        phb_to_exp_profile_id;
    UI32_T                        igr_group_label;
    UI32_T                        egr_group_label;

#define CLX_PORT_INTF_PROPERTY_FLAGS_TRUST_1P               (1U << 0)
#define CLX_PORT_INTF_PROPERTY_FLAGS_TRUST_VLAN             (1U << 1)
#define CLX_PORT_INTF_PROPERTY_FLAGS_PCP_DEI_TO_PHB_VALID   (1U << 2)
#define CLX_PORT_INTF_PROPERTY_FLAGS_PHB_TO_PCP_DEI_VALID   (1U << 3)
#define CLX_PORT_INTF_PROPERTY_FLAGS_DSCP_TO_PHB_VALID      (1U << 4)
#define CLX_PORT_INTF_PROPERTY_FLAGS_PHB_TO_DSCP_VALID      (1U << 5)
#define CLX_PORT_INTF_PROPERTY_FLAGS_EXP_TO_PHB_VALID       (1U << 6)
#define CLX_PORT_INTF_PROPERTY_FLAGS_PHB_TO_EXP_VALID       (1U << 7)
#define CLX_PORT_INTF_PROPERTY_FLAGS_IGR_METER_VALID        (1U << 8)
#define CLX_PORT_INTF_PROPERTY_FLAGS_EGR_METER_VALID        (1U << 9)
#define CLX_PORT_INTF_PROPERTY_FLAGS_IGR_COUNTER_VALID      (1U << 10)
#define CLX_PORT_INTF_PROPERTY_FLAGS_EGR_COUNTER_VALID      (1U << 11)
#define CLX_PORT_INTF_PROPERTY_FLAGS_IGR_DIST_COUNTER_VALID (1U << 12)
#define CLX_PORT_INTF_PROPERTY_FLAGS_EGR_DIST_COUNTER_VALID (1U << 13)
#define CLX_PORT_INTF_PROPERTY_FLAGS_IGR_SAMPLE_TO_MIR      (1U << 14)  /* Sample packets to a mirror session */
#define CLX_PORT_INTF_PROPERTY_FLAGS_EGR_SAMPLE_TO_MIR      (1U << 15)  /* Sample packets to a mirror session */
#define CLX_PORT_INTF_PROPERTY_FLAGS_EGR_SAMPLE_HIGH_LATENCY (1U << 16) /* Sample high latency packets */
    UI32_T                        flags;
} CLX_PORT_INTF_PROPERTY_T;

typedef enum {
    /** PRBS Disable */
    CLX_PORT_PRBS_CONFIG_DISABLE = 0,
    /** Enable both PRBS Transmitter and Receiver */
    CLX_PORT_PRBS_CONFIG_ENABLE_TX_RX,
    /** Enable PRBS Receiver */
    CLX_PORT_PRBS_CONFIG_ENABLE_RX,
    /** Enable PRBS Transmitter */
    CLX_PORT_PRBS_CONFIG_ENABLE_TX,
    CLX_PORT_PRBS_LAST
} CLX_PORT_PRBS_CONFIG_T;

typedef struct  CLX_PORT_TS_ENTRY_S
{
    UI16_T    seq_num;
    UI16_T    sec_hi;
    UI32_T    sec_low;
    UI32_T    nsec;
} CLX_PORT_TS_ENTRY_T;

typedef struct CLX_PORT_STATUS_S
{
    CLX_PORT_SPEED_T    speed;
    UI32_T              link;
    UI32_T              fault;
    UI32_T              rx_fc;
    UI32_T              rx_pfc;
} CLX_PORT_STATUS_T;

typedef struct CLX_PORT_TX_COEF_S
{
#define CLX_PORT_TX_COEF_FLAGS_C0  (1U << 0)
#define CLX_PORT_TX_COEF_FLAGS_C1  (1U << 1)
#define CLX_PORT_TX_COEF_FLAGS_CN1 (1U << 2)
#define CLX_PORT_TX_COEF_FLAGS_C2  (1U << 3)
#define CLX_PORT_TX_COEF_FLAGS_CN2 (1U << 4)
    UI32_T    flags;
    UI32_T    cn2;
    UI32_T    cn1;
    UI32_T    c0;
    UI32_T    c1;
    UI32_T    c2;
} CLX_PORT_TX_COEF_T;

typedef enum CLX_PORT_INTERFACE_TYPE_S
{
    CLX_PORT_INTERFACE_TYPE_NONE    =   0,
    CLX_PORT_INTERFACE_TYPE_CR      =   1 << 0,
    CLX_PORT_INTERFACE_TYPE_CR2     =   1 << 1,
    CLX_PORT_INTERFACE_TYPE_CR4     =   1 << 2,
    CLX_PORT_INTERFACE_TYPE_SR      =   1 << 3,
    CLX_PORT_INTERFACE_TYPE_SR2     =   1 << 4,
    CLX_PORT_INTERFACE_TYPE_SR4     =   1 << 5,
    CLX_PORT_INTERFACE_TYPE_LR      =   1 << 6,
    CLX_PORT_INTERFACE_TYPE_LR4     =   1 << 7,
    CLX_PORT_INTERFACE_TYPE_KR      =   1 << 8,
    CLX_PORT_INTERFACE_TYPE_KR4     =   1 << 9,
    CLX_PORT_INTERFACE_TYPE_CAUI    =   1 << 10,
    CLX_PORT_INTERFACE_TYPE_GMII    =   1 << 11,
    CLX_PORT_INTERFACE_TYPE_SFI     =   1 << 12,
    CLX_PORT_INTERFACE_TYPE_XLAUI   =   1 << 13,
    CLX_PORT_INTERFACE_TYPE_KR2     =   1 << 14,
    CLX_PORT_INTERFACE_TYPE_CAUI4   =   1 << 15,
    CLX_PORT_INTERFACE_TYPE_XAUI    =   1 << 16,
    CLX_PORT_INTERFACE_TYPE_XFI     =   1 << 17,
    CLX_PORT_INTERFACE_TYPE_XGMII   =   1 << 18,
    CLX_PORT_INTERFACE_TYPE_CR8     =   1 << 19,
    CLX_PORT_INTERFACE_TYPE_LR8     =   1 << 20,
    CLX_PORT_INTERFACE_TYPE_MAX     =   1 << 31,
} CLX_PORT_INTERFACE_TYPE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_port_setMediumType
 * PURPOSE:
 *      This API is used to set the medium type for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      medium              -- Medium type
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_setMediumType(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_MEDIUM_TYPE_T    medium);

/* FUNCTION NAME:   clx_port_getMediumType
 * PURPOSE:
 *      This API is used to get the medium type for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_medium          -- Medium type
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getMediumType(
    const UI32_T              unit,
    const UI32_T              port,
    CLX_PORT_MEDIUM_TYPE_T    *ptr_medium);

/* FUNCTION NAME:   clx_port_setSpeed
 * PURPOSE:
 *      This API is used to set the speed for a specific port.<CL>
 *      CLX_PORT_SPEED_T<CL>
 *      - CLX_PORT_SPEED_1G<CL>
 *      - CLX_PORT_SPEED_10G<CL>
 *      - CLX_PORT_SPEED_40G<CL>
 *      - CLX_PORT_SPEED_100G<CL>
 *      User should specify the unit, port and speed.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      speed               -- The speed of the physical port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      The API is used in the force speed mode.
 */
CLX_ERROR_NO_T
clx_port_setSpeed(
    const UI32_T              unit,
    const UI32_T              port,
    const CLX_PORT_SPEED_T    speed);

/* FUNCTION NAME:   clx_port_getSpeed
 * PURPOSE:
 *      This API is used to get the speed for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_speed           -- The speed of the physical port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getSpeed(
    const UI32_T        unit,
    const UI32_T        port,
    CLX_PORT_SPEED_T    *ptr_speed);

/* FUNCTION NAME:   clx_port_setFlowCtrl
 * PURPOSE:
 *      This API is used to set the flow control configuration for a specific port.<CL>
 *      CLX_PORT_FC_T<CL>
 *      - CLX_PORT_FC_OFF<CL>
 *      - CLX_PORT_FC_TXONLY<CL>
 *      - CLX_PORT_FC_RXONLY<CL>
 *      - CLX_PORT_FC_ON<CL>
 *      User should specify the unit, port and flow control value.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      fc                  -- The flow control configuration of the physical port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      The API is used in the force flow control mode.
 */
CLX_ERROR_NO_T
clx_port_setFlowCtrl(
    const UI32_T           unit,
    const UI32_T           port,
    const CLX_PORT_FC_T    fc);

/* FUNCTION NAME:   clx_port_getFlowCtrl
 * PURPOSE:
 *      This API is used to get the flow control configuration for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_fc              -- The flow control configurations of the physical port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getFlowCtrl(
    const UI32_T      unit,
    const UI32_T      port,
    CLX_PORT_FC_T     *ptr_fc);

/* FUNCTION NAME:   clx_port_setPriFlowCtrl
 * PURPOSE:
 *      This API is used to set the PFC configuration for a specific port.<CL>
 *      User should specify the unit, port, priority and PFC value.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      pri                 -- The priority number 0~7
 *      pfc                 -- The PFC configuration of the physical port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_setPriFlowCtrl(
    const UI32_T           unit,
    const UI32_T           port,
    const UI8_T            pri,
    const CLX_PORT_FC_T    pfc);

/* FUNCTION NAME:   clx_port_getPriFlowCtrl
 * PURPOSE:
 *      This API is used to get the PFC configuration for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      pri                 -- The priority number 0~7
 * OUTPUT:
 *      ptr_pfc             -- The PFC configuration of the physical port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getPriFlowCtrl(
    const UI32_T     unit,
    const UI32_T     port,
    const UI8_T      pri,
    CLX_PORT_FC_T    *ptr_pfc);

/* FUNCTION NAME:   clx_port_setEeeMode
 * PURPOSE:
 *      This API is used to set the EEE mode for a specific port.<CL>
 *      User should specify the unit, port and EEE mode.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      mode                -- The EEE mode of the physical port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      The default value of mode is CLX_PORT_EEE_MODE_DISABLE.
 */
CLX_ERROR_NO_T
clx_port_setEeeMode(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_EEE_MODE_T    mode);

/* FUNCTION NAME:   clx_port_getEeeMode
 * PURPOSE:
 *      This API is used to get the EEE mode for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_mode            -- The EEE mode of the physical port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getEeeMode(
    const UI32_T           unit,
    const UI32_T           port,
    CLX_PORT_EEE_MODE_T    *ptr_mode);

/* FUNCTION NAME:   clx_port_setLocalAdvAbility
 * PURPOSE:
 *      This API is used to set the auto-negotiation advertisement for a specific port.<CL>
 *      User should specify the unit, port and the auto-negotiation abilities.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      ptr_ability         -- Auto-negotiation ability setting per port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_setLocalAdvAbility(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   clx_port_getLocalAdvAbility
 * PURPOSE:
 *      This API is used to get the auto-negotiation advertisement for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ability         -- Auto-negotiation ability setting per port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getLocalAdvAbility(
    const UI32_T          unit,
    const UI32_T          port,
    CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   clx_port_getRemoteAdvAbility
 * PURPOSE:
 *      This API is used to get the auto-negotiation remote advertisement for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ability         -- Auto-negotiation ability setting per port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getRemoteAdvAbility(
    const UI32_T          unit,
    const UI32_T          port,
    CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   clx_port_getAbility
 * PURPOSE:
 *      This API is used to get the auto-negotiation ability for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ability         -- Auto-negotiation ability setting per port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getAbility(
    const UI32_T          unit,
    const UI32_T          port,
    CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   clx_port_setLoopback
 * PURPOSE:
 *      This API is used to set the loopback for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      loopback            -- Loopback type: <CL>
 *                          CLX_PORT_LOOPBACK_DISABLE: disable loopback <CL>
 *                          CLX_PORT_LOOPBACK_PHY: local PHY loopback <CL>
 *                          CLX_PORT_LOOPBACK_MAC: local MAC loopback
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_setLoopback(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_LOOPBACK_T    loopback);

/* FUNCTION NAME:   clx_port_getLoopback
 * PURPOSE:
 *      This API is used to get the loopback for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_loopback        -- Loopback type: <CL>
 *                          CLX_PORT_LOOPBACK_DISABLE: disable loopback <CL>
 *                          CLX_PORT_LOOPBACK_PHY: local PHY loopback <CL>
 *                          CLX_PORT_LOOPBACK_MAC: local MAC loopback
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getLoopback(
    const UI32_T           unit,
    const UI32_T           port,
    CLX_PORT_LOOPBACK_T    *ptr_loopback);

/* FUNCTION NAME:   clx_port_probe
 * PURPOSE:
 *      This API is used to probe a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_probe(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   clx_port_initPort
 * PURPOSE:
 *      This API is used to initialize a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_initPort(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   clx_port_deinitPort
 * PURPOSE:
 *      This API is used to deinitialize a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_deinitPort(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   clx_port_setMacAddr
 * PURPOSE:
 *      This API is used to set the MAC address for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      mac                 -- The MAC address
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_setMacAddr(
    const UI32_T       unit,
    const UI32_T       port,
    const CLX_MAC_T    mac);

/* FUNCTION NAME:   clx_port_getMacAddr
 * PURPOSE:
 *      This API is used to get the MAC address for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_mac             -- The MAC address
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getMacAddr(
    const UI32_T    unit,
    const UI32_T    port,
    CLX_MAC_T       *ptr_mac);

/* FUNCTION NAME:   clx_port_getLink
 * PURPOSE:
 *      This API is used to get the physical link status for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_link            -- Link status (Reference to CLX_PORT_LINK_XXX)
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getLink(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_link);

/* FUNCTION NAME:   clx_port_getFault
 * PURPOSE:
 *      This API is used to get the physical fault status for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_fault           -- Fault status (Reference to CLX_PORT_FAULT_XXX)
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getFault(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_fault);

/* FUNCTION NAME:   clx_port_setPhyProperty
 * PURPOSE:
 *      This API is used to set the PHY configuration for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      location            -- PHY location
 *      property            -- PHY property type
 *      value_cnt           -- PHY property value count
 *      ptr_value           -- PHY property value array
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_setPhyProperty(
    const UI32_T                     unit,
    const UI32_T                     port,
    const CLX_PORT_PHY_LOCATION_T    location,
    const CLX_PORT_PHY_PROPERTY_T    property,
    const UI32_T                     value_cnt,
    const UI32_T                     *ptr_value);

/* FUNCTION NAME:   clx_port_getPhyProperty
 * PURPOSE:
 *      This API is used to get the interface type for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      location            -- PHY location
 *      property            -- PHY property type
 *      value_cnt           -- PHY property value count
 * OUTPUT:
 *      ptr_value           -- PHY property value array
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_port_getPhyProperty(
    const UI32_T                     unit,
    const UI32_T                     port,
    const CLX_PORT_PHY_LOCATION_T    location,
    const CLX_PORT_PHY_PROPERTY_T    property,
    const UI32_T                     value_cnt,
    UI32_T                           *ptr_value);

/* FUNCTION NAME:   clx_port_addSegServiceGroup
 * PURPOSE:
 *      This API is used to add a merged vlan group entry.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      merged_vid_min      -- Minimum value of merged vlan id
 *      merged_vid_max      -- Maximum value of merged vlan id
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 *         to merged_vid_min when loop-up port-seg service table.
 */
CLX_ERROR_NO_T
clx_port_addSegServiceGroup(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_VLAN_T    merged_vid_min,
    const CLX_VLAN_T    merged_vid_max);

/* FUNCTION NAME:   clx_port_delSegServiceGroup
 * PURPOSE:
 *      This API is used to del a merged vlan group entry.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      merged_vid_min      -- Minimum value of merged vlan id
 *      merged_vid_max      -- Maximum value of merged vlan id
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 *         to merged_vid_min when loop-up port-seg service table.
 */
CLX_ERROR_NO_T
clx_port_delSegServiceGroup(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_VLAN_T    merged_vid_min,
    const CLX_VLAN_T    merged_vid_max);

/* FUNCTION NAME:   clx_port_getSegServiceGroup
 * PURPOSE:
 *      This API is used to get a merged vlan group entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      port                  -- Physical port ID
 *      merged_vid_min        -- Minimum value of merged vlan id
 *      merged_vid_max        -- Maximum value of merged vlan id
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK              -- Entry exist
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 *         to merged_vid_min when loop-up port-seg service table.
 */
CLX_ERROR_NO_T
clx_port_getSegServiceGroup(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_VLAN_T    merged_vid_min,
    const CLX_VLAN_T    merged_vid_max);

/* FUNCTION NAME:   clx_port_traverseSegServiceGroup
 * PURPOSE:
 *      This API is used to traverse merged vlan group entry.
 * INPUT:
 *      unit                -- Device unit number
 *      callback            -- The callback function of type CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_port_traverseSegServiceGroup(
    const UI32_T                                    unit,
    const CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T    callback,
    void                                            *ptr_cookie);

/* FUNCTION NAME:   clx_port_addSegService
 * PURPOSE:
 *      This API is used to add a port seg service.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 *      seg0                -- segment parameter 0
 *      seg1                -- segment parameter 1
 *      ptr_seg_srv         -- segment service
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Not allow setting port with CLX_PORT_TYPE_LAG,
 *         CLX_PORT_TYPE_MPLS* or CLX_PORT_TYPE_CPU_PORT.
 *      2. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *         Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *         Setting port-based only, seg0 = seg1 = invalid value.
 */
CLX_ERROR_NO_T
clx_port_addSegService(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const UI32_T                seg0,
    const UI32_T                seg1,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   clx_port_delSegService
 * PURPOSE:
 *      This API is used to del a port seg service
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 *      seg0                -- segment parameter 0
 *      seg1                -- segment parameter 1
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Not allow setting port with CLX_PORT_TYPE_LAG,
 *         CLX_PORT_TYPE_MPLS* or CLX_PORT_TYPE_CPU_PORT.
 *      2. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *         Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *         Setting port-based only, seg0 = seg1 = invalid value.
 */
CLX_ERROR_NO_T
clx_port_delSegService(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        seg0,
    const UI32_T        seg1);

/* FUNCTION NAME:   clx_port_getSegService
 * PURPOSE:
 *      This API is used to get a port seg service
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 *      seg0                -- segment parameter 0
 *      seg1                -- segment parameter 1
 * OUTPUT:
 *      ptr_seg_srv         -- segment service
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Not allow setting port with CLX_PORT_TYPE_LAG,
 *         CLX_PORT_TYPE_MPLS* or CLX_PORT_TYPE_CPU_PORT.
 *      2. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *         Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *         Setting port-based only, seg0 = seg1 = invalid value.
 */
CLX_ERROR_NO_T
clx_port_getSegService(
    const UI32_T          unit,
    const CLX_PORT_T      port,
    const UI32_T          seg0,
    const UI32_T          seg1,
    CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   clx_port_setProperty
 * PURPOSE:
 *      Set Port property.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      property            -- Property type
 *      param0              -- First parameter
 *      param1              -- Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_port_setProperty(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_PROPERTY_T    property,
    const UI32_T                 param0,
    const UI32_T                 param1);

/* FUNCTION NAME:   clx_port_getProperty
 * PURPOSE:
 *      Get port property.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      property            -- Property type
 * OUTPUT:
 *      *ptr_param0         -- Ptr of first parameter
 *      *ptr_param1         -- Ptr of second parameter
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */

CLX_ERROR_NO_T
clx_port_getProperty(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_PROPERTY_T    property,
    UI32_T                       *ptr_param0,
    UI32_T                       *ptr_param1);

/* FUNCTION NAME:   clx_port_setLaneMap
 * PURPOSE:
 *      This API is used to set the mapping between unit/port and eth-macro/lane
 *      number.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      eth_macro           -- physical ETH macro ID
 *      lane                -- Physical lane ID
 *      max_speed           -- The maximum speed of the physical port
 *      flags               -- Attributes of the physical port and refer to CLX_PORT_FLAGS_XXX
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      This API is suggested to be used during SDK initialization.
 *
 */
CLX_ERROR_NO_T
clx_port_setLaneMap(
    const UI32_T              unit,
    const UI32_T              port,
    const UI32_T              eth_macro,
    const UI32_T              lane,
    const CLX_PORT_SPEED_T    max_speed,
    const UI32_T              flags);

/* FUNCTION NAME:   clx_port_getLaneMap
 * PURPOSE:
 *      This API is used to get the mapping between unit/port and eth-macro/lane
 *      number.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_eth_macro       -- physical ETH macro ID
 *      ptr_lane            -- Physical lane ID
 *      ptr_max_speed       -- The maximum speed of the physical port
 *      ptr_flags           -- Attributes of the physical port and refer to CLX_PORT_FLAGS_XXX
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_port_getLaneMap(
    const UI32_T        unit,
    const UI32_T        port,
    UI32_T              *ptr_eth_macro,
    UI32_T              *ptr_lane,
    CLX_PORT_SPEED_T    *ptr_max_speed,
    UI32_T              *ptr_flags);

/* FUNCTION NAME:   clx_port_createPort
 * PURPOSE:
 *      This API is used to create a UNIT_PORT object
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_port            -- The pointer of the UNIT_PORT
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_createPort(
    const UI32_T    unit,
    const UI32_T    port,
    CLX_PORT_T      *ptr_port);

/* FUNCTION NAME:   clx_port_destroyPort
 * PURPOSE:
 *      This API is used to destroy a UNIT_PORT object
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- UNIT_PORT object
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_destroyPort(
    const UI32_T    unit,
    CLX_PORT_T      port);

/* FUNCTION NAME:   clx_port_getPort
 * PURPOSE:
 *      This API is used to get UNIT_PORT object port from port.
 * INPUT:
 *      unit -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_port            -- The pointer of the UNIT_PORT
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_getPort(
    const UI32_T    unit,
    const UI32_T    port,
    CLX_PORT_T      *ptr_port);

/* FUNCTION NAME:   clx_port_setIntfProperty
 * PURPOSE:
 *      This API is used to set the properties for a specific interface object
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 *      ptr_property        -- The pointer of the interface properties
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_setIntfProperty(
    const UI32_T                      unit,
    const CLX_PORT_T                  port,
    const CLX_PORT_INTF_PROPERTY_T    *ptr_property);

/* FUNCTION NAME:   clx_port_getIntfProperty
 * PURPOSE:
 *      This API is used to get the properties for a specific interface object
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 * OUTPUT:
 *      ptr_property        -- The pointer of the interface properties
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_getIntfProperty(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    CLX_PORT_INTF_PROPERTY_T    *ptr_property);

/* FUNCTION NAME:   clx_port_getTsTxEntry
 * PURPOSE:
 *      This API is used to get port tx time stamp entry information.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ts_entry        -- Time stamp entry information
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_getTsTxEntry(
    const UI32_T           unit,
    const UI32_T           port,
    CLX_PORT_TS_ENTRY_T    *ptr_ts_entry);

/* FUNCTION NAME:   clx_port_getTsRxEntry
 * PURPOSE:
 *      This API is used to get port rx time stamp entry information.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ts_entry        -- Time stamp entry information
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_getTsRxEntry(
    const UI32_T           unit,
    const UI32_T           port,
    CLX_PORT_TS_ENTRY_T    *ptr_ts_entry);

/* FUNCTION NAME:   clx_port_getPortType
 * PURPOSE:
 *      Get port type.
 *      It is used to lookup corresponding database to get its key.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 * OUTPUT:
 *      ptr_type            -- type of CLX_PORT_TYPE_T
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_getPortType(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    CLX_PORT_TYPE_T     *ptr_type);

/* FUNCTION NAME:   clx_port_setPrbsPattern
 * PURPOSE:
 *      This API is used to set prbs for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      prbs_pattern        -- PRBS pattern
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_setPrbsPattern(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_PORT_PRBS_PATTERN_T       prbs_pattern);

/* FUNCTION NAME:   clx_port_getPrbsPattern
 * PURPOSE:
 *      Get the PRBS test pattern
 * INPUT:
 *      unit             -- Device unit number
 *      port             -- Device port number
 * OUTPUT:
 *      ptr_prbs_pattern -- Test pattern on PRBS
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
clx_port_getPrbsPattern(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_PORT_PRBS_PATTERN_T             *ptr_prbs_pattern);

/* FUNCTION NAME:   clx_port_setPrbsChecker
 * PURPOSE:
 *      Enable/disable the PRBS test checker
 * INPUT:
 *      unit             -- Device unit number
 *      port             -- Device port number
 *      prbs_checker     -- Enable/Disable checker
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
clx_port_setPrbsChecker(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_PORT_PRBS_CHECKER_T       prbs_checker);

/* FUNCTION NAME:   clx_port_getPrbsChecker
 * PURPOSE:
 *      Get the PRBS test checker status (enable/disable)
 * INPUT:
 *      unit             -- Device unit number
 *      port             -- Device port number
 * OUTPUT:
 *      ptr_prbs_checker -- Test checker status (enable/disable)
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
clx_port_getPrbsChecker(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_PORT_PRBS_CHECKER_T             *ptr_prbs_checker);

/* FUNCTION NAME:   clx_port_getPrbsErrorCnt
 * PURPOSE:
 *      Get the PRBS checker error count
 * INPUT:
 *      unit             -- Device unit number
 *      port             -- Device port number
 * OUTPUT:
 *      ptr_error_cnt    -- Error bit counter
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
clx_port_getPrbsErrorCnt(
    const UI32_T                        unit,
    const UI32_T                        port,
    UI32_T                              *ptr_error_cnt);

/* FUNCTION NAME:   clx_port_dumpEyeScan
 * PURPOSE:
 *      This API is used to dump eys scan for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      lane_cnt            -- Lane count
 *      eyc_scan            -- Eye scan type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_dumpEyeScan(
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    lane_cnt,
    const CLX_PORT_EYE_SCAN_T       eyc_scan);

/* FUNCTION NAME:   clx_port_setMdioReg
 * PURPOSE:
 *      This API is used to set mdio register for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      phy_type            -- PHY type
 *      dev_addr            -- PHY device address
 *      reg_addr            -- Register address
 *      reg_data            -- Register data
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_setMdioReg(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_PHY_TYPE_T    phy_type,
    const UI32_T            dev_addr,
    const UI32_T            reg_addr,
    const UI32_T            reg_data);

/* FUNCTION NAME:   clx_port_getMdioReg
 * PURPOSE:
 *      This API is used to get mdio register for a specific port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      phy_type            -- PHY type
 *      dev_addr            -- PHY device address
 *      reg_addr            -- Register address
 * OUTPUT:
 *      ptr_data            -- Register data
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_port_getMdioReg(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_PHY_TYPE_T    phy_type,
    const UI32_T            dev_addr,
    const UI32_T            reg_addr,
    UI32_T                  *ptr_data);

/* FUNCTION NAME:   clx_port_getStatus
 * PURPOSE:
 *      Get the status per physical port.
 * INPUT:
 *      unit       -- Device unit number
 *      port       -- Physical port id
 * OUTPUT:
 *      ptr_status -- Port status
 *                    speed  - reference to CLX_PORT_SPEED_T
 *                    link   - reference to CLX_PORT_LINK_XXX
 *                    fault  - reference to CLX_PORT_FAULT_XXX
 *                    rx_fc  - reference to CLX_PORT_FC_STATUS_XXX
 *                    rx_pfc - reference to CLX_PORT_FC_STATUS_XXX
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      There is 8 bits for 8 RX priority flow control status in rx_pfc.
 *      RX flow control status for priority x (x = 0~7) =
 *      rx_pfc & (CLX_PORT_FC_STATUS_ON << x)
 */
CLX_ERROR_NO_T
clx_port_getStatus(
    const UI32_T         unit,
    const UI32_T         port,
    CLX_PORT_STATUS_T    *ptr_status);

/* FUNCTION NAME:   clx_port_setTxCoef
 * PURPOSE:
 *      This API is used to set the TX coefficients for a specific lane
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      lane_idx            -- Lane number
 *      location            -- PHY location
 *      ptr_tx_coef         -- TX coefficient types and values
 * OUTPUT:
 *        None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_port_setTxCoef(
    const UI32_T                     unit,
    const UI32_T                     port,
    const UI32_T                     lane_idx,
    const CLX_PORT_PHY_LOCATION_T    location,
    CLX_PORT_TX_COEF_T               *ptr_tx_coef);

/* FUNCTION NAME:   clx_port_getTxCoef
 * PURPOSE:
 *      This API is used to get the TX coefficients for a specific lane
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      lane_idx            -- Lane number
 *      location            -- PHY location
 * OUTPUT:
 *      ptr_tx_coef         -- TX coefficient types and values
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_port_getTxCoef(
    const UI32_T                     unit,
    const UI32_T                     port,
    const UI32_T                     lane_idx,
    const CLX_PORT_PHY_LOCATION_T    location,
    CLX_PORT_TX_COEF_T               *ptr_tx_coef);

CLX_ERROR_NO_T
clx_port_getAutoNegEn(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_PORT_AUTO_NEG_TYPE_T        *an_en);

CLX_ERROR_NO_T
clx_port_setAutoNegEn(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_AUTO_NEG_TYPE_T  enable);

CLX_ERROR_NO_T
clx_port_getLinkTrngEn(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_PORT_LINK_TRAINING_T        *enable);

CLX_ERROR_NO_T
clx_port_setLinkTrngEn(
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    enable);

CLX_ERROR_NO_T
clx_port_getLinkTrngFailStatus(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_PORT_LINK_TRAINING_FAIL_T       *status);

CLX_ERROR_NO_T
clx_port_setPrbsGenerator(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_PRBS_CONFIG_T    config);

CLX_ERROR_NO_T
clx_port_getFecCnt(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_FEC_CNT_TYPE_T   fec_type,
    UI32_T                          *counters);

CLX_ERROR_NO_T
clx_port_setAdvertisedIntfType(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        intf_type);
#endif /* End of CLX_PORT_H */
