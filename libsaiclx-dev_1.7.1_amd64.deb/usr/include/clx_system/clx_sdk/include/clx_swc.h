/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_swc.h
 * PURPOSE:
 *      It provides switch control module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_SWC_H
#define CLX_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_tm.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum
{
    CLX_SWC_PROPERTY_IPV4_HDR_ERROR,
    CLX_SWC_PROPERTY_IPV6_HDR_ERROR,
    CLX_SWC_PROPERTY_GLOBAL_ROUTE_MISS_ACTION,
    CLX_SWC_PROPERTY_L2_AGING_TIME,
    CLX_SWC_PROPERTY_PENDING_LEARN,
    CLX_SWC_PROPERTY_ICMP_REDIRECT,
    CLX_SWC_PROPERTY_L3_SELF_FORWARD,
    CLX_SWC_PROPERTY_L3_URPF,
    CLX_SWC_PROPERTY_L3_MCAST_ADDR_VALIDATE,
    CLX_SWC_PROPERTY_VXLAN_ROUTER_ALERT,
    CLX_SWC_PROPERTY_VXLAN_UDP_PORT,
    CLX_SWC_PROPERTY_NVGRE_ROUTER_ALERT,
    CLX_SWC_PROPERTY_NIV_SRC_VIF,
    CLX_SWC_PROPERTY_VM_FCOE_TRANS_MODE,
    CLX_SWC_PROPERTY_MIR_ERSPAN_MISS_ACTION,
    CLX_SWC_PROPERTY_MIR_METER_LAYER,
    CLX_SWC_PROPERTY_STORM_CTRL_METER_LAYER,
    CLX_SWC_PROPERTY_STORM_CTRL_CTRL_PKT_CHECK,
    CLX_SWC_PROPERTY_SOURCE_GUARD_DHCP_PKT_CHECK,
    CLX_SWC_PROPERTY_FCOE_CLV_SWITCH_ENABLE,
    CLX_SWC_PROPERTY_FCOE_DROP_UNKNOWN_MAC,
    CLX_SWC_PROPERTY_STEERING_EN,
    /* exceptions, param0 is CLX_FWD_ACTION_T */
    CLX_SWC_PROPERTY_L2_SA_MOVE_ACTION,
    CLX_SWC_PROPERTY_L3_IPV4_MC_MISS_ACTION,
    CLX_SWC_PROPERTY_L3_IPV6_MC_MISS_ACTION,
    CLX_SWC_PROPERTY_L3_IPV4_OPT_HDR_ACTION,
    CLX_SWC_PROPERTY_L3_IPV6_OPT_HDR_ACTION,
    CLX_SWC_PROPERTY_L3_IGR_MTU_FAIL_ACTION,
    CLX_SWC_PROPERTY_L3_EGR_MTU_FAIL_ACTION,
    CLX_SWC_PROPERTY_L3_TTL0_ACTION,
    CLX_SWC_PROPERTY_L3_IGR_TTL1_ACTION, /* Only for L3 ucast */
    CLX_SWC_PROPERTY_L3_EGR_TTL1_ACTION,
    CLX_SWC_PROPERTY_L3T_TTL0_ACTION,
    CLX_SWC_PROPERTY_L3T_TTL1_ACTION,
    /* Configure the weighted SW mode ECMP block size */
    CLX_SWC_PROPERTY_L3_ECMP_BLOCK_SIZE,
    CLX_SWC_PROPERTY_KEEP_DEI,
    /* Configure the latency threshold to sample high latency packets for sflow. */
    /*  param0 is below values: */
    /*  0:disable, 512ns,    1024ns,    2048ns,    4096ns,   8192ns,*/
    /*  16384ns,   32768ns,   65536ns,   131072ns,  262144ns,       */
    /*  524288ns,  1048576ns, 2097152ns, 4194304ns, 8388608ns       */
    CLX_SWC_PROPERTY_SAMPLE_HIGH_LATENCY_THRESHOLD,
    CLX_SWC_PROPERTY_DTEL_IFA_MIR_ID,
    CLX_SWC_PROPERTY_DTEL_IFA_STEER_MIR,
    CLX_SWC_PROPERTY_DTEL_IOAM_COPY_TO_CPU,
    CLX_SWC_PROPERTY_DTEL_IOAM_LOOPBACK_TO_CPU,
    CLX_SWC_PROPERTY_DTEL_IOAM_EXCEPTION_TO_CPU,
    /* Configure whether tm traffic type is determined by inner or outer header */
    CLX_SWC_PROPERTY_ECN_REMARK_USE_INNER_TCP,
    CLX_SWC_PROPERTY_L3T_LINK_LOCAL_ACTION,
    CLX_SWC_PROPERTY_DTEL_IFA_ENABLE,
    CLX_SWC_PROPERTY_DTEL_DPP_ENABLE,
    CLX_SWC_PROPERTY_LAST
}CLX_SWC_PROPERTY_T;

typedef enum
{
    /*nvo3 key*/
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_OUTER_VID,
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_INNER_VID,
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_ETHERTYPE,
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_DMAC,
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_SMAC,
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_MAC_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_FLOW_LABEL,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_NEXT_HEADER,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_DIP,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_SIP,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_IP_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_DPORT,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_SPORT,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_PORT_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_PROTOCOL,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_DIP,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_SIP,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_IP_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_DPORT,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_SPORT,
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_PORT_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_TRILL_FGL,
    CLX_SWC_HASH_KEY_TYPE_TRILL_VL,
    CLX_SWC_HASH_KEY_TYPE_TRILL_EGR_RN,
    CLX_SWC_HASH_KEY_TYPE_TRILL_IGR_RN,
    CLX_SWC_HASH_KEY_TYPE_TRILL_RN_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV6,
    CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV4,
    CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV4,
    CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV6,
    CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV4,
    CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV6,
    CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV4,
    CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV6,
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL0,
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL1,
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL2,
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL3,
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL4,
    CLX_SWC_HASH_KEY_TYPE_NSH_SRV_IDX,
    CLX_SWC_HASH_KEY_TYPE_NSH_SRV_PATH,
    /*srv key*/
    CLX_SWC_HASH_KEY_TYPE_VNTAG_SVMID,
    CLX_SWC_HASH_KEY_TYPE_VNTAG_DVMID,
    CLX_SWC_HASH_KEY_TYPE_ETAG_SVMID,
    CLX_SWC_HASH_KEY_TYPE_ETAG_DVMID,
    CLX_SWC_HASH_KEY_TYPE_VEPA_SVID,
    CLX_SWC_HASH_KEY_TYPE_L2_OUTER_VID,
    CLX_SWC_HASH_KEY_TYPE_L2_INNER_VID,
    CLX_SWC_HASH_KEY_TYPE_L2_ETHERTYPE,
    CLX_SWC_HASH_KEY_TYPE_L2_DMAC,
    CLX_SWC_HASH_KEY_TYPE_L2_SMAC,
    CLX_SWC_HASH_KEY_TYPE_L2_MAC_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_IPV6_FLOW_LABEL,
    CLX_SWC_HASH_KEY_TYPE_IPV6_NEXT_HEADER,
    CLX_SWC_HASH_KEY_TYPE_IPV6_DIP,
    CLX_SWC_HASH_KEY_TYPE_IPV6_SIP,
    CLX_SWC_HASH_KEY_TYPE_IPV6_IP_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_DPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_SPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_PORT_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_DPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_SPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_PORT_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_DPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_SPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_PORT_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_IPV4_PROTOCOL,
    CLX_SWC_HASH_KEY_TYPE_IPV4_DIP,
    CLX_SWC_HASH_KEY_TYPE_IPV4_SIP,
    CLX_SWC_HASH_KEY_TYPE_IPV4_IP_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_DPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_SPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_PORT_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_DPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_SPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_PORT_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_DPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_SPORT,
    CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_PORT_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_FCOE_VFID,
    CLX_SWC_HASH_KEY_TYPE_FCOE_SEQID,
    CLX_SWC_HASH_KEY_TYPE_FCOE_DID,
    CLX_SWC_HASH_KEY_TYPE_FCOE_SID,
    CLX_SWC_HASH_KEY_TYPE_FCOE_ID_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_FCOE_RXID,
    CLX_SWC_HASH_KEY_TYPE_FCOE_OXID,
    CLX_SWC_HASH_KEY_TYPE_FCOE_XID_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL0,
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL1,
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL2,
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL3,
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL4,
    CLX_SWC_HASH_KEY_TYPE_IGR_PORT,
    CLX_SWC_HASH_KEY_TYPE_EGR_PORT,
    CLX_SWC_HASH_KEY_TYPE_L2,
    CLX_SWC_HASH_KEY_TYPE_L3,
    CLX_SWC_HASH_KEY_TYPE_VM_TUNNEL,
    CLX_SWC_HASH_KEY_TYPE_USE_INNER,
    CLX_SWC_HASH_KEY_TYPE_COMPRESS_IP,
    CLX_SWC_HASH_KEY_TYPE_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_LAST
}CLX_SWC_HASH_KEY_TYPE_T;

typedef enum
{
    CLX_SWC_RSRC_L2_UC_ADDR = 0,
    CLX_SWC_RSRC_L3_ECMP_GROUP,
    CLX_SWC_RSRC_L3_ECMP_PATH,
    CLX_SWC_RSRC_L3_ECMP_HASH,
    CLX_SWC_RSRC_L3_INTF,
    CLX_SWC_RSRC_L3_ADJ,
    CLX_SWC_RSRC_L3_ROUTER_MAC,
    CLX_SWC_RSRC_L3_HOST,
    CLX_SWC_RSRC_L3_ROUTE,
    CLX_SWC_RSRC_ACL_INGRESS_UCP,
    CLX_SWC_RSRC_ACL_INGRESS_GROUP_ENTRY,
    CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE,
    CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE_LOU,
    CLX_SWC_RSRC_ACL_EGRESS_UCP,
    CLX_SWC_RSRC_ACL_EGRESS_GROUP_ENTRY,
    CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE,
    CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE_LOU,
    CLX_SWC_RSRC_LAG_GROUP,
    CLX_SWC_RSRC_VLAN_BDID,
    CLX_SWC_RSRC_LAST
}CLX_SWC_RSRC_T;

typedef struct CLX_SWC_STEERING_ENTRY_S{
    UI32_T              hdr_size;           /*maximum bytes(0~63); 0 means 64 bytes*/
#define CLX_SWC_FLAGS_STEERING_HDR_EN       (0x1<<0)
#define CLX_SWC_FLAGS_STEERING_HDR_UDP_EN   (0x1<<1)
    UI32_T              flags;
    UI32_T              port;
    CLX_TM_HANDLER_T    handler;
    UI32_T              tc;
    UI32_T              color;
    UI32_T              hdr[16];
    UI32_T              vid_num;
    UI32_T              ipv4_tlen_bidx;      /*ipv4 total length byte index*/
    UI16_T              ipv4_checksum;
    UI32_T              ipv6_plen_bidx;      /*ipv6 payload length byte index*/
}CLX_SWC_STEERING_ENTRY_T;

#define CLX_SWC_HASH_KEY_NUM                    (CLX_SWC_HASH_KEY_TYPE_LAST)
#define CLX_SWC_HASH_KEY_WORD_WIDTH             (32)
#define CLX_SWC_HASH_KEY_BITMAP_SIZE            (((CLX_SWC_HASH_KEY_NUM-1)/CLX_SWC_HASH_KEY_WORD_WIDTH )+1)

typedef UI32_T CLX_SWC_HASH_KEY_BITMAP_T[CLX_SWC_HASH_KEY_BITMAP_SIZE];

#define CLX_SWC_SET_HASHKEYBIT(key_bitmap, hash_key)   \
    (((UI32_T *)key_bitmap)[hash_key/CLX_SWC_HASH_KEY_WORD_WIDTH] |= (0x1UL << (hash_key%CLX_SWC_HASH_KEY_WORD_WIDTH)))
#define CLX_SWC_CLEAR_HASHKEYBIT(key_bitmap, hash_key) \
    (((UI32_T *)key_bitmap)[hash_key/CLX_SWC_HASH_KEY_WORD_WIDTH] &= ~(0x1UL << (hash_key%CLX_SWC_HASH_KEY_WORD_WIDTH)))
#define CLX_SWC_CHK_HASHKEYBIT(key_bitmap, hash_key)   \
    (((UI32_T *)key_bitmap)[hash_key/CLX_SWC_HASH_KEY_WORD_WIDTH] &  (0x1UL << (hash_key%CLX_SWC_HASH_KEY_WORD_WIDTH)))

typedef enum
{
    CLX_SWC_HASH_TYPE_ECMP_L3,              /*For egress path is normal l3 flow*/
    CLX_SWC_HASH_TYPE_ECMP_NVO3,            /*For egress path is nvo3 flow*/
    CLX_SWC_HASH_TYPE_LAG,                  /*LAG loading balance*/
    CLX_SWC_HASH_TYPE_LAG_FABRIC,           /*LAG loading balance for fabric port selection*/
    CLX_SWC_HASH_TYPE_VXLAN_UDP_SRC_PORT,   /*UDP header UDP source port generation for VXLAN tunnel initiation*/
    CLX_SWC_HASH_TYPE_NVGRE_FLOW_ID,        /*NVGRE header flow ID generation for NVGRE tunnel initiation*/
    CLX_SWC_HASH_TYPE_L3T_IPV6_FLOW_LABEL,  /*IPv6 header flow label generation for IPv6 tunnel initiation*/
    CLX_SWC_HASH_TYPE_MPLS_ENTROPY_LABEL,   /*MPLS header entrypylable generation for tunnel initiation*/
    CLX_SWC_HASH_TYPE_MPLS_FLOW_LABEL,      /*MPLS header label generation for tunnel initiation*/
    CLX_SWC_HASH_TYPE_LAST
}CLX_SWC_HASH_TYPE_T;

typedef enum
{
    CLX_SWC_ERROR_SRC_ECC = 0,
    CLX_SWC_ERROR_SRC_LAST,
} CLX_SWC_ERROR_SRC_T;

typedef enum
{
    CLX_SWC_ECC_NON_CORRECTABLE = 0,
    CLX_SWC_ECC_CORRECTED,
} CLX_SWC_ECC_CORRECTION_T;

#define CLX_SWC_ECC_ERROR_INFO_INVALID_HUB         (0xFFFFFFFF)
#define CLX_SWC_ECC_ERROR_INFO_INVALID_MEMORY      (0xFFFFFFFF)
#define CLX_SWC_ECC_ERROR_INFO_INVALID_TABLE_ID    (0xFFFFFFFF)

typedef struct
{
    UI32_T                      hub;         /* invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_HUB */
    UI32_T                      memory;      /* invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_MEMORY */
    UI32_T                      single_error_addr;
    UI32_T                      double_error_addr;

    UI32_T                      inst;
    UI32_T                      sub_inst;
    UI32_T                      table_id;    /* invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_TABLE_ID */
    UI32_T                      single_error_table_entry_start;
    UI32_T                      single_error_table_entry_end;
    UI32_T                      double_error_table_entry_start;
    UI32_T                      double_error_table_entry_end;

    UI32_T                      single_error_cnt;
    UI32_T                      double_error_cnt;

    CLX_SWC_ECC_CORRECTION_T    single_error_correction;
    CLX_SWC_ECC_CORRECTION_T    double_error_correction;
} CLX_SWC_ERROR_INFO_ECC_T;

typedef struct
{
    union
    {
        CLX_SWC_ERROR_INFO_ECC_T    ecc_info;
    };
} CLX_SWC_ERROR_INFO_T;

typedef void
(*CLX_SWC_ERROR_FUNC_T)(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_INFO_T    *ptr_error_info,
    void                          *ptr_cookie);

typedef struct CLX_SWC_DEVICE_INFO_S
{
    UI32_T vendor_id;
    UI32_T device_id;
    UI32_T revision_id;
}CLX_SWC_DEVICE_INFO_T;

typedef struct CLX_SWC_PORT_CONFIG_S
{
    CLX_PORT_BITMAP_T       bitmap_all;        /* include active, inactive eth, mxlink, cpu, and cpi ports */
    CLX_PORT_BITMAP_T       bitmap_active;     /* include active eth, mxlink, cpu, and cpi ports */
    CLX_PORT_BITMAP_T       bitmap_mxlink;     /* active mxlink ports */
    CLX_PORT_BITMAP_T       bitmap_breakout;   /* active breakout ports */
    CLX_PORT_BITMAP_T       bitmap_cpu;        /* active cpu ports */
    CLX_PORT_BITMAP_T       bitmap_cpi;        /* active cpi ports */
    CLX_PORT_BITMAP_T       bitmap_rcp;        /* active recirculation ports */
    CLX_PORT_BITMAP_T       bitmap_1g;         /* active 1g ports */
    CLX_PORT_BITMAP_T       bitmap_10g;        /* active 10g ports */
    CLX_PORT_BITMAP_T       bitmap_25g;        /* active 25g ports */
    CLX_PORT_BITMAP_T       bitmap_40g;        /* active 40g ports */
    CLX_PORT_BITMAP_T       bitmap_50g;        /* active 50g ports */
    CLX_PORT_BITMAP_T       bitmap_100g;       /* active 100g ports */
    CLX_PORT_BITMAP_T       bitmap_200g;       /* active 200g ports */
    CLX_PORT_BITMAP_T       bitmap_400g;       /* active 400g ports */
} CLX_SWC_PORT_CONFIG_T;

typedef enum
{
    CLX_SWC_CSO_MODE_SLAVE = 0,
    CLX_SWC_CSO_MODE_MASTER,
    CLX_SWC_CSO_MODE_LAST
} CLX_SWC_CSO_MODE_T;

typedef struct CLX_SWC_CPI_ENCAP_HDR_S{
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_EN                  (0x1<<0)
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN           (0x1<<1) /* if set, use udp_source_port*/
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_CPU_QUEUE_EN     (0x1<<2) /* if set, CPI queue will be encoded in UDP source port.
                                                                  * invalid when flag CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN
                                                                  * is set.*/
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_PORT_EN          (0x1<<3) /* if set, ingress port or egress port will be encoded in
                                                                  * UDP source port. Invalid when flag
                                                                  * CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN is set.*/
    UI32_T              flags;
    UI32_T              encap_size;                              /* 0: no encap*/
    UI8_T               hdr[64];
    UI32_T              ipv4_tlen_bidx;                          /* IPv4 total length byte index*/
    UI16_T              ipv4_checksum;                           /* IPv4 checksum with total length of 0*/
    UI16_T              udp_source_port;                         /* UDP header source port value*/
}CLX_SWC_CPI_ENCAP_HDR_T;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* FUNCTION NAME:   clx_swc_setHashKey
 * PURPOSE:
 *      Set switch control hash keys.
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash type
 *      key_bitmap          -- Hash key bitmap
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setHashKey(
    const UI32_T                    unit,
    const CLX_SWC_HASH_TYPE_T       hash_type,
    const CLX_SWC_HASH_KEY_BITMAP_T key_bitmap);

/* FUNCTION NAME:   clx_swc_getHashKey
 * PURPOSE:
 *      Get switch control hash keys.
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash type
 * OUTPUT:
 *      *ptr_key_bitmap     -- Hash key bitmap
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getHashKey(
    const UI32_T                    unit,
    const CLX_SWC_HASH_TYPE_T       hash_type,
    CLX_SWC_HASH_KEY_BITMAP_T       *ptr_key_bitmap);

/* FUNCTION NAME:   clx_swc_setProperty
 * PURPOSE:
 *      Set switch control property.
 * INPUT:
 *      unit                -- Device unit number
 *      property            -- Property type
 *      param0              -- First parameter
 *      param1              -- Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setProperty(
    const UI32_T                    unit,
    const CLX_SWC_PROPERTY_T        property,
    const UI32_T                    param0,
    const UI32_T                    param1);

/* FUNCTION NAME:   clx_swc_getProperty
 * PURPOSE:
 *      Get switch control property.
 * INPUT:
 *      unit                -- Device unit number
 *      property            -- Property type
 * OUTPUT:
 *      *ptr_param0         -- Ptr of first parameter
 *      *ptr_param1         -- Ptr of second parameter
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */

CLX_ERROR_NO_T
clx_swc_getProperty(
    const UI32_T                    unit,
    const CLX_SWC_PROPERTY_T        property,
    UI32_T                          *ptr_param0,
    UI32_T                          *ptr_param1);

/* FUNCTION NAME:   clx_swc_setTsValue
 * PURPOSE:
 *      Set timestamp value of system.
 * INPUT:
 *      unit                --  Chip id
 *      sec_hi              --  Bit[47:32] seconds for timestamp
 *      sec_low             --  Bit[31:0]  seconds for timestamp
 *      nsec                --  Bit[29:0]  nano seconds for timestamp
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_swc_setTsValue(
    const UI32_T                unit,
    UI16_T                      sec_hi,
    UI32_T                      sec_low,
    UI32_T                      nsec);

/* FUNCTION NAME:   clx_swc_getTsValue
 * PURPOSE:
 *      Get timestamp value of system.
 * INPUT:
 *      unit                --  Chip id
 * OUTPUT:
 *      ptr_sec_hi          --  Bit[47:32] seconds for timestamp
 *      ptr_sec_low         --  Bit[31:0]  seconds for timestamp
 *      ptr_nsec            --  Bit[29:0]  nano seconds for timestamp
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_swc_getTsValue(
    const UI32_T                unit,
    UI16_T                      *ptr_sec_hi,
    UI32_T                      *ptr_sec_low,
    UI32_T                      *ptr_nsec);

/* FUNCTION NAME:   clx_swc_setTsOffset
 * PURPOSE:
 *      Set timestamp offset.
 * INPUT:
 *      unit                --  Chip id
 *      nsec                --  Signed nano seconds for timestamp offset
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_swc_setTsOffset(
    const UI32_T                unit,
    const I32_T                 nsec);

/* FUNCTION NAME:   clx_swc_setSteering
 * PURPOSE:
 *      Set the configuration of egress view of steering.
 * INPUT:
 *      unit                -- Device unit number
 *      *ptr_str_entry      -- Structure of egress steering
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setSteering(
    const UI32_T                    unit,
    const CLX_SWC_STEERING_ENTRY_T  *ptr_str_entry);

/* FUNCTION NAME:   clx_swc_getSteering
 * PURPOSE:
 *      Get the configuration of egress view of steering.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      *ptr_str_entry      -- Setting of egress steering
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getSteering(
    const UI32_T                    unit,
    CLX_SWC_STEERING_ENTRY_T        *ptr_str_entry);

/* FUNCTION NAME:   clx_swc_setHashConstant
 * PURPOSE:
 *      Set hash engine polynomial coefficients
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      count               -- Size (number of elements) of array pointed by ptr_hash_const
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHER         -- Config fail
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
clx_swc_setHashConstant(
    const UI32_T              unit,
    const CLX_SWC_HASH_TYPE_T hash_type,
    const UI32_T              count,
    const UI32_T              *ptr_hash_const);

/* FUNCTION NAME:   clx_swc_getHashConstant
 * PURPOSE:
 *      Get hash engine polynomial coefficients
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      count               -- Size (number of elements) of array pointed by ptr_hash_const
 *
 * OUTPUT:
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
clx_swc_getHashConstant(
    const UI32_T              unit,
    const CLX_SWC_HASH_TYPE_T hash_type,
    const UI32_T              count,
    UI32_T                    *ptr_hash_const);

/* FUNCTION NAME:   clx_swc_setHashConstantByKey
 * PURPOSE:
 *      Set hash engine polynomial coefficients by a specific key field
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      key                 -- Hash key of interest
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHER         -- Config fail
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
clx_swc_setHashConstantByKey(
    const UI32_T                  unit,
    const CLX_SWC_HASH_TYPE_T     hash_type,
    const CLX_SWC_HASH_KEY_TYPE_T key,
    const UI32_T                  *ptr_hash_const);

/* FUNCTION NAME:   clx_swc_getHashConstantByKey
 * PURPOSE:
 *      Get hash engine polynomial coefficients by a specific key field
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      key                 -- Hash key of interest
 *
 * OUTPUT:
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
clx_swc_getHashConstantByKey(
    const UI32_T                  unit,
    const CLX_SWC_HASH_TYPE_T     hash_type,
    const CLX_SWC_HASH_KEY_TYPE_T key,
    UI32_T                        *ptr_hash_const);

/* FUNCTION NAME:   clx_swc_registerErrorCallback
 * PURPOSE:
 *      Register error callback function.
 * INPUT:
 *      unit                -- Device unit number
 *      error               -- error source type
 *      callback            -- The callback function of type CLX_SWC_ERROR_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_registerErrorCallback(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_SRC_T     error,
    const CLX_SWC_ERROR_FUNC_T    callback,
    void                          *ptr_cookie);

/* FUNCTION NAME:   clx_swc_deregisterErrorCallback
 * PURPOSE:
 *      Deregister error callback function.
 * INPUT:
 *      unit                -- Device unit number
 *      error               -- error source type
 *      callback            -- The callback function of type CLX_SWC_ERROR_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_deregisterErrorCallback(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_SRC_T     error,
    const CLX_SWC_ERROR_FUNC_T    callback,
    void                          *ptr_cookie);

/* FUNCTION NAME:   clx_swc_getDeviceInfo
 * PURPOSE:
 *      Get device information.
 * INPUT:
 *      unit                -- Device unit number
 *
 * OUTPUT:
 *      ptr_device_info     -- The device information
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_swc_getDeviceInfo(
    const UI32_T                unit,
    CLX_SWC_DEVICE_INFO_T       *ptr_device_info);

/* FUNCTION NAME:   clx_swc_getPortConfig
 * PURPOSE:
 *      Get port bitmap of current config.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      ptr_port_config     -- Port bitmaps of current config
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_swc_getPortConfig(
    const UI32_T        unit,
    CLX_SWC_PORT_CONFIG_T   *ptr_port_config);

/* FUNCTION NAME:   clx_swc_getCapacity
 * PURPOSE:
 *      Get resource capacity
 * INPUT:
 *      unit            -- Device unit number
 *      type            -- Resource type
 *      param           -- Parameter if necessary
 * OUTPUT:
 *      ptr_size        -- Size of capacity
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getCapacity(
    const UI32_T unit,
    const CLX_SWC_RSRC_T type,
    const UI32_T param,
    UI32_T *ptr_size);

/* FUNCTION NAME:   clx_swc_getUsage
 * PURPOSE:
 *     Get resource usage.
 * INPUT:
 *      unit            -- Device unit number
 *      type            -- Resource type
 *      param           -- Parameter if necessary
 * OUTPUT:
 *      ptr_cnt         -- Count of usage
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getUsage(
    const UI32_T unit,
    const CLX_SWC_RSRC_T type,
    const UI32_T param,
    UI32_T *ptr_cnt);

/* FUNCTION NAME:   clx_swc_setCsoMode
 * PURPOSE:
 *      Set clock servo mode.
 * INPUT:
 *      unit                -- Device unit number
 *      mode                -- Clock servo mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setCsoMode(
    const UI32_T                unit,
    const CLX_SWC_CSO_MODE_T    mode);

/* FUNCTION NAME:   clx_swc_getCsoMode
 * PURPOSE:
 *      Get clock servo mode.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      ptr_mode            -- Clock servo mode
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getCsoMode(
    const UI32_T        unit,
    CLX_SWC_CSO_MODE_T  *ptr_mode);

/* FUNCTION NAME:   clx_swc_getChipTemperature
 * PURPOSE:
 *      Get chip temperature.
 * INPUT:
 *      unit                -- Device unit number.
 * OUTPUT:
 *      ptr_temperature     -- Chip temperature
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getChipTemperature(
    const UI32_T   unit,
    I32_T          *ptr_temperature);

/* FUNCTION NAME:   clx_swc_setCpiEncap
 * PURPOSE:
 *      Set CPI port enacp.
 * INPUT:
 *      unit                -- Device unit number.
 *      port                -- CPI port.
 *      ptr_encap_hdr       -- Structure of encap.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_NOT_SUPPORT   -- Not support.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setCpiEncap(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SWC_CPI_ENCAP_HDR_T   *ptr_encap_hdr);

/* FUNCTION NAME:   clx_swc_getCpiEncap
 * PURPOSE:
 *      Get CPI port enacp.
 * INPUT:
 *      unit                -- Device unit number.
 *      port                -- CPI port.
 * OUTPUT:
 *      ptr_encap_hdr       -- Structure of encap.
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_NOT_SUPPORT   -- Not support.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getCpiEncap(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SWC_CPI_ENCAP_HDR_T         *ptr_encap_hdr);

#endif
