#define CLNX_SAI_COMMIT_ID "aa4820baa5640f0ee0108ae017503eecd6dd3526"
#define CLNX_SAI_GIT_BRANCH "HEAD"
#define CLNX_SAI_BUILD_TIME "Mon Feb 28 12:39:17 UTC 2022"
#define CLNX_SDK_COMMIT_ID "2a632ef57bcf8c617e55684c6dfe54d04bbe8f11(remotes/origin/1.1.0)"
#define CLNX_SAI_BUILD_BY "zhoujd@27fc9658c0fd"
#define SAI_VERSION_CODE 67329
#define CLNX_SAI_HEAD_VERSION "1.7.1"
#define SAI_VER(a,b,c) (((a)<<16)+((b)<<8)+(c))
