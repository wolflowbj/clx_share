#if !defined (__CLNX_SDK_H_)
#define __CLNX_SDK_H_
#include <saitypes.h>
#include <clx_port.h>
#include <hal/common/hal_io.h>
#include <hal/common/hal.h>
#include <cmlib/cmlib_list.h>
#include <cmlib/cmlib_avl.h>
#include <cmlib/cmlib_bitmap.h>

#define CLNX_SAI_MAX_CHIP_NUM                (16)
#define CLNX_SAI_MAX_PORT_NUM                (CLX_PORT_NUM)
#define CLNX_SAI_MAX_PORT_MTU                (9216)
#ifdef CLX_EN_LIGHTNING
#define CLNX_CPU_PORT                        (256)
#else
#define CLNX_CPU_PORT                        (128)
#endif
#define CLNX_SAI_MAX_LAG_NUM                 (512)
#define CLNX_SAI_MAX_PORT_NUM_PER_LAG        (256)
#define CLNX_SAI_MAX_WRED_PROFILE_NUM        (32)
#define CLNX_SAI_MAX_STP_NUM                 (256)
#define CLNX_SAI_MAX_BRIDGE_PORT_NUM         (32768)
#define CLNX_SAI_MAX_VLAN_NUM                (4096)
#define CLNX_SAI_MAX_FDB_NUM                 (65536) /* default config */
#define CLNX_SAI_MAX_MCAST_FDB_NUM           (16384) /* default config */
#define CLNX_SAI_MAX_VRF_NUM                 (8 * 1024)
#define CLNX_SAI_MAX_NEIGHBOR_NUM            (96 * 1024)
#define CLNX_SAI_MAX_NEXTHOP_NUM            (96 * 1024)
#define CLNX_SAI_MAX_ROUTE_NUM               (48 * 1024)
#define CLNX_SAI_MAX_ECMP_PATH_NUM           (8 * 1024)
#define CLNX_SAI_MAX_ECMP_GROUP_NUM          (2 * 1024)
#define CLNX_SAI_MAX_QOSMAP_PROFILE_NUM      (127)
#define CLNX_SAI_MAX_SCHEDULER_PROFILE_NUM   (128)
#define CLNX_SAI_MAX_SAMPLEPKT_PROFILE_NUM   (8)
#define CLNX_SAI_MAX_RPFGRP_NUM   (64)
#define CLNX_SAI_MAX_RPFGRP_MEMBER   (64)

#define CLNX_SAI_BRIDGE_FDID_NUM         (16382)
#define CLNX_SAI_BRIDGE_FDID_1Q_NUM      (4095)
#define CLNX_SAI_BRIDGE_FDID_1D_NUM      (CLNX_SAI_BRIDGE_FDID_NUM - CLNX_SAI_BRIDGE_FDID_1Q_NUM)

#define CLNX_SAI_HOSTIF_MAX_NUM_OF_HIF  (512)
#define CLNX_SAI_HOSTIF_MAX_NUM_OF_HIF_TABLE                     (4096)  /* hostif_table_entry */
#define CLNX_SAI_HOSTIF_MAX_TRAP_GROUPS (48)
#define CLNX_SAI_HOSTIF_REGULAR_TRAP_SUPPORTED_NUM               (32)    /* hostif_trap */
#define CLNX_SAI_HOSTIF_UDF_TRAP_SUPPORTED_NUM       (4)

#define CLNX_SAI_BUF_ING_POOL_NUM        (10)
#define CLNX_SAI_BUF_EGR_POOL_NUM        (10)
#define CLNX_SAI_BUF_CELL_BYTE_SIZE      (224)
#define CLNX_SAI_BUF_ING_POOL_SIZE       ((81511) * (2) * CLNX_SAI_BUF_CELL_BYTE_SIZE)
#define CLNX_SAI_BUF_EGR_POOL_SIZE       ((87511) * (2) * CLNX_SAI_BUF_CELL_BYTE_SIZE)

#if SAI_VERSION_CODE >= SAI_VER(1,7,0)
/* The value come from osal_dma.h (#define OSAL_DMA_MEM_SIZE  (4*1024*1024)) */
#define CLNX_SAI_DMA_MEM_SIZE                  (4*1024*1024)
#endif

#define CLNX_SAI_RSV_STP_ALL_DROP        (255)
#define CLNX_SAI_RSV_STP_ALL_FWD         (254)
#define CLNX_SAI_RSV_STP_ALL_LRN         (253)

#define CLNX_SAI_MAX_NUM_OF_IGR_MIR_SES  (8)
#define CLNX_SAI_MAX_NUM_OF_EGR_MIR_SES  (8)
#define CLNX_SAI_MAX_NUM_OF_MIR_SES      (CLNX_SAI_MAX_NUM_OF_IGR_MIR_SES + CLNX_SAI_MAX_NUM_OF_EGR_MIR_SES)

#define CLNX_SAI_UDF_GROUP_CAPACITY      (18)
#define CLNX_SAI_UDF_GROUP_MAX_NUM       (1)
#define CLNX_SAI_UDF_MATCH_MAX_NUM       (63)
#define CLNX_SAI_UDF_ENTRY_MAX_NUM       (CLNX_SAI_UDF_GROUP_MAX_NUM * CLNX_SAI_UDF_GROUP_CAPACITY)

#define CLNX_SAI_MAX_TAM_OBJECT_COUNT 256
#define CLNX_SAI_MAX_SNAPSHOT_COUNT 256
#define CLNX_SAI_MAX_TAM_STAT_OBJECT_COUNT 1024
#define CLNX_SAI_MAX_TAM_THRESHOLD_OBJECT_COUNT 1024
#define CLNX_SAI_MAX_TAM_SNAPSHOT_OBJECT_COUNT 1024
#define CLNX_SAI_MAX_TAM_TRANSPORTER_OBJECT_COUNT 32
#define CLNX_SAI_MAX_TAM_MICROBURST_OBJECT_COUNT 1024
#define CLNX_SAI_MAX_TAM_HISTOGRAM_OBJECT_COUNT 1024

#define CLNX_ACL_USER_META_FDB_DST_MIN                  (0)
#define CLNX_ACL_USER_META_FDB_DST_MAX                  (0xfff)
#define CLNX_ACL_USER_META_ROUTE_DST_MIN                (0)
#define CLNX_ACL_USER_META_ROUTE_DST_MAX                (0x7ff)
#define CLNX_ACL_USER_META_NEIGHBOR_DST_MIN             (0)
#define CLNX_ACL_USER_META_NEIGHBOR_DST_MAX             (0x7ff)
#define CLNX_ACL_USER_META_ROUTE_NEIGHBOR_DST_OFFSET    (1)
#define CLNX_ACL_USER_META_PORT_MIN                     (0)
#define CLNX_ACL_USER_META_PORT_MAX                     (3)
#define CLNX_ACL_USER_META_PORT_OFFSET                  (8)
#define CLNX_ACL_USER_META_ACL_MIN                      (0)
#define CLNX_ACL_USER_META_ACL_MAX                      (0x3f)
#define CLNX_ACL_INTERNAL_META_ACL_MIN               (0x40)
#define CLNX_ACL_INTERNAL_META_ACL_MAX               (0x7f)
#define CLNX_ACL_META_MAX                    (0x7f)
#define CLNX_ACL_META_MASK                    (CLNX_ACL_META_MAX)
#define CLNX_SAI_INTERNAL_META_ACL_BITMAP_SIZE       \
            (CLX_BITMAP_SIZE(CLNX_ACL_INTERNAL_META_ACL_MAX-CLNX_ACL_INTERNAL_META_ACL_MIN))
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
#define CLNX_SAI_META_GRPLABEL_DST_MIN                (0)
#define CLNX_SAI_META_GRPLABEL_DST_MAX                (0)
#define CLNX_SAI_COUNTER_GRPLABEL_DST_MIN             (0)
#define CLNX_SAI_COUNTER_GRPLABEL_DST_MAX             (0x7ff)

#define CLNX_SAI_COUNTER_MAPPED_DST_MASK             (0x7ff)
#define CLNX_SAI_COUNTER_MAPPED_NUM           (2047)
#define CLNX_SAI_COUNTER_MAPPED_SIZE           (CLX_BITMAP_SIZE(CLNX_SAI_COUNTER_MAPPED_NUM))
//#define CLNX_SAI_META_MAPPED_SIZE      (0)
/* modified by bicl, when this macro is 0, call malloc will return failed. */
#define CLNX_SAI_META_MAPPED_SIZE      (10)

#define CLNX_L3_GRPLABEL_FLAGS_META             (1 << 0)
#define CLNX_L3_GRPLABEL_FLAGS_COUNTER         (1 << 1)
#endif
#define CLNX_SAI_ACL_TABLE_NUM_IGR                          (8)
#define CLNX_SAI_ACL_TABLE_NUM_EGR                          (4)
#define CLNX_SAI_ACL_ENTRY_NUM_IGR                          (CLNX_SAI_ACL_TABLE_NUM_IGR * 1024)
#define CLNX_SAI_ACL_ENTRY_NUM_EGR                          (CLNX_SAI_ACL_TABLE_NUM_EGR * 1024)
#define CLNX_SAI_ACL_GROUP_NUM_IGR                          (256)
#define CLNX_SAI_ACL_GROUP_NUM_EGR                          (256)
#define CLNX_SAI_ACL_RANGE_NUM                                  (16)
#define CLNX_SAI_ACL_GROUP_MEMBER_NUM         (CLNX_SAI_ACL_TABLE_NUM_IGR +  CLNX_SAI_ACL_TABLE_NUM_EGR)
#define CLNX_SAI_DFLT_VLAN               (1)
#define CLNX_SAI_DFLT_STP                (0)
#define CLNX_SAI_DFLT_1Q_BRIDGE_ID       (1)
#define CLNX_SAI_VLAN_BMP_SIZE           (CLX_BITMAP_SIZE(CLNX_SAI_MAX_VLAN_NUM))
#define CLNX_SAI_BRIDGE_PORT_BMP_SIZE    (CLX_BITMAP_SIZE(CLNX_SAI_MAX_BRIDGE_PORT_NUM))

#define CLNX_SAI_BUF_MAX_PROFILE_NUM   (128)

#define CLNX_SAI_NUM_RIF                 (16384)
#define CLNX_SAI_NUM_RTE                 (512)
#define CLNX_SAI_NUM_TNL_RTE                 (512)

#define CLNX_BRIDGE_FLAGS_CREATE_WITH_ID (1 << 0)
#define CLNX_BRIDGE_FLAGS_IS_1Q_BRIDGE   (1 << 1)

#define CLNX_IS_UNIT_VALID(__unit__)                ((__unit__ >= CLNX_SAI_MAX_CHIP_NUM) ? false : clnx_sai_get_unit_inited(__unit__))
#define CLNX_PORT_DB_PTR(__unit__, __port__)        ((CLNX_PORT_UNIT_PORT_PRPRTY_T *)(_clnx_port_cb[__unit__].port_db_ptr + __port__ ))
#define CLNX_PORT_MAP_PTR(__unit__, __port__)    ((CLNX_PORT_MAP_T *)(_clnx_port_cb[__unit__].port_map + __port__))
#define CLNX_IS_ETH_PORT_VALID(__unit__, __port__)  ((__port__ < CLNX_SAI_MAX_PORT_NUM) && ((NULL == _clnx_port_cb[__unit__].port_db_ptr) ? false : (0 != CLNX_PORT_DB_PTR(__unit__, __port__)->clx_port)))
#define CLNX_IS_PORT_VALID(__unit__, __port__)      ((__port__ < CLNX_SAI_MAX_PORT_NUM) && ((NULL == _clnx_port_cb[__unit__].port_db_ptr) ? false : (0 != CLNX_PORT_DB_PTR(__unit__, __port__)->clx_port)))
#define CLNX_CHECK_PTR(__ptr__, __msg__) \
    do                         \
    {                                                              \
        if (NULL == __ptr__)                                       \
        {                                                          \
            CLNX_LOG_ERR(__MODULE__, "%s", __msg__);                \
            return SAI_STATUS_INVALID_PARAMETER;                   \
        }                                                          \
    } while (0)

#define CLNX_UNIT_FOREACH(__unit__)                              \
    for (__unit__ = 0; __unit__ < CLNX_SAI_MAX_CHIP_NUM; __unit__++)    \
        if (clnx_sai_get_unit_inited(__unit__))

#define CLNX_PORT_FOREACH(__unit__, __port__)                              \
    if (NULL != _clnx_port_cb[__unit__].port_db_ptr)                 \
    for (__port__ = 0; __port__ < CLX_PORT_NUM; __port__++)    \
    if (0 != CLNX_PORT_DB_PTR(__unit__, __port__)->clx_port)

#define INVALID_L3_ADJ_ID 0xffffffff
#define INVALID_VRF_ID 0xffffffff
#define INVALID_INTF_ID 0xffffffff

#define CLNX_COUNTER_TYPE_DIST       1
#define CLNX_COUNTER_TYPE_SRV        2

#define CLNX_PKT_MAC_LEN_BYTE                     (6)
#define CLNX_PKT_VXLAN_LEN_WORD                   (2)
#define CLNX_PKT_IPV4_LEN_WORD                    (5)
#define CLNX_PKT_IPV6_LEN_WORD                    (10)
#define CLNX_PKT_ETH_P_8021Q     0x8100 /* 802.1q Service VLAN */
#define CLNX_PKT_ETH_P_8021AD    0x88A8 /* 802.1ad Service VLAN */
#define CLNX_PKT_ETHERTYPE_IPV4  0x0800
#define CLNX_PKT_ETHERTYPE_IPV6  0x86dd
#define CLNX_PKT_PORT_INDEX_TO_PHYPORT(__port__)        ((__port__ & 0x000000ff))

/* CLNX_PKT ETH/ETH_VLAN/VXLAN_EVPN_IPV4/VXLAN_EVPN_VLAN_IPV4/VXLAN_EVPN_QINQ/VXLAN_EVPN_IPV6/VXLAN_EVPN_VLAN_IPV6/VXLAN_EVPN_QINQ_IPV6 PKT struct START */
typedef struct
{
    uint8_t  dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  smac[CLNX_PKT_MAC_LEN_BYTE];
    uint16_t ethertype;
} CLNX_PKT_ETH_T;

typedef struct
{
    uint8_t  dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  smac[CLNX_PKT_MAC_LEN_BYTE];
    uint16_t vlan_type;
    uint16_t vlan_tag;
    uint16_t ethertype;
} CLNX_PKT_ETH_VLAN_T;

typedef struct
{
    uint8_t  outer_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLNX_PKT_MAC_LEN_BYTE];
    uint16_t ethertype;
    uint32_t outer_ipv4[CLNX_PKT_IPV4_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLNX_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLNX_PKT_MAC_LEN_BYTE];
} CLNX_PKT_IPV4_T;

typedef struct
{
    uint8_t  outer_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLNX_PKT_MAC_LEN_BYTE];
    uint16_t vlan_type;
    uint16_t vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv4[CLNX_PKT_IPV4_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLNX_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLNX_PKT_MAC_LEN_BYTE];
} CLNX_PKT_VLAN_T;

typedef struct
{
    uint8_t  outer_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLNX_PKT_MAC_LEN_BYTE];
    uint16_t outer_vlan_type;
    uint16_t outer_vlan_tag;
    uint16_t inner_vlan_type;
    uint16_t inner_vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv4[CLNX_PKT_IPV4_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLNX_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLNX_PKT_MAC_LEN_BYTE];
} CLNX_PKT_QINQ_T;

typedef struct
{
    uint8_t  outer_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLNX_PKT_MAC_LEN_BYTE];
    uint16_t ethertype;
    uint32_t outer_ipv6[CLNX_PKT_IPV6_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLNX_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLNX_PKT_MAC_LEN_BYTE];
} CLNX_PKT_IPV6_T;

typedef struct
{
    uint8_t  outer_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLNX_PKT_MAC_LEN_BYTE];
    uint16_t vlan_type;
    uint16_t vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv6[CLNX_PKT_IPV6_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLNX_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLNX_PKT_MAC_LEN_BYTE];
} CLNX_PKT_VLAN_IPV6_T;

typedef struct
{
    uint8_t  outer_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLNX_PKT_MAC_LEN_BYTE];
    uint16_t outer_vlan_type;
    uint16_t outer_vlan_tag;
    uint16_t inner_vlan_type;
    uint16_t inner_vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv6[CLNX_PKT_IPV6_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLNX_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLNX_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLNX_PKT_MAC_LEN_BYTE];
} CLNX_PKT_QINQ_IPV6_T;
/* CLNX_PKT ETH/ETH_VLAN/VXLAN_EVPN_IPV4/VXLAN_EVPN_VLAN_IPV4/VXLAN_EVPN_QINQ/VXLAN_EVPN_IPV6/VXLAN_EVPN_VLAN_IPV6/VXLAN_EVPN_QINQ_IPV6 PKT struct END */

typedef enum _clnx_sai_api_t
{
    CLNX_SAI_API_START      = SAI_API_MAX,
    CLNX_SAI_API_UTIL         = CLNX_SAI_API_START,
    CLNX_SAI_API_DIAG,
    CLNX_SAI_API_TAM_INT,
    CLNX_SAI_API_HAIRPIN,
    CLNX_SAI_API_PACKET_JOURNAL,
    CLNX_SAI_API_WATERMARK,

    CLNX_SAI_API_MAX
}clnx_sai_api_t;

struct avl_cookie
{
    UI32_T length;
    void* data;
};

struct avl_cookie_box
{
    UI32_T count;
    struct avl_cookie* cookies;
};

static inline UI32_T
cmlib_bitmap_findFirstOne(
    UI32_T ui32_map)
{
    UI32_T shift_count;
    static const C8_T lookup_table[] =
    {
        4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0 /*0 is invalid*/
    };

    for (shift_count = 0; shift_count < 32; shift_count += 8)
    {
        if ((ui32_map & 0xff) != 0)
        {
            break;
        }
        ui32_map >>= 8;
    }
    if (ui32_map & 0x0f)
        return lookup_table[ui32_map & 0x0f] + shift_count;
    return lookup_table[(ui32_map>>4) & 0x0f] + shift_count + 4;
}

#define CMLIB_BITMAP_NEXT(bitmap, word, from, bit) \
({\
    unsigned int i = ((from) + 1)/32;  \
    unsigned int offset = ((from)+1) %32;  \
    if (offset && bitmap[i] >=(unsigned int)(1<< offset))  \
        bit = i*32 + cmlib_bitmap_findFirstOne(bitmap[i] & ~((1<<offset)-1)); \
    else  \
    { \
        if (offset) i++; \
        for(; i<(word); i++) \
        { \
            if (bitmap[i]) \
            {    \
                bit = i* 32 + cmlib_bitmap_findFirstOne(bitmap[i]); \
                break; \
            } \
        }  \
        if (i == (word))bit = (word)*32;\
    } \
})

#define CMLIB_BITMAP_FIRST(bitmap, word, bit) \
({\
    unsigned int i; \
    for(i = 0; i < (word); i++) \
    { \
        if (bitmap[i]) \
        { \
            bit = i*32 + cmlib_bitmap_findFirstOne(bitmap[i]); \
            break; \
        } \
    } \
    if (i == (word))bit = (word)*32; \
})

#define CMLIB_BITMAP_FOREACH(bitmap, bit, word)  \
for (CMLIB_BITMAP_FIRST(bitmap, word, bit); bit < (word)*32; CMLIB_BITMAP_NEXT(bitmap, word, bit, bit))

#define VRF_FOREACH(unit, vrf_id)  CMLIB_BITMAP_FOREACH(ptr_clnx_vrf_cb[unit]->vrf_bitmap, vrf_id, CLNX_VRF_BITMAP_SIZE)

#define CMLIB_LIST_FOREACH(ptr_list, ptr_data, ptr_node) \
    for ( cmlib_list_locateHead(ptr_list, &ptr_node); \
          ptr_node && CLX_E_OK == cmlib_list_getNodeData(ptr_list, ptr_node, (void**)&ptr_data); \
          cmlib_list_next(ptr_list, ptr_node, &ptr_node))
#define CMLIB_LIST_FOREACH_SAFE(ptr_list, ptr_data, ptr_node, ptr_next_node) \
    for ( cmlib_list_locateHead(ptr_list, &ptr_node); \
          ptr_node && (CLX_E_OK == cmlib_list_getNodeData(ptr_list, ptr_node, (void**)&ptr_data)) \
          && (CLX_E_OK == cmlib_list_next(ptr_list, ptr_node, &ptr_next_node)); ptr_node = ptr_next_node)

typedef struct CLNX_BRIDGE_PORT_INFO_S
{
    sai_bridge_port_type_t    type;
    sai_object_id_t           oid;  /* PORT/LAG/RIF/TNL object */
    uint16_t                  vid;  /* only SUB_PORT use */
} CLNX_BRIDGE_PORT_INFO_T;

typedef enum
{
    CLNX_SRV_LRN_MODE_EXCPT,     /* sa_miss: except, lrn: dis */
    CLNX_SRV_LRN_MODE_FWD,       /* sa_miss: fwd,    lrn: dis */
    CLNX_SRV_LRN_MODE_LRN,       /* sa_miss: fwd,    lrn: en  */
    CLNX_SRV_LRN_MODE_LAST
} CLNX_SRV_LRN_MODE_T;

typedef enum
{
    CLNX_SRV_BUM_TYPE_BROADCAST = 0,
    CLNX_SRV_BUM_TYPE_UNKNOWN_MULTICAST,
    CLNX_SRV_BUM_TYPE_UNKNOWN_UNICAST,
    CLNX_SRV_BUM_TYPE_LAST
} CLNX_SRV_BUM_TYPE_T;

/* =========SAI_API_UTILS========= */
extern CLX_ERROR_NO_T
clnx_io_saveAvlTree(
    const CMLIB_AVL_HEAD_T *ptr_avl,
    CMLIB_AVL_TRAV_FUNC_T trav_func,
    HAL_IO_OBJ_META_T      *ptr_obj_meta);

extern CLX_ERROR_NO_T
clnx_io_restoreAvlTree(
    CMLIB_AVL_HEAD_T  *ptr_avl,
    CMLIB_AVL_TRAV_FUNC_T trav_func,
    HAL_IO_OBJ_META_T *ptr_obj_meta);

/* =========SAI_API_RPF_GROUP========= */
sai_status_t clnx_rpfgrp_getGrpInfo(
    _In_  sai_object_id_t   obj_id,
    _Out_ uint32_t          *ptr_unit,
    _Out_ CLX_IP_ADDR_T     *ptr_ip,
    _Out_ uint32_t          *ptr_cnt,
    _Out_ uint32_t          *ptr_grp_id);

sai_status_t clnx_rpfgrp_getObjByIp(
    _In_   CLX_IP_ADDR_T    *ptr_ip,
    _In_   uint32_t         unit,
    _Out_  sai_object_id_t  *ptr_obj_id);

sai_status_t clnx_rpfgrp_init(
    const uint32_t    unit);

sai_status_t clnx_rpfgrp_deinit(
    const uint32_t    unit);

/* =========SAI_API_ROUTER_INTERFACE========= */
typedef enum
{
    CLNX_RIF_IDX_TYPE_RTE_MAC = 0,
    CLNX_RIF_IDX_TYPE_TNL_MAC,

} CLNX_RIF_IDX_TYPE_T;

sai_status_t clnx_rif_init(
    _In_ const uint32_t    unit);

sai_status_t clnx_rif_deinit(
    _In_ const uint32_t    unit);

sai_status_t clnx_rif_getsubvid(
    _In_  const sai_object_id_t         rif_id,
    _Out_ uint32_t                      *ptr_subvid);

sai_status_t clnx_rif_getInfo(
    _In_  const sai_object_id_t         rif_id,
    _Out_ uint32_t                      *ptr_unit,
    _Out_ CLX_BRIDGE_DOMAIN_T           *ptr_bdid,
    _Out_ CLX_L3_INTF_INFO_T            *ptr_intf_info,
    _Out_ sai_router_interface_type_t   *ptr_type,
    _Out_ CLX_PORT_T                    *ptr_port);

sai_status_t clnx_rif_updateLagMember(
    _In_ const uint32_t                 unit,
    _In_ const sai_object_id_t          lag_oid,
    _In_ const sai_object_id_t          member_port_oid,
    _In_ const uint32_t                 is_add);

sai_status_t clnx_rif_get_bdid(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  intf_id,
    _Out_ CLX_BRIDGE_DOMAIN_T* bdid);

sai_status_t clnx_rif_get_type(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  intf_id,
    _Out_ sai_int32_t* type);

sai_status_t
_clnx_rif_getObj(
    const uint32_t          unit,
    const uint32_t          intf_id,
    sai_object_id_t         *ptr_rif_oid);

sai_status_t
_clnx_rif_getId(
    const sai_object_id_t   rif_oid,
    uint32_t                *ptr_unit,
    uint32_t                *ptr_intf_id);

sai_status_t
clnx_rif_allocRouterMacIdx(
    const uint32_t              unit,
    const CLNX_RIF_IDX_TYPE_T    type,
    uint32_t                    *ptr_idx);

void
clnx_rif_freeRouterMacIdx(
    const uint32_t              unit,
    const CLNX_RIF_IDX_TYPE_T    type,
    const uint32_t              idx);

sai_status_t clnx_rif_getRouterMacIdx(
    _In_ const uint32_t              unit,
    _In_ const CLNX_RIF_IDX_TYPE_T    type,
    _In_ const uint32_t                 l3_intf_id,
    _In_ const CLX_MAC_T  mac,
    _Out_  uint32_t*              ptr_idx);

sai_status_t clnx_rif_update_router_mac(
    _In_ const uint32_t unit,
    _In_ const sai_mac_t old_mac,
    _In_ const sai_mac_t new_mac);

sai_status_t
clnx_rif_getSdkIntfIdByTypeObjID(
    _In_ const uint32_t    unit,
    _In_ const sai_object_id_t    obj_id,
    _Out_ uint32_t      *ptr_intf_id);

sai_status_t
clnx_rif_update_router_macByVrf(
    _In_ const uint32_t unit,
    _In_ const uint32_t vrf,
    _In_ const sai_mac_t* new_mac);

/* =========SAI_API_NEIGHBOR========= */
sai_status_t clnx_neighbor_init(
    _In_ const uint32_t           unit);

sai_status_t clnx_neighbor_deinit(
    _In_ const uint32_t           unit);

sai_status_t clnx_neighbor_getInfo(
    _In_ const sai_neighbor_entry_t     *ptr_neighbor,
    _Out_ CLX_L3_HOST_INFO_T            *ptr_host_info,
    _Out_ uint32_t                      *ptr_adj_id,
    _Out_ CLX_L3_ADJ_INFO_T             *ptr_adj_info);

sai_status_t clnx_neighbor_route_add_update(
    UI32_T unit,
    CLX_L3_ROUTE_INFO_T* route_info,
    UI32_T intf_id);

sai_status_t clnx_neighbor_route_delete_update(
    UI32_T unit,
    CLX_L3_ROUTE_INFO_T* route_info,
    UI32_T intf_id);

/* =========SAI_API_NEXTHOP========= */
sai_status_t
clnx_nexthop_init(
    _In_ const uint32_t         unit);

sai_status_t
clnx_nexthop_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clnx_nexthop_getObj(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         adj_id,
    _Out_ sai_object_id_t       *ptr_next_hop_id);

sai_status_t
clnx_nexthop_getInfo(
    _In_ const sai_object_id_t  next_hop_id,
    _In_ const uint32_t  vrf_id,
    _In_ const uint32_t  flags,
    _Out_ uint32_t              *ptr_unit,
    _Out_ uint32_t              *ptr_adj_id);

sai_status_t clnx_nexthop_updateL2Addr(
    _In_ const uint32_t              unit,
    _In_ const CLX_L2_ADDR_T         *ptr_l2_addr);

void clnx_nexthop_tunnel_map_encap_update(uint32_t unit, uint32_t vrf_id, uint32_t vni);
void clnx_nexthop_switch_vxlan_mac_update(uint32_t unit);
#define SET_MAC     (1 << 0)
#define REMOVE_MAC      (1 << 1)
#define GET_ADJ_ONLY (1 << 2)

/*although these cmds can not exist at same time, maybe we can use enum to describe it
   but i keep the possibility something can do together*/
#define SET_TUNNEL_VNI     (1 << 0)
#define UNSET_TUNNEL_VNI     (1 << 1)
#define SET_TUNNEL_MAC      (1 << 2)
#define UPDATE_VRF_VNI      (1 << 3)
#define ADD_ROUTE      (1 << 4)
#define DELETE_ROUTE      (1 << 5)

sai_status_t
clnx_get_ip_type_nexthop_adj_id(
    _In_  uint32_t unit,
    _In_ sai_object_id_t rif_id,
    _In_ sai_ip_address_t ip_address,
    _In_ uint32_t flags,
    _In_ void* p_para,
    _In_ uint32_t adj_flags,
    _Out_ uint32_t *out_adj_id);

sai_status_t clnx_nexthop_update_by_adj_id(
    _In_  uint32_t unit,
    _In_  uint32_t vrf_id,
    _In_  uint32_t adj_id);


/* =========SAI_API_NEXTHOPGROUP========= */
sai_status_t
clnx_nexthopgroup_init(
    _In_ const uint32_t         unit);

sai_status_t
clnx_nexthopgroup_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clnx_nexthopgroup_getObj(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         ecmp_grp_id,
    _Out_ sai_object_id_t       *ptr_next_hop_group_id);

sai_status_t
clnx_nexthopgroup_getInfo(
    _In_ const sai_object_id_t  next_hop_group_id,
    _Out_ uint32_t              *ptr_unit,
    _Out_ uint32_t              *ptr_ecmp_grp_id);

/* =========SAI_API_VIRTUAL_ROUTER========= */
typedef struct
{
    CLX_MAC_T           src_mac;
    CLX_FWD_ACTION_T    mc_miss_action;

} CLNX_VRF_ENTRY_T;
#define CLNX_VRF_BITMAP_SIZE   (CLX_BITMAP_SIZE(CLNX_SAI_MAX_VRF_NUM))

typedef struct
{
    CLNX_VRF_ENTRY_T     *ptr_vrf_entry;
    CLX_SEMAPHORE_ID_T  sema;
    sai_object_id_t     default_vrf_id;
    uint32_t  vrf_bitmap[CLNX_VRF_BITMAP_SIZE];
} CLNX_VRF_CB_T;

extern CLNX_VRF_CB_T* ptr_clnx_vrf_cb[];

sai_status_t clnx_vrf_init(
    const uint32_t    unit);

sai_status_t clnx_vrf_deinit(
    const uint32_t    unit);

sai_status_t clnx_vrf_getInfo(
    _In_ const sai_object_id_t  obj_id,
    _Out_ uint32_t              *ptr_unit,
    _Out_ uint32_t              *ptr_vrf_id,
    _Out_ CLX_MAC_T             *ptr_src_mac,
    _Out_ CLX_FWD_ACTION_T      *ptr_fwd_act);

sai_status_t clnx_vrf_getObject(
    _In_ const uint32_t         vrf_id,
    _In_ const uint32_t         unit,
    _Out_ sai_object_id_t       *ptr_obj_id);

sai_status_t clnx_vrf_getDefaultVrf(
    _In_ const uint32_t unit,
    _Out_ sai_object_id_t *ptr_obj_id);

bool is_vrf_exist(const uint32_t unit, const uint32_t vrf_id);

/* =========SAI_API_ROUTER========= */
sai_status_t clnx_route_init(
    const uint32_t    unit);

sai_status_t clnx_route_deinit(
    const uint32_t    unit);

bool is_route_directed(CLX_L3_ROUTE_INFO_T * ptr_route_info);

bool clnx_route_check_interface(UI32_T unit, UI32_T vrf_id, sai_ip_prefix_t* prefix, UI32_T intf_id);

sai_status_t clnx_route_match_get(
    _In_ const UI32_T    unit,
    _In_ const UI32_T    vrf_id,
    _In_ sai_ip_address_t   ip_addr,
    _Out_  CLX_L3_ROUTE_INFO_T* route_info);

/* =========SAI_IPMC_GROUP========= */
sai_status_t
clnx_ipmcgrp_getInfo(
    _In_ const sai_object_id_t    oid,
    _Out_ uint32_t                *ptr_unit,
    _Out_ uint32_t                *ptr_mcast_id);

sai_status_t clnx_ipmc_group_init(
    const uint32_t    unit);

sai_status_t clnx_ipmc_group_deinit(
    const uint32_t    unit);

/* =========SAI_API_HASH========= */
sai_status_t
clnx_hash_init(
    _In_ uint32_t               unit);

sai_status_t
clnx_hash_deinit(
    _In_ uint32_t               unit);

sai_status_t
clnx_hash_id_get(
    _In_  sai_object_id_t       switch_id,
    _In_  CLX_SWC_HASH_TYPE_T   type,
    _Out_ sai_object_id_t       *ptr_hash_id);

sai_status_t
clnx_hash_id_set(
    _In_ sai_object_id_t        switch_id,
    _In_ CLX_SWC_HASH_TYPE_T    type,
    _In_ sai_object_id_t        hash_id);

CLX_ERROR_NO_T clnx_hash_diag_set_hash_key(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clnx_hash_diag_show_hash_key(
    _In_ const C8_T                *tokens[]);

/* =========SAI_API_SWITCH========= */
sai_status_t
clnx_switch_getUnitId(
    _In_ sai_object_id_t        switch_id,
    _Out_ uint32_t              *ptr_unit_id);

sai_status_t
clnx_switch_getFdbMissAction(
    _In_ const uint32_t             unit,
    _In_ const CLNX_SRV_BUM_TYPE_T   type,
    _Out_ sai_packet_action_t       *ptr_action);

sai_status_t
clnx_switch_getCfgValue(
    _In_ const UI32_T unit,
    _In_ const CLX_CFG_TYPE_T in_cfg_type,
    _Inout_ CLX_CFG_VALUE_T * ptr_in_value);

bool clnx_switch_get_restart_warm_only(uint32_t unit);

const char *clnx_switch_get_module_name(uint32_t index);

typedef enum
{
    _CLNX_SWITCH_MAC = 0,
    _CLNX_DEFAULT_VXLAN_ROUTER_MAC
}SWITCH_MAC_TYPE;

sai_status_t
clnx_switch_getSrcMac(
    _In_ const uint32_t              unit,
    _In_ const uint32_t              type,
    _Out_ sai_mac_t                 *mac);
sai_status_t
clnx_switch_getDefaultVxlanRouterMac(
    _In_ const uint32_t              unit,
    _Out_ sai_mac_t                 *mac);

extern uint32_t clnx_sai_get_unit_inited(uint32_t unit);

/* =========SAI_API_POLICER========= */
sai_status_t
clnx_policer_init(
    _In_ const uint32_t unit);

sai_status_t
clnx_policer_deinit(
    _In_ const uint32_t unit);

sai_status_t
clnx_policer_getUnitId(
    _In_ const sai_object_id_t  policer_id,
    _Out_ uint32_t              *ptr_unit);

sai_status_t
clnx_policer_addColorAct(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         port,
    _In_ const CLX_ACL_GROUP_T  type,
    _In_ const sai_object_id_t  policer_id);

sai_status_t
clnx_policer_delColorAct(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         port,
    _In_ const CLX_ACL_GROUP_T  type,
    _In_ const sai_object_id_t  policer_id);

sai_status_t
clnx_policer_applySettingToPort(
    _In_ const sai_object_id_t          port_id,
    _In_ sai_port_attr_t                type,
    _In_ const sai_object_id_t          cur_policer_id,
    _In_ const sai_object_id_t          new_policer_id);

/* =========SAI_API_PORT========= */
#define CLNX_PORT_MAX_PFC_COUNT            (8)

typedef enum
{
    CLNX_PORT_BREAKOUT_CAPABILITY_NONE       = 0,
    CLNX_PORT_BREAKOUT_CAPABILITY_TWO        = 1,
    CLNX_PORT_BREAKOUT_CAPABILITY_FOUR       = 2,
    CLNX_PORT_BREAKOUT_CAPABILITY_TWO_FOUR   = 3     /*TODO: clarify this purpose*/
} clnx_port_breakout_capability_t;

typedef enum
{
    CLNX_PORT_POLICER_TYPE_REGULAR_INDEX     = 0,
    CLNX_PORT_POLICER_TYPE_FLOOD_INDEX       = 1,
    CLNX_PORT_POLICER_TYPE_BROADCAST_INDEX   = 2,
    CLNX_PORT_POLICER_TYPE_MULTICAST_INDEX   = 3,
    CLNX_PORT_POLICER_TYPE_MAX               = 4
} clnx_port_policer_type;

typedef struct CLNX_PORT_UNIT_PORT_PRPRTY_S
{
    uint8_t                         valid;
    CLX_PORT_T                      clx_port;
    CLX_PORT_SPEED_T                max_speed;
    CLX_PORT_MEDIUM_TYPE_T          medium_type;
    uint32_t                        lane_grp;  /*First lane number in the list*/
    uint8_t                         lane_num;
    uint8_t                         default_tc;
    bool                            is_present;
    uint32_t                        admin_state;
    /*  SAI Port can have up to CLNX_PORT_POLICER_TYPE_MAX SDK port storm
     *  policers in use internally.  For each storm item we keep type of
     *  traffic it'll handle and SAI policer id which contains the policer
     *  attributes (cbs, pir, etc.) if SAI_NULL_OBJECT_ID == policer_id then
     *  given storm item is not in use currently.
     */
    sai_object_id_t                 ingress_policers[CLNX_PORT_POLICER_TYPE_MAX];
    sai_object_id_t                 ingress_samplepacket_obj;
    sai_object_id_t                 egress_samplepacket_obj;
    sai_object_id_t                 ingress_sample_mirror_session_obj;
    sai_object_id_t                 egress_sample_mirror_session_obj;
    sai_object_id_t                 wred_id;
    sai_object_id_t                 isolation_group_id;
    sai_object_id_t                 ing_acl_object;
    sai_object_id_t                 egr_acl_object;
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 1)
    sai_object_id_t                 port_serdes_id;
#endif
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
    sai_object_list_t            tamlist;
#endif
#define CLNX_PORT_UNIT_PORT_FLAG_PARENT    (1 << 0)
    uint32_t    flags;
}CLNX_PORT_UNIT_PORT_PRPRTY_T;

typedef struct CLNX_PORT_MAP_S
{
    bool valid;
    uint32_t unit;
    uint32_t port;
    CLX_PORT_T clx_port;
    uint32_t dst_idx;
    sai_object_id_t obj;
    char hostif_name[SAI_HOSTIF_NAME_SIZE];
}CLNX_PORT_MAP_T;

typedef struct  CLNX_PORT_CB_S
{
    CLNX_PORT_UNIT_PORT_PRPRTY_T *port_db_ptr;
    sai_pointer_t               callback_func;
    CLX_SEMAPHORE_ID_T          sema;
    uint32_t                    port_count;
    CLNX_PORT_MAP_T *port_map;
} CLNX_PORT_CB_T;

extern CLNX_PORT_CB_T _clnx_port_cb[];

typedef struct  CLNX_PORT_STAT_PFC_CB_S
{
    uint64_t                                rx_duration[CLNX_SAI_MAX_PORT_NUM][CLNX_PORT_MAX_PFC_COUNT];
    uint32_t                                interval_us;
    UI32_T                                 thread_pri;
    CLX_THREAD_ID_T                thread_id;
    CLX_SEMAPHORE_ID_T          sema;
} CLNX_PORT_STAT_PFC_CB_T;

extern CLNX_PORT_STAT_PFC_CB_T *_clnx_port_stat_pfc_cb[];

sai_status_t
clnx_port_init(
    _In_ const uint32_t         unit);

sai_status_t
clnx_port_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clnx_port_getUnitPort(
    _In_ const CLX_PORT_T       clx_port,
    _Out_ uint32_t                *ptr_unit,
    _Out_ uint32_t                *ptr_port);

sai_status_t
clnx_port_getCLXPort(
    _In_ const uint32_t           unit,
    _In_ const uint32_t           port,
    _Out_ CLX_PORT_T            *ptr_clx_port);

sai_status_t
clnx_port_registerCallback(
    _In_ const uint32_t         unit,
    _In_ void                   *func);

sai_status_t _clnx_port_setSampleMirrorSession(
    _In_ const sai_object_key_t         *ptr_key,
    _In_ const sai_attribute_value_t    *ptr_value,
    void                                *ptr_arg);

sai_status_t _clnx_port_setSamplepacketSession(
    _In_ const sai_object_key_t         *ptr_key,
    _In_ const sai_attribute_value_t    *ptr_value,
    void                                *ptr_arg);

sai_status_t clnx_port_getPortNumber(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clnx_port_getMaxPortNumber(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clnx_port_getPortList(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clnx_port_getCpuPort(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clnx_port_getTpid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const sai_switch_attr_t attr,
    _Out_ uint16_t * ptr_tpid);

sai_status_t clnx_port_setTpid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const sai_switch_attr_t attr,
    _In_ const uint16_t ptr_tpid);

sai_status_t clnx_port_getPortBmpEth(
    _In_ const uint32_t unit,
    _Out_ CLX_PORT_BITMAP_T eth_port_bmp);

sai_status_t
clnx_port_setBindEgrTable(
    sai_object_id_t     port_object,
    uint32_t        intf_group_label,
    bool        is_add);

sai_status_t
clnx_port_updatePortMapForName(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const char *port_name);

sai_status_t
clnx_port_dumpPortMapBrief(
    _In_ const uint32_t unit);

sai_status_t
clnx_port_dumpPortMapDetail(
    _In_ const uint32_t unit);

CLX_ERROR_NO_T clnx_port_dpbRemovePort(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clnx_port_dpbCreatePort(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clnx_port_dpbSetPort(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clnx_port_dpbGetPort(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clnx_port_dpbShowPort(
    _In_ const C8_T                *tokens[]);

sai_status_t
clnx_port_getMirrorSessionOid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ bool igr,
    _Out_ sai_object_id_t *ptr_mirrorsession_oid);

/* =========SAI_API_HOSTIF========= */
sai_status_t
clnx_hostif_init(
    _In_ const uint32_t         unit);

sai_status_t
clnx_hostif_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clnx_get_hostif_netid(
    _In_ sai_object_id_t    port_id,
    _Out_ uint32_t  *netif_id);

sai_status_t
clnx_hostif_getDefaultTrapGroupOid(
    _In_ const uint32_t         unit,
    _Out_ sai_object_id_t       *ptr_trap_group_oid);

sai_status_t clnx_hostif_get_port_oid_by_name(
    _In_ const uint32_t unit,
    _In_ const char *name,
    _Out_ sai_object_id_t *obj_id);

sai_status_t clnx_hostif_get_port_name_by_oid(
    _In_ const uint32_t unit,
    _In_ const sai_object_id_t obj_id,
    _Out_ char *name);

/* =========PKT_RX========= */
sai_status_t
clnx_pkt_rx_registerCallback(
    _In_ const uint32_t         unit,
    _In_ void                   *ptr_func);

sai_status_t
clnx_pkt_rx_init(
    _In_ const uint32_t         unit);

sai_status_t
clnx_pkt_rx_deinit(
    _In_ const uint32_t         unit);

/* =========SAI_API_FDB========= */
sai_status_t
clnx_fdb_init(
    _In_ const uint32_t unit);

sai_status_t
clnx_fdb_deinit(
    _In_ const uint32_t unit);

sai_status_t
clnx_fdb_registerCallback(
    _In_ const uint32_t unit,
    _In_ void *ptr_func);

sai_status_t
clnx_fdb_addNotifyL2Addr(
    _In_ const uint32_t                    unit,
    _In_ const CLX_L2_ADDR_NOTIFY_REASON_T reason,
    _In_ const CLX_L2_ADDR_T               *ptr_l2_addr);

/* =========SAI_API_LAG========= */
sai_status_t
clnx_lag_init(
    _In_ const uint32_t unit);

sai_status_t
clnx_lag_deinit(
    _In_ const uint32_t unit);

sai_status_t
clnx_lag_getInfo(
    _In_ const sai_object_id_t oid,
    _Out_ uint32_t             *ptr_unit,
    _Out_ CLX_PORT_T           *ptr_lag_port);

sai_status_t
clnx_lag_getObject(
    _In_ const uint32_t   unit,
    _In_ const CLX_PORT_T lag_port,
    _Out_ sai_object_id_t *ptr_oid);

sai_status_t
clnx_lag_setBindEgrTable(
    sai_object_id_t    lag_object,
    uint32_t        intf_group_label,
    bool        is_add);

sai_status_t
clnx_lag_getLagMember(
    _In_ sai_object_id_t    lag_oid,
    _Inout_ uint32_t    *lag_member_cnt,
    _Inout_ CLX_PORT_T  **pptr_lag_member_list);

sai_status_t
clnx_lag_updateAclHwEntry(
    _In_ sai_object_id_t    lag_oid,
    _In_ sai_object_id_t    lag_member_oid,
    _In_ bool   is_add);

sai_status_t
clnx_lag_updateAclEntryBmp(
    _In_ sai_object_id_t    lag_oid,
    _In_ uint32_t   entry_id,
    _In_ bool   is_add);
/* =========SAI_API_BRIDGE========= */
sai_status_t
clnx_bridge_init(
    _In_ const uint32_t             unit);

sai_status_t
clnx_bridge_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clnx_bridge_createBridgeDomain(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             flags,      /* reference CLNX_BRIDGE_FLAGS_XXX */
    _Inout_ CLX_BRIDGE_DOMAIN_T     *ptr_bdid);

sai_status_t
clnx_bridge_removeBridgeDomain(
    _In_ const uint32_t             unit,
    _In_ const CLX_BRIDGE_DOMAIN_T  bdid);

sai_status_t
clnx_bridge_getBridgeDomainType(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bdid,
    _Out_ sai_bridge_type_t         *ptr_type);

sai_status_t
clnx_bridge_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_bdid);

sai_status_t
clnx_bridge_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bdid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clnx_bridge_getBdPortIdByObject(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_bd_port_id);

sai_status_t
clnx_bridge_getBdPortIdByInfo(
    _In_ const uint32_t                 unit,
    _In_ const CLNX_BRIDGE_PORT_INFO_T   *ptr_info,
    _Out_ uint32_t                      *ptr_bd_port_id);

sai_status_t
clnx_bridge_getPortInfo(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ CLNX_BRIDGE_PORT_INFO_T    *ptr_info);

sai_status_t
clnx_bridge_getPortObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clnx_bridge_getBdPortBdid(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ uint32_t                  *ptr_bdid);

sai_status_t
clnx_bridge_setFloodAct(
    _In_ const uint32_t             unit,
    _In_ const CLNX_SRV_BUM_TYPE_T   type,
    _In_ const sai_packet_action_t  act);
#if 0
sai_status_t
clnx_bridge_setPortMode(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             port, /* native port id */
    _In_ const sai_bridge_port_type_t mode);

sai_status_t
clnx_bridge_getPortMode(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             port, /* native port id */
    _Out_ sai_bridge_port_type_t      *ptr_mode);
#endif
sai_status_t
clnx_bridge_fillServiceFloodAct(
    _In_ const uint32_t             unit,
    _In_ const CLNX_SRV_BUM_TYPE_T   type,
    _In_ const sai_packet_action_t  act,
    _In_ const uint32_t             mcast_id,
    _Inout_ CLX_PORT_SEG_SRV_T      *ptr_srv);

sai_status_t
clnx_bridge_fillServiceLrn(
    _In_ const uint32_t             unit,
    _In_ const bool                 bd_lrn_en,
    _In_ const CLNX_SRV_LRN_MODE_T   mode,
    _Inout_ CLX_PORT_SEG_SRV_T      *ptr_srv);

sai_status_t
clnx_bridge_fillTnlService(
    _In_ const uint32_t             unit,
    _In_ const sai_object_id_t      tnl_oid,
    _In_ const uint32_t             bdid,
    _Inout_ CLX_PORT_SEG_SRV_T      *ptr_srv);

sai_status_t
clnx_bridge_createDfltBdPort(
    _Out_  sai_object_id_t *bd_port_oid,
    _In_ const sai_object_id_t          switch_id,
    _In_ const CLNX_BRIDGE_PORT_INFO_T   *ptr_port_info);

sai_status_t
clnx_bridge_updateLagMbr(
    _In_ const uint32_t                 unit,
    _In_ const bool                     is_add,
    _In_ const uint32_t                 bd_port_id,
    _In_ const CLNX_BRIDGE_PORT_INFO_T   *ptr_port_info);

/* =========SAI_API_VLAN========= */
sai_status_t
clnx_vlan_init(
    _In_ const uint32_t             unit);

sai_status_t
clnx_vlan_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clnx_vlan_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint16_t                  *ptr_vid);

sai_status_t
clnx_vlan_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint16_t             vid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clnx_vlan_setFloodAct(
    _In_ const uint32_t             unit,
    _In_ const CLNX_SRV_BUM_TYPE_T   type,
    _In_ const sai_packet_action_t  act);

sai_status_t
clnx_vlan_create_VlanMbr(
    _Out_ sai_object_id_t    *vlan_member_id,
    _In_ const sai_object_id_t   switch_id,
    _In_ uint16_t   vid,
    _In_ const sai_object_id_t   bd_port_oid,
    _In_ sai_vlan_tagging_mode_t tag_mode);

sai_status_t
clnx_vlan_updateLagMbr(
    _In_ const uint32_t                  unit,
    _In_ const bool                      is_add,
    _In_ const uint32_t                  bd_port_id,
    _In_ const CLNX_BRIDGE_PORT_INFO_T    *ptr_port_info);

sai_status_t
clnx_vlan_update_flood_all_mgid(
    _In_ const uint32_t unit,
    _In_ const uint32_t vid,
    _In_ const uint32_t flags,
    _Out_ uint32_t *mcast_id
    );

sai_status_t clnx_vlan_valid_check(
    _In_ const uint32_t unit,
    _In_ const uint16_t vid);

sai_status_t clnx_vlan_set_dtel_profile (
    _In_ const uint32_t unit,
    _In_ const uint16_t vid,
    _In_ const uint32_t profile);
/* =========SAI_API_STP========= */
sai_status_t
clnx_stp_init(
    _In_ const uint32_t             unit);

sai_status_t
clnx_stp_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clnx_stp_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_stpid);

sai_status_t
clnx_stp_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clnx_stp_getPortInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_stpid,
    _Out_ uint32_t                  *ptr_bd_port_id);

sai_status_t
clnx_stp_getPortObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             bd_port_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clnx_stp_updateStpVlan(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             vid,
    _In_ const bool                 is_add);

sai_status_t
clnx_stp_updateStpBdid(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             bd_port_id,
    _In_ const uint32_t             bdid);

/* =========SAI_API_L2MC_GRP========= */
sai_status_t
clnx_l2mcgrp_init(
    _In_ const uint32_t             unit);

sai_status_t
clnx_l2mcgrp_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clnx_l2mcgrp_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_mcast_id);

sai_status_t
clnx_l2mcgrp_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             mcast_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clnx_l2mcgrp_addMcastBdPortId(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             mcast_id,
    _In_ const uint32_t             bdid,
    _In_ const uint32_t             bd_port_id,
    _In_ const uint32_t             flags);


sai_status_t
clnx_l2mcgrp_delMcastBdPortId(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             mcast_id,
    _In_ const uint32_t             vid,
    _In_ const uint32_t             bd_port_id,
    _In_ const uint32_t             flags);

sai_status_t
clnx_l2mcgrp_addMcastMbrPort(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  mcast_id,
    _In_ const CLNX_BRIDGE_PORT_INFO_T    *ptr_port_info,
    _In_ const CLX_BRIDGE_DOMAIN_T       bdid,
    _In_ const uint32_t                  flags);

sai_status_t
clnx_l2mcgrp_delMcastMbrPort(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  mcast_id,
    _In_ const CLNX_BRIDGE_PORT_INFO_T    *ptr_port_info,
    _In_ const CLX_BRIDGE_DOMAIN_T       bdid,
    _In_ const uint32_t          flags);

/* =========SAI_API_L2MC========= */
sai_status_t
clnx_l2mc_init(
    _In_ const uint32_t             unit);

sai_status_t
clnx_l2mc_deinit(
    _In_ const uint32_t             unit);

/* =========SAI_API_IPMC========= */
sai_status_t
clnx_ipmc_init(
    _In_ const uint32_t unit);

/* =========SAI_API_QUEUE========= */
#define CLNX_QUEUE_UC_NUM                (8)
#define CLNX_QUEUE_MC_NUM                (8)
#define CLNX_QUEUE_LEGACY_NUM            (8)
#define CLNX_QUEUE_CPU_NUM               (48)

typedef struct CLNX_QUEUE_DB_S
{
    bool                        is_used;
    sai_object_id_t             object_id;
    sai_object_id_t             parent_id;
    sai_object_id_t             scheduler_id;
    sai_object_id_t             wred_id;
    sai_object_id_t             buffer_id;
    CLX_TM_SCH_TOPOLOGY_ENTRY_T topology_entry;
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
    sai_object_list_t            tamlist;
#endif
} CLNX_QUEUE_DB_T;
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
 /*micro-burst begin*/

#define CLNX_TAM_CONFIG_ADD               (1)
#define CLNX_TAM_CONFIG_DEL                (0)

sai_status_t
clnx_tam_mburst_test(void);

sai_status_t
clnx_sai_tam_mburst_config(
    _In_ uint32_t    unit,
    _In_ uint32_t    port,
    _In_ uint32_t    queue,
    _In_ CLX_TM_HANDLER_TYPE_T    handler_type,
    _In_ CLX_TM_BUF_TYPE_T    buf_type,
    _In_ sai_object_id_t    tam_oid);

sai_status_t
clnx_sai_tam_mburst_clear(
    _In_ uint32_t    unit,
    _In_ uint32_t    port,
    _In_ uint32_t    queue,
    _In_ CLX_TM_HANDLER_TYPE_T    handler_type,
    _In_ CLX_TM_BUF_TYPE_T    buf_type);

sai_status_t
clnx_sai_tam_configtam(
  _In_ uint32_t    oper_flag,
  _In_ sai_object_id_t obj_id,
  _In_ CLX_TM_BUF_TYPE_T buf_type,
  _In_ sai_object_list_t tamobjlist);

 #endif
sai_status_t clnx_queue_getQueueDb(
    uint32_t            unit,
    uint32_t            port,
    sai_queue_type_t    type,
    uint32_t            queue_id,
    CLNX_QUEUE_DB_T      *ptr_queue_db);

sai_status_t clnx_queue_setQueueDb(
    uint32_t            unit,
    uint32_t            port,
    sai_queue_type_t    type,
    uint32_t            queue_id,
    CLNX_QUEUE_DB_T      *ptr_queue_db);

sai_status_t clnx_queue_getInfo(
    sai_object_id_t     object_id,
    uint32_t            *ptr_unit,
    uint32_t            *ptr_port_id,
    uint32_t            *ptr_type,
    uint32_t            *ptr_idx);

sai_status_t clnx_queue_getNum(
    sai_object_id_t     port_object_id,
    uint32_t             *ptr_num);

sai_status_t clnx_queue_getList(
    sai_object_id_t     port_object_id,
    sai_object_id_t     *ptr_list);

sai_status_t clnx_queue_init(
    uint32_t unit);

sai_status_t clnx_queue_deinit(
    uint32_t unit);

/* =========SAI_API_SCHEDULER_GROUP========= */
#define CLNX_SCH_GRP_MAX_SCH_LEVELS      (3)
#define CLNX_SCH_GRP_MAX_NUM_LEVEL_2     (8)
#define CLNX_SCH_GRP_MAX_NUM_LEVEL_1     (9)
#define CLNX_SCH_GRP_MAX_NUM_LEVEL_0     (1)
#define CLNX_SCH_GRP_MAX_CHILD_LEVEL_2   (2)
#define CLNX_SCH_GRP_MAX_CHILD_LEVEL_1   (8)
#define CLNX_SCH_GRP_MAX_CHILD_LEVEL_0   (9)

typedef struct CLNX_SCH_GRP_DB_S
{
    bool                        is_used;
    sai_object_id_t             object_id;
    sai_object_id_t             parent_id;
    uint32_t                    child_count;
    uint32_t                    max_child_count;
    sai_object_id_t             scheduler_id;
    CLX_TM_SCH_TOPOLOGY_ENTRY_T topology_entry;
} CLNX_SCH_GRP_DB_T;

typedef struct CLNX_SCH_GRP_HIERARCHY_S
{
    bool             is_legacy;
    /* queue, lv2, lv1*/
    CLNX_SCH_GRP_DB_T groups[CLNX_SCH_GRP_MAX_SCH_LEVELS][CLNX_SCH_GRP_MAX_NUM_LEVEL_1];
} CLNX_SCH_GRP_HIERARCHY_T;

sai_status_t
clnx_sch_grp_getPortQueueLegacy(
    uint32_t    unit,
    uint32_t    port,
    bool    *legacy);

sai_status_t clnx_sch_grp_parse_info(
    sai_object_id_t     object_id,
    uint32_t            *ptr_unit,
    uint32_t            *ptr_port_id,
    uint32_t            *ptr_lvl,
    uint32_t            *ptr_idx);

sai_status_t clnx_sch_grp_getGroupDb(
    uint32_t            unit,
    uint32_t            port,
    uint32_t            level,
    uint32_t            index,
    CLNX_SCH_GRP_DB_T    *ptr_group_db);

sai_status_t
clnx_sch_grp_removeQueue(
    uint32_t    unit,
    uint32_t    port,
    sai_object_id_t parent_oid);

sai_status_t
clnx_sch_grp_addQueue(
    uint32_t    unit,
    uint32_t    port,
    sai_object_id_t     parent_oid);

sai_status_t clnx_sch_grp_setGroupDb(
    uint32_t            unit,
    uint32_t            port,
    uint32_t            level,
    uint32_t            index,
    CLNX_SCH_GRP_DB_T    *ptr_group_db);

sai_status_t clnx_sch_grp_applyTopology(
    uint32_t            unit,
    uint32_t            port);

sai_status_t clnx_sch_grp_checkTopologyComplete(
    uint32_t            unit,
    uint32_t            port);

sai_status_t clnx_sch_grp_getHierarchyDb(
    uint32_t                    unit,
    uint32_t                    port,
    CLNX_SCH_GRP_HIERARCHY_T     *ptr_db);

sai_status_t clnx_sch_grp_getGroupNum(
    sai_object_id_t     port_object_id,
    uint32_t            *ptr_num);

sai_status_t clnx_sch_grp_getGroupList(
    sai_object_id_t     port_object_id,
    sai_object_id_t     *ptr_list);

sai_status_t clnx_sch_grp_init(
    uint32_t unit);

sai_status_t clnx_sch_grp_deinit(
    uint32_t unit);

/* =========SAI_API_SCHEDULER========= */
sai_status_t clnx_scheduler_setToPort(
    sai_object_id_t     object_id,
    sai_object_id_t     scheduler_id);

sai_status_t clnx_scheduler_getFromPort(
    sai_object_id_t     object_id,
    sai_object_id_t     *ptr_scheduler_id);

sai_status_t clnx_scheduler_applyToQueueGroup(
    sai_object_id_t     scheduler_id,
    uint32_t            port,
    CLX_TM_HANDLER_T    handler);

sai_status_t clnx_scheduler_init(
    uint32_t unit);

sai_status_t clnx_scheduler_deinit(
    uint32_t unit);

/* =========SAI_API_QOSMAP============ */
#define CLNX_QOSMAP_MAX_TC_COUNT             (16)
#define CLNX_QOSMAP_MAX_LOSSLESS_QUEUE_NUM   (2)
#define CLNX_QOSMAP_MAX_PFC_COUNT            (8)


sai_status_t clnx_qosmap_getPfcControl(
    sai_object_id_t         port_object_id,
    const sai_port_attr_t   attr_id,
    sai_attribute_value_t   *ptr_value);

sai_status_t clnx_qosmap_setPfcControl(
    sai_object_id_t         port_object_id,
    const sai_port_attr_t       attr_id,
    const sai_attribute_value_t   *ptr_value);

sai_status_t clnx_qosmap_getPfcControlMode(
    sai_object_id_t         port_object_id,
    sai_attribute_value_t   *ptr_value);

sai_status_t clnx_qosmap_setPfcControlMode(
    sai_object_id_t         port_object_id,
    const sai_attribute_value_t   *ptr_value);

sai_status_t clnx_qosmap_getInfo(
    sai_object_id_t object_id,
    uint32_t        *ptr_profileId,
    uint32_t        *ptr_unit,
    uint32_t        *ptr_type);

sai_status_t clnx_qosmap_getProfileFromPort(
    sai_object_id_t         port_object_id,
    uint32_t                type,
    sai_attribute_value_t   *ptr_value);

sai_status_t clnx_qosmap_setProfileToPort(
    sai_object_id_t port_object_id,
    sai_object_id_t profile_object_id);

sai_status_t clnx_qosmap_getProfileFromSwitch(
    sai_object_id_t         switch_id,
    uint32_t                type,
    sai_attribute_value_t   *ptr_value);

sai_status_t clnx_qosmap_setProfileToSwitch(
    sai_object_id_t object_id);

sai_status_t clnx_qosmap_init(
    uint32_t unit);

sai_status_t clnx_qosmap_deinit(
    uint32_t unit);

/* =========SAI_API_MCASTFDB============ */
sai_status_t
clnx_mcastfdb_init(
    _In_ const uint32_t unit);

sai_status_t
clnx_mcastfdb_deinit(
    _In_ const uint32_t unit);

/* =========SAI_API_SAMPLEPACKET========= */
sai_status_t clnx_samplepacket_init(
    _In_ uint32_t unit);

sai_status_t clnx_samplepacket_deinit(
    _In_ uint32_t unit);

sai_status_t clnx_samplepacket_getRate(
    _In_ sai_object_id_t samplepacket_id,
    _Out_ uint32_t *ptr_samplepacket_rate);

sai_status_t clnx_samplepacket_getType(
    _In_ sai_object_id_t samplepacket_id,
    _Out_ sai_samplepacket_type_t *ptr_samplepacket_type);

sai_status_t clnx_samplepacket_applySetting(
    _In_ sai_object_id_t obj_id,
    _In_ bool igr,
    _In_ sai_object_id_t cur_samplepacket_id,
    _In_ sai_object_id_t new_samplepacket_id);

sai_status_t clnx_create_samplepacket(
        _Out_ sai_object_id_t *samplepacket_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/* =========SAI_API_WRED========= */
sai_status_t clnx_wred_applySetting(
    _In_ sai_object_id_t obj_id,
    _In_ sai_object_id_t wred_id);

sai_status_t clnx_wred_init(
    _In_ uint32_t unit);

sai_status_t clnx_wred_deinit(
    _In_ uint32_t unit);

/* =========SAI_API_MIRROR========= */
sai_status_t clnx_mirror_sync_ses(
    _In_ uint32_t unit,
    _In_ sai_object_id_t mir_obj_idx,
    _In_ CLX_MIR_DIRECTION_T dir,
    _Out_ uint32_t *ptr_mir_session);

sai_status_t clnx_mirror_get_mir_type(
    _In_ uint32_t unit,
    _In_ sai_object_id_t mir_obj_idx,
    _Out_ CLX_MIR_TYPE_T *mir_type);

sai_status_t clnx_mirror_nvgre_ctrl(
    uint32_t unit,
    sai_object_id_t mir_obj_idx);

/* Get session id from mirror idx*/
sai_status_t clnx_mirror_get_ses_id(
    _In_ uint32_t unit,
    _In_ CLX_MIR_DIRECTION_T dir,
    _In_ uint32_t mir_idx,
    _Out_ sai_object_id_t *ptr_mir_ses_obj_id);

sai_status_t
clnx_tam_init(
    _In_ const uint32_t unit);

sai_status_t
clnx_tam_deinit(
    _In_ const uint32_t unit);

sai_status_t clnx_mirror_init(uint32_t unit);

sai_status_t clnx_mirror_deinit(uint32_t unit);

sai_status_t clnx_mirror_get_SysTc(uint32_t unit, uint8_t *ptr_sys_tc);

sai_status_t clnx_mirror_set_SysTc(uint32_t unit, uint8_t new_sys_tc);

sai_status_t clnx_mirror_apply_tc_to_all_session(uint32_t unit, uint8_t new_tc);

sai_status_t clnx_mirror_sync_for_tam_int(
    _In_ uint32_t unit,
    _In_ uint32_t udp_port,
    _In_ CLX_MIR_SESSION_T *session);

sai_status_t clnx_mirror_get_sdk_ses_id(
    _In_ sai_object_id_t session_oid,
    _Inout_ uint32_t *sdk_ses_id);

/* =========SAI_API_BUFFER========= */
typedef enum _CLNX_BUFFER_PORT_TYPE_T
{
    PORT_BUFF_TYPE_INGRESS,
    PORT_BUFF_TYPE_EGRESS,
    PORT_BUFF_TYPE_PG,
    PORT_BUFF_TYPE_QUEUE
} CLNX_BUFFER_PORT_TYPE_T;

typedef struct _CLNX_BUFFER_CAPACITY_T
{
    uint32_t num_ingress_pools;
    uint32_t num_egress_pools;
    uint32_t num_total_pools;
    uint32_t num_port_queue_buff;
    uint32_t num_port_pg_buff;
    uint32_t unit_size;
    uint32_t max_buffer_profiles;
} CLNX_BUFFER_CAPACITY_T;

typedef struct _CLNX_BUFFER_POOL_ATTR_T
{
    uint32_t                    clnx_pool_id;
    sai_buffer_pool_type_t      pool_type;
    sai_buffer_pool_threshold_mode_t pool_mode;
    /*size in bytes*/
    uint32_t pool_size;
    uint32_t pool_xoff_size;
    sai_object_id_t     wred_profile_id;
} CLNX_BUFFER_POOL_ATTR_T;

extern const CLNX_BUFFER_CAPACITY_T buffer_limits;
extern BOOL_T  clnx_sai_schedule_legacy;

sai_status_t clnx_buffer_set_profile_to_obj(
    _In_ CLNX_BUFFER_PORT_TYPE_T port_buff_type,
    _In_ sai_object_id_t object_id,
    _In_ sai_object_id_t profile);

sai_status_t
clnx_buffer_get_port_profile_list(
    _In_ CLNX_BUFFER_PORT_TYPE_T port_buff_type,
    _In_ sai_object_id_t    object_id,
    _Inout_ sai_attribute_value_t       *ptr_value);

sai_status_t clnx_buffer_get_port_pool_list(
    _In_ sai_object_id_t    object_id,
    _Inout_ sai_attribute_value_t       *ptr_value);

sai_status_t clnx_buffer_init(uint32_t unit);

sai_status_t clnx_buffer_add_port(
    _In_ uint32_t unit,
    _In_ uint32_t port);

sai_status_t clnx_buffer_deinit(uint32_t unit);

sai_status_t clnx_buffer_getPriorityGroupCount(
    _In_ sai_object_id_t port_object_id,
    _Out_ uint32_t *ptr_count);

sai_status_t clnx_buffer_getPriorityGroupList(
    _In_ sai_object_id_t port_object_id,
    _Out_ sai_object_id_t *ptr_list);

sai_status_t
clnx_buffer_updatePortPgBuffer(
    _In_ uint32_t    unit,
    _In_ uint32_t    port,
    _In_ uint32_t    pg_idx,
    _In_ uint32_t    pfc_enable);

CLX_ERROR_NO_T clnx_buffer_getHandler(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _In_ uint32_t type,
    _In_ uint32_t queue_id,
    _Out_ CLX_TM_HANDLER_T *ptr_handler);

uint32_t clnx_buffer_clnx_cells_to_bytes(uint32_t cells);

sai_status_t clnx_buffer_get_pool_data_ext(
    _In_ sai_object_id_t             sai_pool,
    _Out_ CLNX_BUFFER_POOL_ATTR_T *ptr_sai_pool_attr);
#if SAI_VERSION_CODE >= SAI_VER(1,5,0)
sai_status_t
clnx_buffer_get_pg_data(
    _In_ sai_object_id_t sai_pg,
    _Out_ uint32_t       *ptr_port,
    _Out_ uint32_t       *ptr_port_pg_index);

sai_status_t
clnx_buffer_pg_getUnitId(
    _In_ sai_object_id_t       object_id,
    _Out_ uint32_t *ptr_unit);
#endif
/* =========SAI_API_ACL========= */
#define CLNX_ACL_ACTION_PRIO_USR_DEFINE_MIN             (200)
#define CLNX_ACL_ACTION_PRIO_USR_DEFINE_MAX             (700)

#define CLNX_ACL_GROUP_MEMBER_PRIO_MIN                  (CLNX_ACL_ACTION_PRIO_USR_DEFINE_MIN)
#define CLNX_ACL_GROUP_MEMBER_PRIO_MAX                  (CLNX_ACL_ACTION_PRIO_USR_DEFINE_MAX)
#define CLNX_ACL_ENTRY_PRIO_MIN                         (0)
#define CLNX_ACL_ENTRY_PRIO_MAX                         (0xffffff)

/*the smaller prio value means higher priority */
/*other priority reserved to acl application */
#define CLNX_ACL_GROUP_PRIO_POLICER     (7)
#define CLNX_ACL_GROUP_PRIO_USER_ALLOC_MIN               (1)
#define CLNX_ACL_GROUP_PRIO_USER_ALLOC_MAX               (5)
#define CLNX_ACL_GROUP_PRIO_ICC         (0)
#define CLNX_ACL_GROUP_PRIO_COUNTER     (6)

#define CLNX_ACL_ACTION_PRIO_POLICER    (15)
#define CLNX_ACL_ACTION_PRIO_USER_ALLOC_MIN              (2)
#define CLNX_EGR_ACL_ACTION_PRIO_USER_ALLOC_MAX              (7)
#define CLNX_IGR_ACL_ACTION_PRIO_USER_ALLOC_MAX              (14)
#define CLNX_ACL_ACTION_PRIO_ICC        (1)

#define CLNX_ROUTE_IP2ME_GROUP_LABEL (1 << 11)
typedef enum
{
    CLNX_ACL_USER_META_PORT,
    CLNX_ACL_USER_META_FDB_DST,
    CLNX_ACL_USER_META_ROUTE_DST,
    CLNX_ACL_USER_META_NEIGHBOR_DST,
    CLNX_ACL_USER_META_ACL,
    CLNX_ACL_USER_META_ACL_LAST
} CLNX_ACL_USER_META_T;

sai_status_t
clnx_acl_init(
    _In_ const uint32_t unit);

sai_status_t
clnx_acl_deinit(
    _In_ const uint32_t unit);

sai_status_t
clnx_acl_getSwitchAttr(
    _In_ const sai_object_key_t *ptr_key,
    _Inout_ sai_attribute_value_t *ptr_value,
    void *ptr_arg);

sai_status_t
clnx_get_acl_entry_enum_values_capability(
    _In_ uint32_t unit,
    _In_ sai_attr_id_t attr_id,
    _Inout_ sai_s32_list_t *enum_values_capability);

sai_status_t
clnx_sai_acl_setGrpLblBindInfo(
    _In_ const uint32_t unit,
    _In_ const sai_acl_stage_t stage,
    _In_ const sai_object_id_t acl_object_id,
    _In_ const sai_object_id_t bind_point_onject_id,
    _In_ const bool add,
    _Inout_ uint32_t *ptr_group_label);

sai_status_t
clnx_sai_acl_getBindInfo(
    _In_ const uint32_t unit,
    _In_ const sai_acl_stage_t stage,
    _In_ const uint32_t group_label,
    _In_ const sai_object_id_t bind_point_object_id,
    _Out_ sai_object_id_t *ptr_object_id);

sai_status_t
clnx_sai_acl_setGrpLblUserMeta(
    _In_ const CLNX_ACL_USER_META_T user_meta_type,
    _In_ const uint32_t user_meta,
    _Inout_ uint32_t *ptr_group_label);

sai_status_t
clnx_sai_acl_getUserMeta(
    _In_ const CLNX_ACL_USER_META_T user_meta_type,
    _In_ const uint32_t group_label,
    _Out_ uint32_t *ptr_user_meta);

sai_status_t
clnx_sai_acl_addUdfKeyProfile(
    _In_ const uint32_t unit,
    _In_ const uint32_t prof_id,
    _In_ const CLX_ACL_PKT_FORMAT_T *ptr_pkt_format,
    _In_ const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

sai_status_t
clnx_sai_acl_delUdfKeyProfile(
    _In_ const uint32_t unit,
    _In_ const uint32_t prof_id);

sai_status_t
clnx_sai_acl_updateUdfKeyProfile(
    _In_ const uint32_t unit,
    _In_ const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

sai_status_t
clnx_sai_acl_updateEntrySamplingRate(
    _In_ const sai_object_id_t entry_object_id,
    _In_ const uint32_t sampling_rate);

sai_status_t
clnx_acl_getBindPortList(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id,
    _Out_ sai_object_list_t *ptr_igr_portlist,
    _Out_ sai_object_list_t *ptr_egr_portlist);

sai_status_t
clnx_pkj_updateIngressPort(
    _In_ uint32_t   unit,
    _In_ uint32_t   igr_port);

sai_status_t
clnx_set_acl_entry_attribute(
    _In_ sai_object_id_t acl_entry_id,
    _In_ const sai_attribute_t *attr);

/* =========SAI_API_TUNNEL========= */
sai_status_t
clnx_tunnel_init(
    _In_ const uint32_t unit);

sai_status_t
clnx_tunnel_deinit(
    _In_ const uint32_t unit);

sai_status_t
clnx_tunnel_getInfo(
    _In_ const sai_api_t init_caller,
    _In_ const sai_object_id_t tunnel_id,
    _In_ const sai_ip_address_t *ptr_dip,
    _Out_ uint32_t *ptr_unit,
    _Out_ CLX_TUNNEL_KEY_T *ptr_key,
    _Out_ CLX_PORT_T *ptr_port);

sai_status_t clnx_tunnel_get_tunnel_port_vni(
    _In_ sai_object_id_t tunnel_id,
    _In_ uint32_t vrf_id,
    _In_ sai_ip_address_t ipaddr,
    _Out_ CLX_PORT_T *port,
    _Out_ uint32_t *vni);

sai_status_t clnx_tunnel_add_nexthop_tunnel(
    UI32_T unit, UI32_T clnx_next_hop_id,
    sai_object_id_t  sai_tunnel_id,
    sai_ip_address_t endpoint_ip, UI32_T tunnel_vni,
    UI32_T vni_configured);

sai_status_t clnx_tunnel_remove_nexthop_tunnel(
    UI32_T unit, UI32_T clnx_next_hop_id,
    sai_object_id_t sai_tunnel_id,
    sai_ip_address_t endpoint_ip, UI32_T tunnel_vni,
    UI32_T vni_configured);

sai_status_t clnx_get_tunnel_portList(
    _In_ const sai_object_id_t tunnel_id,
    _Out_ CLX_PORT_T port_list[CLX_PORT_NUM],
    _Out_ uint32_t *pcount);

bool clnx_tunnel_is_vxlan(
    _In_ sai_object_id_t tunnel_id);

sai_status_t clnx_tunnel_port_get_ref_bridge_port(
    _In_ const UI32_T unit,
    _In_ const CLX_PORT_T tunnel_port,
    _Out_ sai_object_id_t* bridge_port_id,
    _Out_ sai_ip_address_t* dst_ip);

sai_status_t clnx_tunnel_set_ref_bridge_port(
    _In_ const sai_object_id_t tunnel_id,
    _In_ const sai_object_id_t bridge_port_id);

sai_status_t clnx_tunnel_host_update(UI32_T unit, CLX_L3_HOST_INFO_T* host_info);

sai_status_t clnx_tunnel_adj_update(UI32_T unit, UI32_T l3_adj_id);

sai_status_t clnx_tunnel_route_update(UI32_T unit, CLX_L3_ROUTE_INFO_T* route_info);

sai_status_t clnx_tunnel_ecmp_grp_update(UI32_T unit, UI32_T ecmp_grp_id, BOOL_T add, UI32_T adj_id);

/* =========SAI_API_UDF========= */

typedef struct _CLNX_UDF_MATCH_L2_T
{
    uint16_t data;
    bool     is_valid;
} CLNX_UDF_MATCH_L2_T;

typedef struct _CLNX_UDF_MATCH_L3_T
{
    uint8_t  data;
    bool     is_valid;
} CLNX_UDF_MATCH_L3_T;

typedef struct _CLNX_UDF_MATCH_DB_T
{
    uint32_t refs;
    CLNX_UDF_MATCH_L2_T l2_type;
    CLNX_UDF_MATCH_L3_T l3_type;
    uint8_t priority;
    sai_object_id_t sai_object;
} CLNX_UDF_MATCH_DB_T;

typedef struct _CLNX_UDF_GROUP_DB_T
{
    uint32_t type;
    uint32_t length;
    uint32_t refs;
    uint32_t count;
    uint32_t udf_indexes[CLNX_SAI_UDF_GROUP_CAPACITY];
    sai_object_id_t sai_object;
} CLNX_UDF_GROUP_DB_T;

sai_status_t clnx_udf_get_group(
    _In_ sai_object_id_t     udf_group_id,
    _Out_ CLNX_UDF_GROUP_DB_T **pptr_group_db);

sai_status_t clnx_udf_get_match_list_from_group(
    _In_ sai_object_id_t    udf_group_id,
    _Out_ uint32_t          *ptr_count,
    _Out_ CLNX_UDF_MATCH_DB_T *ptr_match_list);

sai_status_t clnx_udf_get_entry_list(
    _In_ sai_object_id_t    udf_group_id,
    _In_ sai_object_id_t    udf_match_id,
    _Out_ uint32_t          *ptr_count,
    _Out_ uint32_t          *ptr_list);

sai_status_t clnx_udf_init(_In_ uint32_t unit);

sai_status_t clnx_udf_deinit(_In_ uint32_t unit);

sai_status_t clnx_udf_get_group_obj(
    _In_ uint32_t         unit,
    _In_ uint32_t         udf_group_id,
    _Out_ sai_object_id_t *ptr_udf_group_id);

sai_status_t clnx_udf_get_match_id(
    _In_ sai_object_id_t    udf_match_obj,
    _Out_ uint32_t          *ptr_match_id);

/* =========SAI_API_ISOLATION_GROUP========= */
#if SAI_VERSION_CODE >= SAI_VER(1, 4, 0)
sai_status_t
clnx_isolationgroup_init(
    _In_ const uint32_t    unit);

sai_status_t
clnx_isolationgroup_deinit(
    _In_ const uint32_t    unit);

sai_status_t
clnx_isolation_group_setBindObj(
    _In_ sai_object_id_t    bind_port_oid,
    _In_ sai_object_id_t    isolation_grp_oid,
    _In_ bool   is_add);

sai_status_t
clnx_isolation_group_updateLagMbr(
    _In_ sai_object_id_t    lag_oid,
    _In_ sai_object_id_t    lag_member_oid,
    _In_ bool   is_add);
#endif

/* =========SAI_API_COUNTER========= */
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
sai_status_t
clnx_get_CounterInfo(
    _In_ sai_object_id_t counter_id,
    _Out_ uint32_t *cnt_id,
    _Out_ uint32_t *cnt_type);
#endif
/* =========SAI_API_COUNT========= */
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)

#define CLNX_SAI_COUNTER_L3_OPTFLAGS_REMOVE       (0)
#define CLNX_SAI_COUNTER_L3_OPTFLAGS_CREATE        (1)
#define CLNX_SAI_COUNTER_GRPLABEL_CREATE        (1)
#define CLNX_SAI_COUNTER_GRPLABEL_REMOVE        (0)

sai_status_t
clnx_counter_init(
    _In_ const uint32_t      unit);

sai_status_t
clnx_counter_deinit(
    _In_ const uint32_t      unit);

sai_status_t
clnx_counter_operate(
    _In_ uint32_t unit,
    _In_ uint32_t optflags,
    _In_ sai_object_id_t counter_id,
    _In_ sai_ip_addr_family_t addr_family,
    _Out_ uint32_t *ptr_group_label);

sai_status_t
clnx_counter_getGrpLabel(
    _In_ uint32_t unit,
    _In_ uint32_t flags,
    _Inout_ uint32_t                  *ptr_group_label);

sai_status_t
clnx_counter_createacltable(
    _In_ uint32_t unit,
    _Out_ uint32_t *ptr_acl_table_id);

sai_status_t
clnx_counter_createaclentry(
    _In_ uint32_t unit,
    _In_ uint32_t acl_table_id,
    _In_ sai_object_id_t counter_id,
    _In_ uint32_t counter_grouplabel,
    _In_ const sai_ip_addr_family_t addr_family,
    _Out_ uint32_t *ptr_acl_entry_id);

sai_status_t clnx_counter_delaclEntry(
        _In_ const uint32_t unit,
        _In_ const uint32_t entry_id);
#endif

/* =========SAI_API_DEBUG_COUNTER========= */
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
sai_status_t
clnx_debug_counter_init(
    _In_ const uint32_t         unit);

sai_status_t
clnx_debug_counter_deinit(
    _In_ const uint32_t         unit);
#endif

/* =========SAI_API_TAM========= */
sai_status_t
clnx_tam_init(
    _In_ const uint32_t unit);

#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
sai_status_t
clnx_tam_getTamIntObjList(
    _In_ sai_object_id_t    tam_obj,
    _Inout_ sai_object_list_t    *tam_int_list);
#endif

sai_status_t
clnx_tam_showData(void);

/* =========SAI_API_TAM_INT_DEMO========= */
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
typedef enum
{
    CLNX_TAM_INT_DEVICE_ROLE_NONE = 0,
    CLNX_TAM_INT_DEVICE_ROLE_INITIATOR,
    CLNX_TAM_INT_DEVICE_ROLE_TRANSIT,
    CLNX_TAM_INT_DEVICE_ROLE_TRANSIT_PORT_BASE,
    CLNX_TAM_INT_DEVICE_ROLE_TERMINATOR
} CLNX_TAM_INT_DEVICE_ROLE_T;

typedef enum
{
    CLNX_TAM_INT_MODE_NONE = 0,
    CLNX_TAM_INT_MODE_PORT, /* for device role: transit/terminator*/
    CLNX_TAM_INT_MODE_FLOW, /* for device role: initiator/transit */
    CLNX_TAM_INT_MODE_TUNNEL, /* for device role: initiator/terminator*/
    CLNX_TAM_INT_MODE_LAST
} CLNX_TAM_INT_MODE_T;

typedef struct CLNX_TAM_INT_DEMO_IOAM_S
{
    uint16_t trace_type;
    uint8_t max_len;
    uint8_t node_len;
    uint32_t node_id;
    uint32_t opq_id;
} CLNX_TAM_INT_DEMO_IOAM_T;

typedef struct CLNX_TAM_INT_DEMO_IFA1_S
{
    uint32_t presence_pb1;
    uint32_t presence_pb2;
    uint16_t trace_vector;
    uint16_t action_vector;
    uint32_t device_id;
    uint32_t max_len;
    uint16_t send_id;
    uint16_t seq_num;
    uint8_t max_hop_count;
    uint8_t tid;
    bool in_line;
} CLNX_TAM_INT_DEMO_IFA1_T;

typedef struct CLNX_TAM_INT_DEMO_INFO_S
{
    bool valid;
    uint32_t profile; /* sdk: The profile ID 0 ~ 7 are for DTEL profile, and profile 0 reserve to port tasnsit only. */
    sai_object_id_t tam_int_id;
    sai_tam_int_type_t int_type;
    CLNX_TAM_INT_DEVICE_ROLE_T device_role;
    union
    {
        CLNX_TAM_INT_DEMO_IOAM_T ioam;
        CLNX_TAM_INT_DEMO_IFA1_T ifa1;
    } u;
    uint32_t sampling_rate;
    CLNX_TAM_INT_MODE_T transit_mode;
    sai_object_list_t transit_port;
    CLNX_TAM_INT_MODE_T terminator_mode;
    sai_object_list_t sink_port;
    sai_object_id_t acl_entry;
    uint32_t acl_rule_id;
    sai_object_id_t mir_oid;
    uint32_t mir_id;
    uint32_t vlan_bmp[CLNX_SAI_VLAN_BMP_SIZE];
    bool sonic_test;
#define CLNX_TAM_INT_DEMO_FLAGS_ACL (1UL << 0)
#define CLNX_TAM_INT_DEMO_FLAGS_MIRROR (1UL << 1)
#define CLNX_TAM_INT_DEMO_FLAGS_VLAN (1UL << 2)
    uint32_t flags;
} CLNX_TAM_INT_DEMO_INFO_T;

typedef struct CLNX_TAM_INT_DEMO_PORT_TS_REF_S
{
    bool enable;
    uint32_t en_count;
} CLNX_TAM_INT_DEMO_PORT_TS_REF_T;

typedef struct CLNX_TAM_INT_DEMO_PORT_TS_S
{
    CLNX_TAM_INT_DEMO_PORT_TS_REF_T ts_en;
    #if 0
    CLNX_TAM_INT_DEMO_PORT_TS_REF_T ts_insert_eof_igr;
    CLNX_TAM_INT_DEMO_PORT_TS_REF_T ts_insert_eof_egr;
    #endif
} CLNX_TAM_INT_DEMO_PORT_TS_T;

typedef struct CLNX_TAM_INT_DEMO_SWC_CSO_S
{
    CLX_SWC_CSO_MODE_T mode;
    uint32_t master_count; /* count setting for master*/
} CLNX_TAM_INT_DEMO_SWC_CSO_T;

typedef struct CLNX_TAM_INT_DEMO_TS_S
{
    CLNX_TAM_INT_DEMO_SWC_CSO_T cso;
    CLNX_TAM_INT_DEMO_PORT_TS_T port_ts[CLNX_SAI_MAX_PORT_NUM];
    CLX_SEMAPHORE_ID_T sema;
} CLNX_TAM_INT_DEMO_TS_T;

typedef enum
{
    CLNX_TAM_INT_DEMO_TS_ACTION_ENABLE = 0,
    CLNX_TAM_INT_DEMO_TS_ACTION_DISABLE,
    CLNX_TAM_INT_DEMO_TS_ACTION_LAST,
} CLNX_TAM_INT_DEMO_TS_ACTION;

sai_status_t
clnx_tam_int_demo_init(
    _In_ const uint32_t unit);

sai_status_t
clnx_tam_int_demo_deinit(
    _In_ const uint32_t unit);

CLX_ERROR_NO_T
clnx_tam_int_demo_initDiagTask(void);

CLX_ERROR_NO_T
clnx_tam_int_demo_deinitDiagTask(void);

CLX_ERROR_NO_T
_clnx_tam_int_demo_procNonSdkCmd(
    const C8_T          *ptr_cmd_buf);

void
_clnx_tam_int_demo_clearCmdOutBuf(void);

sai_status_t
clnx_tam_int_demo_str_to_uint(
    _In_ const char    *string,
    _Out_ UI32_T       *pUint);

sai_status_t
clnx_tam_int_demo_uint_to_str(
    _In_ const UI32_T    uint,
    _Out_ char    *string);

sai_status_t clnx_tam_int_demo_set_ts(
	_In_ uint32_t unit,
	_In_ CLNX_TAM_INT_DEMO_TS_ACTION action);

#endif

/* =========SAI_API_TAM_INT========= */
#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
typedef struct CLNX_TAM_INT_IOAM_S
{
    uint32_t trace_type;
    uint32_t opq_id;
    uint8_t node_len;
} CLNX_TAM_INT_IOAM_T;

typedef struct CLNX_TAM_INT_IFA1_S
{
    uint32_t presence_pb1;
    uint32_t presence_pb2;
    bool in_line;
    uint16_t trace_vector;
    uint16_t action_vector;
    uint32_t send_id;
    uint32_t seq_num;
    uint8_t tid;
} CLNX_TAM_INT_IFA1_T;

#if 0
typedef struct CLNX_TAM_INT_P4_S
{
    uint16_t p4_int_instruction_bitmap;

} CLNX_TAM_INT_P4_T;
#endif

typedef struct CLNX_TAM_INT_BIND_DATA_S
{
    sai_object_id_t oid;
} CLNX_TAM_INT_BIND_DATA_T;

typedef struct CLNX_TAM_INT_DEVICE_S
{
    CLNX_TAM_INT_DEVICE_ROLE_T role;
    CLNX_TAM_INT_MODE_T mode;
    uint32_t acl_ref;
    /* Now, when there is only IFA sample mode on the terminator, the chip can mirror itself, but
    supports egress mirroring only. Use mir_change to mark whether the mirror has been secretly
    modified, bit0:1 indicates that the ingress mirror 0(sdk) has been changed to egress, and bit0:0 indicates that the
    mirror has not been modified. */
    uint32_t mir_change;
    union
    {
        CMLIB_LIST_T *port_list;
        CMLIB_LIST_T *mir_list;
    } u;
    uint32_t list_len; /* for warm-reboot */
} CLNX_TAM_INT_DEVICE_T;

typedef struct CLNX_TAM_INT_INFO_S
{
    bool valid;
    uint32_t profile; /* sdk: The profile ID 0 ~ 7 are for DTEL profile, and profile 0 reserve to port tasnsit only. */
    sai_tam_int_type_t int_type;
    sai_tam_int_presence_type_t presence_type;
    uint32_t device_id;
    union
    {
        CLNX_TAM_INT_IOAM_T ioam;
        CLNX_TAM_INT_IFA1_T ifa1;
        //CLNX_TAM_INT_P4_T p4;
    } u;
    uint8_t presence_dscp_value;
    uint8_t presence_l3_protocol;
    bool metadata_fragment_enable;
    bool report_all_packets;
    uint16_t flow_liveness_period;
    uint8_t latency_sensitivity;
    uint8_t max_hop_count;
    uint8_t max_length;
    uint8_t name_space_id;
    bool name_sapce_id_global;
    sai_object_id_t acl_group;
    sai_object_id_t ingress_samplepacket_enable;
    uint32_t sampling_rate;
    sai_object_list_t collector;
    sai_object_id_t math_func;
    sai_object_id_t report_id;
    sai_object_list_t transit_port; /* for tam int demo */
    sai_object_list_t sink_port; /* for tam int demo */
    CLNX_TAM_INT_DEVICE_T device;
} CLNX_TAM_INT_INFO_T;

sai_status_t
clnx_tam_int_init(
    _In_ const uint32_t unit);

sai_status_t
clnx_tam_int_deinit(
    _In_ const uint32_t unit);

sai_status_t clnx_create_tam_int(
        _Out_ sai_object_id_t *tam_int_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

sai_status_t clnx_remove_tam_int(
        _In_ sai_object_id_t tam_int_id);

sai_status_t clnx_get_tam_int_attribute(
        _In_ sai_object_id_t tam_int_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

sai_status_t clnx_set_tam_int_attribute(
        _In_ sai_object_id_t tam_int_id,
        _In_ const sai_attribute_t *attr);

sai_status_t clnx_set_tam_int(
	_In_ sai_object_id_t tam_int_id,
	_In_ CLNX_TAM_INT_DEMO_INFO_T *ptr_demo);

sai_status_t clnx_tam_int_create_obj(
	_In_ uint32_t unit,
	_In_ uint32_t profile_id,
	_Out_ sai_object_id_t *tam_int_id);

sai_status_t clnx_tam_int_get_profile_id(
	_In_ const sai_object_id_t tam_int_id,
	_Out_ uint32_t *profile_id);

char * clnx_tam_int_type_to_str(
        _In_ sai_tam_int_type_t type);

char * clnx_tam_int_device_role_to_str(
        _In_ CLNX_TAM_INT_DEVICE_ROLE_T type);

char * clnx_tam_int_presence_type_to_str(
        _In_ sai_tam_int_presence_type_t type);

sai_status_t clnx_tam_int_update_port(
    _In_ const sai_object_id_t    tam_int_oid,
    _In_ const sai_object_id_t    port_oid,
    _In_ const bool    bind);

sai_status_t clnx_tam_int_update_acl(
    _In_ const sai_object_id_t    tam_int_oid,
    _In_ const bool    bind,
    _Out_ uint32_t    *sdk_profile_id);

sai_status_t clnx_tam_int_update_mirror(
    _In_ const sai_object_id_t    tam_int_oid,
    _In_ const sai_object_list_t    *mir_list,
    _In_ const CLX_MIR_DIRECTION_T    mir_dir,
    _In_ const bool bind);

sai_status_t clnx_tam_int_get_int_info_brief(
    _In_ const sai_object_id_t tam_int_id,
    _Out_ CLNX_TAM_INT_INFO_T *ptr_int_info);

sai_status_t clnx_tam_int_updateSampleRate(
    _In_ const sai_object_id_t tam_int_oid,
    _In_ uint32_t sample_rate);

#endif

/* =========SAI_API_WARM========= */
typedef sai_status_t (*SAI_MODULE_BACKUP_FUNC)(
    _In_ const uint32_t unit,
    _Out_ uint32_t* module_length,
    _Out_ void** module_data);

extern SAI_MODULE_BACKUP_FUNC sai_module_backer[CLNX_SAI_API_MAX];
#define SAI_REGISTER_WARM_BACKER(func)   do { sai_module_backer[__MODULE__] = func; } while (0)

extern sai_status_t clnx_sai_restore_module_data(uint32_t unit, char*filename, uint32_t *length);
extern sai_status_t clnx_sai_get_module_warm_data(
    _In_ sai_api_t module,
    _In_ uint32_t unit,
    _Out_ uint32_t* length,
    _Out_ void** data);
uint32_t clnx_sai_get_boot_type(uint32_t unit);
bool clnx_sai_get_deinit_type(uint32_t unit);
void set_fake_warm_reboot(bool warm);
int get_fake_warm_reboot(void);

#if SAI_VERSION_CODE >= SAI_VER(1,5,0)
sai_status_t clnx_tam_report_data(
    _In_ sai_object_id_t    tam_oid,
    _In_ uint8_t    *ptr_buf,
    _In_ uint32_t   buf_len);

sai_status_t
clnx_tam_telemetry_clear_stats(void);

sai_status_t
clnx_tam_telemetry_create(
    _In_ uint32_t   collector_dst_ip,
    _In_ uint32_t   collector_dst_port,
    _In_ uint32_t   interval);

sai_status_t
clnx_tam_telemetry_destroy(void);
#endif

sai_status_t
clnx_pkj_init(
    _In_ uint32_t   unit);

sai_status_t
clnx_pkj_deinit(
    _In_ uint32_t   unit);

sai_status_t
clnx_pkj_createEntry(
    _In_ sai_object_id_t switch_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);

sai_status_t
clnx_pkj_removeEntry(
    _In_ uint32_t   unit);

bool clnx_pkj_getCaptureEnable(
    _In_ uint32_t   unit);

 sai_status_t
clnx_pkj_restartTrigger(void);

sai_status_t
clnx_pkj_setTamOid(
    _In_ uint32_t   unit,
    _In_ sai_object_id_t    tam_oid);

sai_status_t
clnx_pkj_getTamOid(
    _In_ uint32_t   unit,
    _In_ sai_object_id_t    *ptr_tam_oid);

sai_status_t
clnx_pkj_destroyTam(void);

sai_status_t
clnx_pkj_createTam(
    _In_ uint32_t   collector_dst_ip,
    _In_ uint32_t   collector_dst_port);

sai_status_t
clnx_hairpin_init(
    _In_ uint32_t   unit);

sai_status_t
clnx_hairpin_deinit(
    _In_ uint32_t   unit);

sai_status_t
clnx_hairpin_getTamOid(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry,
    _In_ sai_object_id_t    *ptr_tam_oid);

sai_status_t
clnx_hairpin_addMonitorNode(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id,
    _In_ uint32_t   rate,
    _In_ sai_object_id_t    cnt_obj,
    _In_ sai_object_id_t    tam_obj);

sai_status_t
clnx_hairpin_removeMonitorNode(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

sai_status_t
clnx_hairpin_updateMonitorNode(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id,
    _In_ sai_acl_entry_attr_t   type,
    _In_ const sai_attribute_value_t *ptr_value);

sai_status_t
clnx_hairpin_destroyTam(void);

sai_status_t
clnx_hairpin_createTam(
    _In_ uint32_t   collector_dst_ip,
    _In_ uint32_t   collector_dst_port,
    _In_ CLX_PORT_BITMAP_T  *ptr_portlist,
    _In_ uint32_t   kbps);

sai_status_t
clnx_hairpin_addEntry(
    _In_ C8_T *hairpin_name,
    _In_ CLX_PORT_BITMAP_T  igr_pbm,
    _In_ CLX_PORT_BITMAP_T  egr_pbm,
    _In_ sai_object_id_t tam_obj);

sai_status_t
clnx_hairpin_delEntry(
    _In_ C8_T *hairpin_name);

sai_status_t
clnx_hairpin_showEntry(void);

#define SAI_COLD_BOOT               0
#define SAI_WARM_BOOT              1
#define SAI_FAST_BOOT                2
#define SAI_IS_WARM_BOOT(unit)  (get_fake_warm_reboot() || clnx_sai_get_boot_type(unit) == SAI_WARM_BOOT)
#define SAI_IS_FAST_BOOT(unit)  (clnx_sai_get_boot_type(unit) == SAI_FAST_BOOT)
#define SAI_IS_WARM_DEINIT(unit)  clnx_sai_get_deinit_type(unit)

#define offsetof(TYPE, MEMBER) ((size_t)&((TYPE *)0)->MEMBER)

/* sai tam*/
typedef enum
{
    CLNX_TEL_PORT_STATS_RX_OCTETS,
    CLNX_TEL_PORT_STATS_RX_PKTS,
    CLNX_TEL_PORT_STATS_RX_UCAST_PKTS,
    CLNX_TEL_PORT_STATS_RX_MULTICAST_PKTS,
    CLNX_TEL_PORT_STATS_RX_BROADCAST_PKTS,
    CLNX_TEL_PORT_STATS_RX_ERR_PKTS,
    CLNX_TEL_PORT_STATS_RX_DROP_PKTS,
    CLNX_TEL_PORT_STATS_RX_UNDERSIZE_PKTS,
    CLNX_TEL_PORT_STATS_RX_FRAGMENTS,
    CLNX_TEL_PORT_STATS_RX_OVERSIZE_PKTS,
    CLNX_TEL_PORT_STATS_RX_JABBERS,
    CLNX_TEL_PORT_STATS_RX_SYMBOL_ERRORS,
    CLNX_TEL_PORT_STATS_RX_COLLISIONS,
    CLNX_TEL_PORT_STATS_RX_CRC_ALIGN_ERRORS,
    CLNX_TEL_PORT_STATS_RX_FRAME_TOO_LONGS,
    CLNX_TEL_PORT_STATS_RX_UNKNOWN_OPCODES,
    CLNX_TEL_PORT_STATS_RX_L2_MTU_DISCARDS,
    CLNX_TEL_PORT_STATS_RX_L3_DISCARDS,
    CLNX_TEL_PORT_STATS_RX_L3_BLACKHOLE_DISCARDS,
    CLNX_TEL_PORT_STATS_RX_NON_QUEUE_DISCARDS,
    CLNX_TEL_PORT_STATS_RX_PARITY_DISCARDS,
    CLNX_TEL_PORT_STATS_RX_PAUSE_PKTS,
    CLNX_TEL_PORT_STATS_RX_PFC_0_PKTS,
    CLNX_TEL_PORT_STATS_RX_PFC_1_PKTS,
    CLNX_TEL_PORT_STATS_RX_PFC_2_PKTS,
    CLNX_TEL_PORT_STATS_RX_PFC_3_PKTS,
    CLNX_TEL_PORT_STATS_RX_PFC_4_PKTS,
    CLNX_TEL_PORT_STATS_RX_PFC_5_PKTS,
    CLNX_TEL_PORT_STATS_RX_PFC_6_PKTS,
    CLNX_TEL_PORT_STATS_RX_PFC_7_PKTS,
    CLNX_TEL_PORT_STATS_RX_PKTS_64_OCTETS,
    CLNX_TEL_PORT_STATS_RX_PKTS_65_TO_127_OCTETS,
    CLNX_TEL_PORT_STATS_RX_PKTS_128_TO_255_OCTETS,
    CLNX_TEL_PORT_STATS_RX_PKTS_256_TO_511_OCTETS,
    CLNX_TEL_PORT_STATS_RX_PKTS_512_TO_1023_OCTETS,
    CLNX_TEL_PORT_STATS_RX_PKTS_1024_TO_1518_OCTETS,
    CLNX_TEL_PORT_STATS_RX_PKTS_1519_TO_MAX_OCTETS,

    CLNX_TEL_PORT_STATS_RX_LAST
} CLNX_TEL_PORT_STATS_RX_T;

typedef enum
{
    CLNX_TEL_PORT_STATS_TX_OCTETS,
    CLNX_TEL_PORT_STATS_TX_PKTS,
    CLNX_TEL_PORT_STATS_TX_UCAST_PKTS,
    CLNX_TEL_PORT_STATS_TX_MULTICAST_PKTS,
    CLNX_TEL_PORT_STATS_TX_BROADCAST_PKTS,
    CLNX_TEL_PORT_STATS_TX_ERR_PKTS,
    CLNX_TEL_PORT_STATS_TX_DROP_PKTS,
    CLNX_TEL_PORT_STATS_TX_L3_DISCARDS,
    CLNX_TEL_PORT_STATS_TX_NON_QUEUE_DISCARDS,
    CLNX_TEL_PORT_STATS_TX_INVALID_VLAN_DISCARDS,
    CLNX_TEL_PORT_STATS_BUFFER_DISCARDS,
    CLNX_TEL_PORT_STATS_TX_OVERSIZE_PKTS,
    CLNX_TEL_PORT_STATS_TX_PAUSE_PKTS,
    CLNX_TEL_PORT_STATS_TX_PFC_0_PKTS,
    CLNX_TEL_PORT_STATS_TX_PFC_1_PKTS,
    CLNX_TEL_PORT_STATS_TX_PFC_2_PKTS,
    CLNX_TEL_PORT_STATS_TX_PFC_3_PKTS,
    CLNX_TEL_PORT_STATS_TX_PFC_4_PKTS,
    CLNX_TEL_PORT_STATS_TX_PFC_5_PKTS,
    CLNX_TEL_PORT_STATS_TX_PFC_6_PKTS,
    CLNX_TEL_PORT_STATS_TX_PFC_7_PKTS,
    CLNX_TEL_PORT_STATS_TX_PKTS_64_OCTETS,
    CLNX_TEL_PORT_STATS_TX_PKTS_65_TO_127_OCTETS,
    CLNX_TEL_PORT_STATS_TX_PKTS_128_TO_255_OCTETS,
    CLNX_TEL_PORT_STATS_TX_PKTS_256_TO_511_OCTETS,
    CLNX_TEL_PORT_STATS_TX_PKTS_512_TO_1023_OCTETS,
    CLNX_TEL_PORT_STATS_TX_PKTS_1024_TO_1518_OCTETS,
    CLNX_TEL_PORT_STATS_TX_PKTS_1519_TO_MAX_OCTETS,

    CLNX_TEL_PORT_STATS_TX_LAST
} CLNX_TEL_PORT_STATS_TX_T;

typedef enum
{
    CLNX_TEL_QUEUE_STATS_OCTETS,         //chip not support.
    CLNX_TEL_QUEUE_STATS_PKTS,
    CLNX_TEL_QUEUE_STATS_DROP_OCTETS,         //chip not support.
    CLNX_TEL_QUEUE_STATS_DROP_PKTS,
    CLNX_TEL_QUEUE_STATS_LAST
}CLNX_TEL_QUEUE_STATS_T;

typedef struct
{
    uint32_t    tv_sec;
    uint32_t    tv_usec;
}CLNX_TM_VAL;

typedef enum
{
    CLNX_TEL_PORT_STATS_RATE_PKTS,
    CLNX_TEL_PORT_STATS_RATE_BYTES,

    CLNX_TEL_PORT_STATS_RATE_LAST,
}CLNX_PORT_STAT_RATE_T;

typedef struct
{
    uint32_t    port;
    uint64_t    ingress_stats[CLNX_TEL_PORT_STATS_RX_LAST];
    uint64_t    egress_stats[CLNX_TEL_PORT_STATS_TX_LAST];
    uint64_t    queue_stats[CLNX_QUEUE_UC_NUM+CLNX_QUEUE_MC_NUM][CLNX_TEL_QUEUE_STATS_LAST];
    uint64_t    igr_stats_rate[CLNX_TEL_PORT_STATS_RATE_LAST];
    uint64_t    egr_stats_rate[CLNX_TEL_PORT_STATS_RATE_LAST];

#define STATS_ENABLE_FLAGS_PORT_INGRESS     (0x1 << 0)
#define STATS_ENABLE_FLAGS_PORT_EGRESS      (0x1 << 1)
#define STATS_ENABLE_FLAGS_OUTPUT_QUEUE     (0x1 << 2)
#define STATS_ENABLE_FLAGS_MMU_STATS     (0x1 << 3)
    uint32_t    flags;
}CLNX_TEL_PORT_STATS_T;


#define CLNX_SAI_TAM_BUF_SNAPSHOT_RECORD_MAX     (120)
#define CLNX_SAI_TAM_BUF_SNAPSHOT_POOL_CNT       (4)
#define CLNX_SAI_TAM_BUF_SNAPSHOT_TYPE_PERIODIC      (1 << 0)
#define CLNX_SAI_TAM_BUF_SNAPSHOT_TYPE_THRESHOLD_EGR_GLOBAL      (1 << 1)

typedef struct
{
    uint32_t    igr_glb_lossless;
    uint32_t    igr_glb_headroom;
    uint32_t    egr_glb_share;
}CLNX_TM_POOL_SNAPSHOT_T;

typedef struct
{
    uint32_t    igr_queue[CLNX_QUEUE_LEGACY_NUM];
    uint32_t    egr_uc_queue[CLNX_QUEUE_LEGACY_NUM];
    uint32_t    egr_mc_queue[CLNX_QUEUE_LEGACY_NUM];
}CLNX_TM_PORT_SNAPSHOT_T;

typedef struct
{
    uint32_t    index;
    CLNX_TM_VAL   time[CLNX_SAI_TAM_BUF_SNAPSHOT_RECORD_MAX];
    uint32_t    type[CLNX_SAI_TAM_BUF_SNAPSHOT_RECORD_MAX];
    CLNX_TM_POOL_SNAPSHOT_T  pool[CLNX_SAI_TAM_BUF_SNAPSHOT_RECORD_MAX][CLNX_SAI_TAM_BUF_SNAPSHOT_POOL_CNT];
    CLNX_TM_PORT_SNAPSHOT_T  port[CLNX_SAI_TAM_BUF_SNAPSHOT_RECORD_MAX][CLNX_SAI_MAX_PORT_NUM];
    uint32_t    cpu[CLNX_SAI_TAM_BUF_SNAPSHOT_RECORD_MAX][CLNX_QUEUE_CPU_NUM];
}CLNX_TM_SNAPSHOT_T;

typedef struct
{
    CLNX_TM_VAL   time;
    CLNX_TM_POOL_SNAPSHOT_T  pool[CLNX_SAI_TAM_BUF_SNAPSHOT_POOL_CNT];
    CLNX_TM_PORT_SNAPSHOT_T  port[CLNX_SAI_MAX_PORT_NUM];
    uint32_t    cpu[CLNX_QUEUE_CPU_NUM];
}CLNX_TM_SNAPSHOT_STAT_T;


#if SAI_VERSION_CODE >= SAI_VER(1, 5, 0)
extern sai_status_t _clnx_watermark_threshold_init(const UI32_T    unit);
extern sai_status_t _clnx_watermark_threshold_deinit(const uint32_t unit);

#define CLNX_WATERMARK_THRESHOLD_STATUS_OVER (1)
#define CLNX_WATERMARK_THRESHOLD_STATUS_NOT_OVER (0)

extern sai_status_t clnx_watermark_tam_update_threshold(_In_ uint32_t unit);

typedef struct _clnx_watermark_queue_tam_t
{
    uint32_t unit;
    uint32_t type;
    uint32_t port;
    uint32_t queue;
    uint32_t queue_type;
    sai_object_id_t tam_obj;
} clnx_watermark_queue_tam_t;

typedef struct _clnx_watermark_queue_threshold_t
{
    uint32_t unit;
    uint32_t type;
    uint32_t port;
    uint32_t queue;
    uint32_t queue_type;
    uint32_t threshold_value;
    uint32_t status;
} clnx_watermark_queue_threshold_t;

typedef struct _clnx_watermark_queue_threshold_report_t
{
    uint32_t unit;
    uint32_t type;
    uint32_t port;
    uint32_t queue;
    uint32_t queue_type;
    uint32_t threshold_percentage_value;
    uint32_t threshold_byte_value;
    struct timeval tv;
} clnx_watermark_queue_threshold_report_t;

typedef struct _clnx_watermark_port_tam_t
{
    uint32_t unit;
    uint32_t type;
    uint32_t port;
    sai_object_id_t tam_obj;
} clnx_watermark_port_tam_t;

typedef struct _clnx_watermark_port_threshold_t
{
    uint32_t unit;
    uint32_t type;
    uint32_t port;
    uint32_t threshold_value;
    uint32_t status;
} clnx_watermark_port_threshold_t;

typedef struct _clnx_watermark_port_threshold_report_t
{
    uint32_t unit;
    uint32_t type;
    uint32_t port;
    uint32_t threshold_percentage_value;
    uint32_t threshold_byte_value;
    struct timeval tv;
} clnx_watermark_port_threshold_report_t;

typedef struct _clnx_watermark_global_threshold_report_t
{
    uint32_t unit;
    uint32_t pool_id;
    uint32_t threshold_byte_value;
    struct timeval tv;
} clnx_watermark_global_threshold_report_t;

extern sai_status_t clnx_watermark_show_global_threshold();
extern sai_status_t clnx_watermark_show_port_threshold();
extern sai_status_t clnx_watermark_show_queue_threshold();
extern sai_status_t clnx_watermark_set_global_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t threshold_value);
extern sai_status_t clnx_watermark_set_port_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t type,
    _In_ uint32_t port,
    _In_ uint32_t threshold_value);
extern sai_status_t clnx_watermark_set_queue_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t type,
    _In_ uint32_t port,
    _In_ uint32_t queue,
    _In_ uint32_t queue_type,
    _In_ uint32_t threshold_value);
extern sai_status_t clnx_watermark_clear_global_threshold(_In_ uint32_t unit);
extern sai_status_t clnx_watermark_clear_port_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t type,
    _In_ uint32_t port);
extern sai_status_t clnx_watermark_clear_queue_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t type,
    _In_ uint32_t port,
    _In_ uint32_t queue,
    _In_ uint32_t queue_type);

extern sai_status_t clnx_watermark_tam_set_queue_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t type,
    _In_ uint32_t port,
    _In_ uint32_t queue,
    _In_ uint32_t queue_type,
    _In_ uint32_t threshold_value,
    sai_object_id_t tam_obj);
extern sai_status_t clnx_watermark_tam_clear_queue_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t type,
    _In_ uint32_t port,
    _In_ uint32_t queue,
    _In_ uint32_t queue_type);

extern sai_status_t clnx_watermark_tam_set_port_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t type,
    _In_ uint32_t port,
    _In_ uint32_t threshold_value,
    sai_object_id_t tam_obj);
extern sai_status_t clnx_watermark_tam_clear_port_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t type,
    _In_ uint32_t port);

sai_status_t clnx_watermark_tam_set_global_threshold(
    _In_ uint32_t unit,
    _In_ uint32_t threshold_value,
    sai_object_id_t tam_obj);
sai_status_t clnx_watermark_tam_clear_global_threshold(_In_ uint32_t unit);

extern sai_status_t clnx_wmd_snapshot_show_interval();
extern sai_status_t clnx_wmd_snapshot_config_interval(_In_ uint32_t value);

#define _STRING_MAX_LEN 32
#define STRING_NAME_MAX_LENGTH 128
typedef struct _clnx_wmd_object_threshold_t
{
    C8_T     name[_STRING_MAX_LEN];
    C8_T     mode[_STRING_MAX_LEN];
    uint32_t high_threshold_value;
    uint32_t low_threshold_value;
    uint32_t rate_threshold_value;

    sai_object_id_t threshold_obj_id;
    uint32_t reference_count;
} clnx_wmd_object_threshold_t;

extern sai_status_t clnx_wmd_object_threshold_show();
extern sai_status_t
clnx_wmd_object_threshold_create(
    _In_ C8_T *name,
    _In_ C8_T *mode,
    _In_ uint32_t high_threshold_value,
    _In_ uint32_t low_threshold_value,
    _In_ uint32_t rate_threshold_value);
extern sai_status_t clnx_wmd_object_threshold_del(_In_ C8_T *name);

typedef struct _clnx_wmd_object_collector_t
{
    C8_T     name[_STRING_MAX_LEN];
    C8_T     ip[_STRING_MAX_LEN];
    uint32_t port;
    sai_object_id_t collector_obj_id;
    sai_object_id_t transport_obj_id;
    uint32_t reference_count;
} clnx_wmd_object_collector_t;

extern sai_status_t clnx_wmd_object_collector_show();
extern sai_status_t clnx_wmd_object_collector_create(_In_ C8_T *name,
                                                    _In_ C8_T *ip,
                                                    _In_ uint32_t port);
extern sai_status_t clnx_wmd_object_collector_del(_In_ C8_T *name);

typedef struct _clnx_wmd_object_tam_event_t
{
    C8_T     name[_STRING_MAX_LEN];
    C8_T     type[_STRING_MAX_LEN];
    C8_T     collectors_name[STRING_NAME_MAX_LENGTH]; /* 128 */
    C8_T     threshold_name[_STRING_MAX_LEN];
    sai_object_id_t tam_event_obj_id;
    uint32_t reference_count;
} clnx_wmd_object_tam_event_t;

extern sai_status_t clnx_wmd_object_tam_event_show();
extern sai_status_t clnx_wmd_object_tam_event_create(_In_ C8_T *name,
                                                    _In_ C8_T *type,
                                                    _In_ C8_T *collectors_name,
                                                    _In_ C8_T *threshold_name);
extern sai_status_t clnx_wmd_object_tam_event_del(_In_ C8_T *name);

typedef struct _clnx_wmd_object_tam_t
{
    C8_T     name[_STRING_MAX_LEN];
    C8_T     type[_STRING_MAX_LEN];
    C8_T     tamevents_name[STRING_NAME_MAX_LENGTH]; /* 128 */
    C8_T     telemetry_name[STRING_NAME_MAX_LENGTH]; /* 128 */
    sai_object_id_t tam_obj_id;
    uint32_t reference_count;
} clnx_wmd_object_tam_t;

extern sai_status_t clnx_wmd_object_tam_show();
extern sai_status_t clnx_wmd_object_tam_create(_In_ C8_T *name,
                                              _In_ C8_T *type,
                                              _In_ C8_T *tamevents_name,
                                              _In_ C8_T *telemetry_name);
extern sai_status_t clnx_wmd_object_tam_del(_In_ C8_T *name);

typedef struct _clnx_wmd_tam_bind_queue_t
{
    uint32_t unit;
    uint32_t type;
    uint32_t port;
    uint32_t queue;
    uint32_t queue_type;
    C8_T     tam_name[_STRING_MAX_LEN];
} clnx_wmd_tam_bind_queue_t;
extern sai_status_t clnx_wmd_tam_bind_queue_show();
extern sai_status_t clnx_wmd_tam_bind_queue_set(
                                               _In_ uint32_t unit,
                                               _In_ uint32_t type,
                                               _In_ uint32_t port,
                                               _In_ uint32_t queue,
                                               _In_ uint32_t queue_type,
                                               _In_ C8_T *tam_name);

extern sai_status_t clnx_wmd_tam_bind_queue_del(
                                               _In_ uint32_t unit,
                                               _In_ uint32_t type,
                                               _In_ uint32_t port,
                                               _In_ uint32_t queue,
                                               _In_ uint32_t queue_type,
                                               _In_ C8_T *tam_name);

typedef struct _clnx_wmd_tam_bind_port_t
{
    uint32_t unit;
    uint32_t port;
    C8_T     tam_name[_STRING_MAX_LEN];
} clnx_wmd_tam_bind_port_t;
extern sai_status_t clnx_wmd_tam_bind_port_show();
extern sai_status_t clnx_wmd_tam_bind_port_set(
                                              _In_ uint32_t unit,
                                              _In_ uint32_t port,
                                              _In_ C8_T *tam_name);
extern sai_status_t clnx_wmd_tam_bind_port_del(
                                              _In_ uint32_t unit,
                                              _In_ uint32_t port,
                                              _In_ C8_T *tam_name);

typedef struct _clnx_wmd_tam_bind_switch_t
{
    uint32_t    unit;
    C8_T     tam_name[_STRING_MAX_LEN];
} clnx_wmd_tam_bind_switch_t;
extern sai_status_t clnx_wmd_get_tam_obj(
                                                _In_ C8_T   *tam_name,
                                                _Inout_ sai_object_id_t *tam_obj);
extern sai_status_t clnx_wmd_tam_bind_switch_show();
extern sai_status_t clnx_wmd_tam_bind_switch_set(
                                                _In_ uint32_t unit,
                                                _In_ C8_T *tam_name);
extern sai_status_t clnx_wmd_tam_bind_switch_del(
                                                _In_ uint32_t unit,
                                                _In_ C8_T *tam_name);

extern sai_status_t clnx_wmd_watermark_tam_bind_queue_set(
                                               _In_ uint32_t unit,
                                               _In_ uint32_t type,
                                               _In_ uint32_t port,
                                               _In_ uint32_t queue,
                                               _In_ uint32_t queue_type,
                                               _In_ C8_T *tam_name,
                                               _In_ uint32_t threshold_value);
extern sai_status_t clnx_wmd_watermark_tam_bind_queue_clear(
                                               _In_ uint32_t unit,
                                               _In_ uint32_t type,
                                               _In_ uint32_t port,
                                               _In_ uint32_t queue,
                                               _In_ uint32_t queue_type);

extern sai_status_t clnx_wmd_watermark_tam_bind_port_set(
                                               _In_ uint32_t unit,
                                               _In_ uint32_t type,
                                               _In_ uint32_t port,
                                               _In_ C8_T *tam_name,
                                               _In_ uint32_t threshold_value);
extern sai_status_t clnx_wmd_watermark_tam_bind_port_clear(
                                               _In_ uint32_t unit,
                                               _In_ uint32_t type,
                                               _In_ uint32_t port);

extern sai_status_t clnx_wmd_watermark_tam_bind_global_set(
                                               _In_ uint32_t unit,
                                               _In_ C8_T *tam_name,
                                               _In_ uint32_t threshold_value);
extern sai_status_t clnx_wmd_watermark_tam_bind_global_clear(_In_ uint32_t unit);

sai_status_t
clnx_sai_tam_switch_config_tamlist(
  _In_ uint32_t           oper_flag,
  _In_ sai_object_id_t switch_id,
  _In_ sai_object_list_t tamobjlist);

extern sai_status_t
clnx_sai_tam_watermark_queue_threshold_trigger_send(
    _In_ uint32_t   unit,
    _In_ uint32_t type,
    _In_ uint32_t port,
    _In_ uint32_t queue,
    _In_ uint32_t handler,
    _In_ uint32_t threshold_byte_value,
    _In_ CLNX_TM_VAL *trigger_time,
    _In_ CLNX_TM_VAL *report_time,
    sai_object_id_t tam_obj_oid);

extern sai_status_t
clnx_sai_tam_watermark_port_threshold_trigger_send(
    _In_ uint32_t   unit,
    _In_ uint32_t type,
    _In_ uint32_t port,
    _In_ uint32_t threshold_byte_value,
    _In_ CLNX_TM_VAL *trigger_time,
    _In_ CLNX_TM_VAL *report_time,
    sai_object_id_t tam_obj_oid);

extern sai_status_t
clnx_sai_tam_watermark_global_threshold_trigger_send(
    _In_ uint32_t   unit,
    _In_ uint32_t pool_id,
    _In_ uint32_t threshold_byte_value,
    _In_ CLNX_TM_VAL *trigger_time,
    _In_ CLNX_TM_VAL *report_time,
    sai_object_id_t tam_obj_oid);

extern sai_status_t
clnx_wmd_object_telemetry_create(
    _In_ C8_T *name,
    _In_ C8_T *collector_name,
    _In_ UI32_T report_interval,
    _In_ BOOL_T ingress_port_stats_enable,
    _In_ BOOL_T egress_port_stats_enable,
    _In_ BOOL_T queue_stats_enable,
    _In_ BOOL_T mmu_stats_enable);

extern sai_status_t clnx_wmd_object_telemetry_show(void);
extern sai_status_t clnx_wmd_object_telemetry_del(_In_ C8_T *name);
#endif  /* SAI_VERSION_CODE >= SAI_VER(1, 5, 0) */
#if SAI_VERSION_CODE >= SAI_VER(1,5,0)
sai_status_t
clnx_tam_getTamEventType(
    _In_ sai_object_id_t    tam_obj,
    _Out_ sai_tam_event_type_t  *ptr_event_type,
    _Out_ uint32_t  *ptr_rate);

sai_status_t
clnx_tam_setTamObjList(
    _In_ sai_object_id_t bind_obj,
    _In_ const sai_object_list_t   *ptr_tam_obj_list);

sai_status_t
clnx_tam_getTamObjList(
    _In_ sai_object_id_t bind_obj,
    _Inout_ sai_attribute_value_t   *value);
#endif
sai_status_t clnx_diag_init(void);
sai_status_t clnx_diag_deinit(void);
void
clnx_diag_printToCmdOutBuf(
    _In_ const void     *ptr_buf,
    _In_ UI32_T         len);

#endif /* __CLNX_SAI_H_ */
